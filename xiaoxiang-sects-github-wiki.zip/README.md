# Xiaoxiang Sects Expanded: Wiki

*Addon 1.0.148 · Minecraft 1.20.1 · Forge 47.x · needs Xiaoxiang Cultivation World 0.2.106+ and Threateningly Mobs 1.1+*

> **Disclaimer: I do not own anything.** This is an unofficial, fan-made addon. All credit goes to the main mod, **Xiaoxiang Cultivation World**, and its author, and to **Threateningly Mobs** and its author. If any author asks me to take this addon (or any part of it) down, I will remove it.

## Contents

- **Start here**: [Overview](#overview) · [Getting Started](#getting-started) · [Keys and Commands](#keys-and-commands) · [Server Settings](#server-settings) · [FAQ and Known Limitations](#faq-and-known-limitations) · [Version History](#version-history) · [Credits and Disclaimer](#credits-and-disclaimer)
- **Cultivation**: [The Harsh World](#the-harsh-world) · [Dao Paths](#dao-paths) · [Mastery](#mastery) · [Breakthroughs and Foundation](#breakthroughs-and-foundation) · [Dantian World and Soul Sea](#dantian-world-and-soul-sea) · [Domain Expansion](#domain-expansion)
- **The mortal world**: [The Mortal Kingdoms](#the-mortal-kingdoms) · [Town Wards and the Underworld](#town-wards-and-the-underworld) · [Life in the Cities](#life-in-the-cities) · [Clan Estates](#clan-estates)
- **The wilds**: [Demon Beasts](#demon-beasts) · [Great Evils and World Bosses](#great-evils-and-world-bosses) · [Spirit Stone Caves and Herb Grottos](#spirit-stone-caves-and-herb-grottos) · [Beast Tide Almanac](#beast-tide-almanac) · [Beast Tides](#beast-tides) · [Companion Beasts](#companion-beasts) · [Secret Realms](#secret-realms) · [Spirit Veins](#spirit-veins) · [Ancient Battlefields](#ancient-battlefields) · [Encounters on the Road](#encounters-on-the-road)
- **Sects of the world**: [Generated Sects](#generated-sects) · [Holy Sect Fairs](#holy-sect-fairs)
- **Your sect**: [Founding Your Sect](#founding-your-sect) · [Buildings and Production](#buildings-and-production) · [Arrays and the Reservoir](#arrays-and-the-reservoir) · [Defending Your Sect](#defending-your-sect) · [Sect Life](#sect-life) · [The Scripture Pagoda](#the-scripture-pagoda) · [Relations and War](#relations-and-war) · [Tournaments and the Arena](#tournaments-and-the-arena) · [Sect Wards and the Sect Domain](#sect-wards-and-the-sect-domain)
- **Missions**: [Missions and the Journal](#missions-and-the-journal) · [Sect Bounty Board](#sect-bounty-board)
- **Crafting and items**: [Minigames](#minigames) · [Items and Recipes](#items-and-recipes)

## Overview

**Xiaoxiang Sects Expanded** (shown in game as *Xiaoxiang Sects & Beasts*) is an unofficial addon for **Xiaoxiang Cultivation World**. It turns the main mod's world into a living cultivation world:

- **Harder cultivation:** cultivation is slow, breakthroughs are risky, resources and techniques are scarce, and stronger cultivators are a real threat to weaker ones.
- **The wilds:** demon beasts of the *Classic of Mountains and Seas* that cultivate, cast spells and fly. There are spirit stone caves and herb grottos, beast nests, world bosses and ten great evils sealed under altars.
- **Mortal kingdoms:** walled villages, towns and capitals with kings, clans, shops, inns, arenas and gambling houses. Towns are split into slums, an outer ring and an inner ring, and each has its own underworld.
- **Clans and sects:** clan estates out in the wilds, each with its own craft. Generated sects are ranked and specialised, and the finest of them are **Holy Sects** with pavilions far above any clan's.
- **Your own sect:** recruit disciples, raise buildings, run production, keep protection arrays, and defend against beast tides, war parties, sieges and demonic invasions. You can also take on missions, form alliances, fight wars, take vassals and hold tournaments.
- **Your inner world:** the Dantian World (meridians, storage, Dao seeds and the Dantian Guard), battles in the Soul Sea, and *[Domain Expansion](#domain-expansion)*.
- **Missions:** a Mission Journal with thirty kinds of missions, story chains, requests from the people you meet, reputation, achievements and titles.

The demon beasts come from **Threateningly Mobs**. Each creature keeps its own body and attacks, and gains a cultivation realm, a nature, spells and techniques.

### Requirements

| Requirement | Version | Notes |
|---|---|---|
| Minecraft | 1.20.1 | |
| Forge | 47.x | |
| Xiaoxiang Cultivation World | **0.2.106** or newer | The main mod, unmodified |
| Threateningly Mobs | 1.1 or newer | Required: it supplies the demon beasts |

### Installation

1. Install Forge 1.20.1.
2. Put the Xiaoxiang Cultivation World jar, the Threateningly Mobs jar and the addon jar in your `mods` folder. Keep **only one** addon jar: remove the old one when you update.
3. Install the **same addon version on the client and the server**. The network version must match (it is currently **24**).
4. A **new world** is strongly recommended. Caves, settlements, clan estates, sect arrays, grottos and secret realm layouts only appear in newly generated land.

### What the addon changes in the base game

- **Spawning:** only creatures that cultivate spawn by themselves. Vanilla monsters and animals no longer spawn naturally, but spawners, eggs, breeding and commands still work.
- **Wild spawns follow your strength:** creatures that spawn by themselves are matched to the strongest player nearby (see [The Harsh World](#the-harsh-world)).
- **Villages:** vanilla villages and villagers are replaced by the mortal kingdoms' walled settlements.
- **Spirit stones:** spirit stone ore and spirit vein springs no longer generate in the open world. Ore is found only in the caves.
- **Threateningly Mobs structures** (palaces, nests, altars, dungeons) never generate. Its creatures remain.
- **Arrays:** spirit vein cores and formation core plates store and supply far more qi, so protection arrays can stay up.
- **Crafting by hand:** the alchemy core, refining core and formation plate only work through hands-on minigames, and talismans are sealed with a brush minigame.
- **Scarcity:** breakthrough materials (Foundation and Golden Core) are rare in chests, rare with wandering cultivators and sold at four times the price.
- **A harsh world (on by default):** half-speed cultivation, harder breakthroughs, dearer goods, thinner chests and realm suppression. All of it can be configured.

### Compatibility

The addon hooks the main mod with small, optional mixins and never changes the main mod's jar. If a future main mod update changes the code a hook relies on, that hook switches itself off quietly instead of crashing.

## Getting Started

A suggested path for a new world. You don't have to follow it in this order.

### Your first days (Mortal to Qi Refining)

- **Find a settlement.** Mortal towns sell food, pills, herbs, arms and talisman supplies, and their inns, guilds and arenas have work. Use `/sectcity nearest` to find one.
- **Wild beasts are matched to you.** While you're weak, the beasts that spawn near you stay within one realm of you, and boss-rank beasts don't roam near you until you reach Foundation. Beyond 10,000 blocks from spawn the wilds are not matched to you at all.
- **Talk to people:** sneak and right-click with an empty hand. Wandering cultivators give news, advice and requests. Townsfolk, clan disciples, sect disciples and even wild beasts can be talked to.
- **The Mission Journal (O)** lists daily missions and the Mission Board. The Missions window on the left of the screen tracks what you're doing.
- **The Dao Awakening:** when you first draw qi into your body, the heavens choose your **Dao Path** (Sword, Pill, Body or Demonic). Your path grows with deeds that suit it.
- **Spirit stones** come from caves, slain beasts, bounties, missions and trade. The first wild caves are Low-grade.

### Building strength (Foundation to Golden Core)

- **Breakthroughs** need scarce materials. The **Paths to Ascension** (cultivation menu, G) list every road to them: your sect's Scripture Pavilion, the sect trial, a master's teaching, an ally's exchange, comprehension under a storm, a royal grant, clan adoption and more.
- **Found a sect** with a Sect Master's Command Token, recruit wandering cultivators and raise buildings.
- **Tame a companion beast** with a Beast Subduing Talisman.
- **Join a Holy Sect** by winning its recruitment fair in a capital under its sway.
- **Explore** spirit stone caves of higher grades, secret realm gates, spirit vein grottos and clan estates.

### Becoming a power (Nascent Soul and beyond)

- *[Domain Expansion](#domain-expansion)* (V) unfolds from Golden Core (incomplete), sealed from Nascent Soul and open from Mahayana.
- **The great breakthroughs** beyond Golden Core cost Ascension Seals, Beast Soul Orbs and spirit stones.
- **Take on the great powers:** world bosses, the great evils at the Demon-Sealing Altar, S-Rank gates, wars, sieges and vassals.
- **Beyond Earth Immortal**, the addon opens its own road through the immortal realms, and an immortal master can fold the sect into a **Sect Domain** of its own.

## Keys and Commands

### Keys

All keys can be rebound under *Controls → Xiaoxiang Sects*.

| Key | What it does |
|---|---|
| **G** | The cultivation mod's menu, with the addon's **Dao Path**, **Dantian World** and **Paths to Ascension** buttons |
| **H** | Open the **Dantian World** |
| **Shift+H** | **Soul Seize** (Soul Formation and above; Soul-Piercing if you know the scroll's art) |
| **Ctrl+H** | **Qi Burst Escape** (Foundation and above) |
| **V** | *[Domain Expansion](#domain-expansion)* (in a clash: push) |
| **Shift+V** | Raise or lower a **Qi Ward** |
| **B** | Your domain's **signature art**, or **Domain Amplification** when no domain stands |
| **O** | **Mission Journal** |
| **U** | Missions window: full / compact / hidden |
| **Shift+U** | Show or hide beast nests in the Missions window |
| **N** | **Live sect map** |
| **J** | *[Companion Beasts](#companion-beasts)* screen |
| **R** | Your nearest companion beast casts a spell at what you look at |
| **K** | *[Mastery](#mastery)* of your techniques and spells |

In conversations, keys **1–9** pick a choice, **Enter** takes the first, **Space** finishes the text and **Esc** closes.

### Commands for everyone

| Command | What it does |
|---|---|
| `/sectcity` | About the settlement you stand in |
| `/sectcity nearest [any\|village\|town\|city\|castle]` | The nearest settlements, with their kingdoms and rulers |
| `/sectcity find <place>` | Inns, the arena, the castle, the House of Fortune and other places in the town you're in |
| `/sectcity list` | Settlements you have visited |
| `/sectfellow ...` | Invite, accept, leave and other actions for player members of a sect |
| `/sectstore` | Open the Sect Storehouse near your headquarters |
| `/sectreport [0-7]` | Reopen one of your sect's last eight battle reports |
| `/sectmissions nests [show\|hide]` | Show or hide beast nests in the Missions window |
| `/sectdomain expand \| ward \| art \| amplify \| form \| element [e] \| info` | Domain Expansion |
| `/dantian`, `/dantian burst`, `/dantian seize` | Dantian World, Qi Burst Escape, Soul Seize |
| `/daopath` | Your Dao Path |
| `/sectwards [on\|off\|fee <n>\|rings <outer> <inner> <core>]` | Wards around your sect's headquarters (sect master) |
| `/sectbranch`, `/sectbranch found` | Branch clan estates |
| `/sectreservoir` | Show the reservoir settings |
| `/harshworld` | Show the harsh-world settings |
| `/sectbet` | Bet on a bout in the arena you're watching |
| `/sectauction`, `/sectduel` | Bid at a travelling auction on the road, or join a side in a duel between two sects' disciples |
| `/secttoll pay`, `/secttoll leave` | Pay a sect gate's toll, or turn back |
| `/sectkingdom`, `/sectvillage` | Your standing with the kingdom, and the settlement you're in |

### Commands for operators

| Command | What it does |
|---|---|
| `/sectcity tp <x> <z>` | Go to the south gate of a settlement |
| `/sectrealm <player> <realm> [early\|middle\|late\|peak]` | Set a player's cultivation realm |
| `/sectgrotto protection <FULL\|SURFACE\|OWNERS\|OFF>` | Spirit vein grotto protection |
| `/sectreservoir conversion\|rate\|siege\|worth\|veins\|regen ...` | Reservoir settings (saved to the config) |
| `/harshworld on\|off\|speed\|breakthrough\|predators\|prices\|chests ...` | Harsh-world settings (saved to the config) |
| `/sectinvasion now` | Send a demonic invasion against your sect now |

## Server Settings

The settings live in `<world>/serverconfig/xiaoxiang_sects-server.toml`. Edit the file with the world closed, or use the in-game commands, which save to it. The Beast Tide Almanac's spawn settings are saved with the world instead (see [Beast Tide Almanac](#beast-tide-almanac)).

### `[harsh_world]`

| Key | Default | What it does |
|---|---|---|
| `enabled` | true | The whole harsh world on or off (every value below applies only while on) |
| `cultivation_speed` | 0.5 | Multiplier on cultivation from absorbing qi and meditating |
| `breakthrough_penalty` | 15 | Percentage points off every breakthrough chance (never below 1%) |
| `realm_gap_damage_up` | 0.4 | Extra damage per great realm when the stronger strikes the weaker (up to ×4) |
| `realm_gap_damage_down` | 0.7 | Damage kept per great realm when the weaker strikes the stronger (never below 15%) |
| `realm_pressure` | true | The aura of cultivators two or more realms above you slows and weakens you |
| `predator_chance` | 20 | % chance a far stronger loose cultivator in the wilds preys on you |
| `price_multiplier` | 1.5 | Price of cultivation goods in the addon's shops and counters |
| `technique_rarity` | 0.35 | How often wandering cultivators still carry spell books and manuals |
| `teaching_regard` | 90 | Regard a wandering cultivator needs before teaching you an art |
| `chest_loot_keep` | 0.4 | Chance a stack of cultivation goods in a chest is kept (kept stacks are halved) |

### `[wild_scaling]`

| Key | Default | What it does |
|---|---|---|
| `enabled` | true | Match wild spawns to the nearest player's realm |
| `realms_above_player` | 1 | How far above you a wild demon beast may be |
| `boss_min_realm` | 2 | Realm needed before boss-rank beasts roam near you (2 = Foundation) |
| `unmatched_beyond_blocks` | 10000 | Beyond this distance from spawn the wilds are not matched (0 = matched everywhere) |
| `natural_max_health` | 60 | Health limit on other mods' natural monster spawns near a Mortal or Qi Refining player |
| `natural_health_growth` | 2.5 | How much that limit grows per great realm |

### `[reservoir]`

| Key | Default | What it does |
|---|---|---|
| `vein_core_conversion` | `SNEAK_USE` | `OFF`, `SNEAK_USE` (sneak + empty-hand right-click) or `ALWAYS` |
| `peace_rate_percent` | 10 | Refill per second in peace, % of the core's maximum |
| `siege_rate_multiplier` | 2.0 | Multiplier on the refill speed under attack |
| `stone_worth_multiplier` | 2.0 | Qi per stone (and per treasury stone), as a multiple |
| `draw_from_vein_cores` | true | Draw on nearby Spirit Vein Cores before using stones |
| `passive_qi_per_second` | 20 | Qi a reservoir gathers by itself each second |
| `passive_qi_per_tier` | 40 | Extra passive qi per tier of the vein core it came from |
| `passive_qi_cap` | 50000 | Most passive qi it keeps banked |

### `[spirit_vein_grottos]` and `[beasts]`

| Key | Default | What it does |
|---|---|---|
| `protection` | `SURFACE` | `FULL` (grotto and the land above), `SURFACE` (only the grotto, its stair and gate), `OWNERS` (as SURFACE, and the owning sect's leaders may build inside) or `OFF` |
| `roster` | `MYTHS` | `MYTHS`: only the Mountains-and-Seas beasts, with the great evils only at the altar or their omens. `ALL`: every Threateningly Mobs creature |

## FAQ and Known Limitations

**Where do I find spirit stones?**
Caves (ore and chests), slain beasts, bounties, missions, miners, veins, vassals, tributes, trade and the money changers. They don't generate as ore in the open world.

**Everything is too hard / too easy.**
The harsh world is on by default. Ease it with `/harshworld speed 0.75` and `/harshworld predators 10`, or turn it off with `/harshworld off`. Wild spawns are matched to your strength by `[wild_scaling]`.

**I keep getting one-shot at the start.**
Make sure `[wild_scaling] enabled = true`. Within 10,000 blocks of spawn, wild beasts stay within one realm of the strongest player near them, and bosses wait until Foundation. Structures, nests, tides and realms are not matched.

**My array runs out of stones.**
From 1.0.147 a reservoir pays an array's running cost for free and spends stones only to repair damage. Keep Spirit Vein Cores in its reach for free qi.

**Placing a Spirit Vein Core turned it into a reservoir.**
That was the old behaviour. From 1.0.141, conversion happens only on a sneaking, empty-handed right-click (or never, with `vein_core_conversion = OFF`). Sneak + right-click a reservoir to turn it back.

**My alchemy core, refining core or formation plate does nothing.**
Every craft goes through a minigame. Choose the recipe, press the core's button, then play.

**I can't enter a clan estate.**
Its array lets through anyone the clan doesn't count as an enemy (regard above −15). The rings inside ask fees and regard.

**The game lags when new land loads.**
Freezes marked `Qingqiu region … planned … urgent=true` in the log come from Xiaoxiang Cultivation World planning its fox-spirit lands in brand-new terrain. They're worst after a long teleport into unexplored land, and the addon can't change them.

**Do I need a new world?**
Strongly recommended. Caves, settlements, wards, clan estates, sect arrays, grottos and realms appear only in newly generated land. Settlements already recorded keep their old layout so the built parts still match.

**Something crashed.**
Send `latest.log` (or the crash report).

### Known limitations

- **Interrupted battles:** a bout, tide, siege, raid or minigame interrupted by a restart ends quietly. A bout replays, and the materials for an unfinished craft are returned.
- **Online only:** bounty hunters, sieges, invasions and kidnappings need the player online.
- **Main mod updates:** if the main mod changes code a hook relies on, that hook switches off quietly. Report it so the addon can be updated.
- **Inner Heaven:** the old Inner Heaven island (1.0.124–1.0.127) is retired. Its treasures moved into the Dantian World.

## Version History

| Versions | Highlights |
|---|---|
| 1.0.10 – 1.0.30 | Caves, demon beasts, beast tides, the almanac, generated sects, player sects, buildings, relations, tournaments, companions, the bounty board, secret realms, spirit veins, sect life, the Scripture Pagoda, sieges and vassals, minigames, ancient battlefields |
| 1.0.31 – 1.0.97 | The mortal kingdoms and their cities, coins and games; Dao Paths; mastery; foundation quality and the Paths to Ascension; the great breakthroughs and the immortal road; heart demons; working sect buildings and production; disciple crafts, merit and orders; fellow players and tokens; the Sect Gate; demonic invasions; garrisons; the Wanted Board; honours; the Sect Domain |
| 1.0.98 – 1.0.102 | Beast tides lay real sieges; smarter defenders; beasts built like true demon beasts (zhenyuan, qi shield); great arts and flight |
| 1.0.103 – 1.0.120 | The Missions window and Mission Journal; thirty missions; honours; cinematic conversations; the Spirit-Stone Reservoir; bosses in phases; the alarm bell; battle reports; the sect map; the Elder Council; disciple bonds; beast nests and eggs; the Beast Chamber; flying mounts; world bosses; the beasts of the Mountains and Seas and the ten great evils |
| 1.0.121 – 1.0.123 | Domain Expansion: four forms, signature arts, clashes, barriers, mastery |
| 1.0.124 – 1.0.127 | The Inner Heaven world (since retired) |
| 1.0.128 – 1.0.130 | The Dantian World and the Soul Sea; crafted Dao seeds; the dark jade and gold interface |
| 1.0.131 – 1.0.136 | Generated sects keep their arrays like you do; strong and weak lands; specialities and the Holy Sects; clans of craft and their estates; sect pavilions |
| 1.0.137 – 1.0.140 | Town wards and the underworld; ringed clan estates; clan rivalries, trials, heirlooms, succession and marriage; Holy Sect fairs; vassal clans and sieges; sect wards; branch estates |
| 1.0.141 | The reservoir made configurable and renewable |
| 1.0.142 – 1.0.143 | The harsh world, and harsh loot chests |
| 1.0.144 | Lag fixes; the jade slip on its own thread |
| 1.0.145 | Room along ward walls; real clan protection arrays |
| 1.0.146 | Wild spawns matched to the nearest player |
| 1.0.147 | Running an array is free; stones only repair damage; better stones last longer |
| 1.0.148 | Fixed: sealed and open domains can be unfolded again from Nascent Soul and Mahayana |

## Credits and Disclaimer

**I do not own anything.** Xiaoxiang Sects Expanded is an unofficial, fan-made addon. I claim no copyright and no credit for the mods it builds on.

- **Xiaoxiang Cultivation World:** all credit to the main mod and its author. Everything this addon adds is built on their work. The addon needs the original, unmodified mod and doesn't include or redistribute any of its files.
- **Threateningly Mobs:** all credit to its author. Its creatures, models and textures are its own. This addon only changes how they spawn and fight, and doesn't include its files.
- **Domains:** the idea of a domain was inspired by JujutsuCraft's domain expansion. None of its code, models or textures is used.
- **Not affiliated:** this addon isn't affiliated with or endorsed by any of those mods' authors, Mojang or Microsoft. Minecraft is a trademark of Mojang Studios.

**If anything has to be removed, I will remove it.** If the author of any of these mods asks for this addon, or any part of it, to be taken down or changed, it will be done. Please download Xiaoxiang Cultivation World and Threateningly Mobs from their official pages to support their creators.

## The Harsh World

Cultivation is hard, the means to it are scarce, and the strong rule the weak. **On by default.** Every part can be tuned under `[harsh_world]` (see [Server Settings](#server-settings)) or live with `/harshworld` (operators).

### Cultivating is slow

- **Half speed:** cultivation from absorbing qi and meditating is halved (`cultivation_speed` 0.5). Pills are not affected.
- **Breakthroughs:** every breakthrough chance loses 15 percentage points (never below 1%). Guaranteed breakthroughs are unaffected.
- **The cultivation mod's own difficulty** (Easy, Normal, Hard or Inferno) stacks with all of this.

### Resources and techniques are earned

- **Prices:** cultivation goods cost ×1.5 in every addon shop, pavilion, clan counter and back room. Mortal goods are unchanged.
- **Techniques:** wandering cultivators carry spell books and technique manuals only 35% as often, one at a time. They teach you one of their arts only at **90 regard**.
- **Chests:** in every chest loot table of the world, each stack of cultivation goods is kept only 40% of the time and halved. Spell books and manuals are kept at the technique rarity. Mortal loot is untouched, and so are earned rewards (secret realm spoils, boss drops, quests, bounties, heirlooms). Generated sects' storehouses are thinned the same way.
- **Breakthrough materials** (Foundation and Golden Core) are always scarce, harsh world or not:
  - The Dao Foundation Fruit and Foundation Secret are not found in ordinary chests.
  - Sect storehouses keep at most one of a kind.
  - Wandering cultivators rarely carry them, and sell them at four times the price.

### The strong rule the weak

- **Realm suppression:** in a fight between cultivators (players and cultivator NPCs):
  - the stronger one's blows hit the weaker **+40% per great realm** of difference, up to ×4;
  - the weaker one's blows on the stronger keep **70% per great realm** (70%, 49%, 34%…), never below 15%.
- **Realm pressure:** within 14 blocks of a cultivator two or more great realms above you, their aura gives you Slowness and Weakness (Mining Fatigue at three realms or more). Your own sect's people never press on you.
- **Predators:** a **loose** cultivator two or more great realms above you, met in the wilds, may decide you are prey: 20%, more if they dislike you, less if they like you. Each checks once every 10 minutes. They either:
  - **demand your spirit stones:** sneak within 10 seconds to kneel and pay a third of what you carry, or they attack; or
  - **attack outright.**
- **No predators** inside town walls, clan estates or your own sect's grounds. Townsfolk, clan folk, sect members, avengers and examiners never prey on you.

### The wilds are matched to you

Creatures that spawn by themselves are matched to the **strongest player within 128 blocks**. Settings are under `[wild_scaling]`.

- **Demon beasts:** a wild demon beast is at most **one great realm above** that player. A Mortal or Qi Refining player meets Qi Refining and Foundation beasts.
- **Bosses:** boss-rank beasts roam only near players of **Foundation** or higher.
- **Other monsters** (other mods' and the cultivation mod's own) spawning naturally near a Mortal or Qi Refining player may have at most **60 health**. The limit grows ×2.5 with each great realm. Vanilla monsters are never affected.
- **Full danger stays** in structures, nests, beast tides, warbands, secret realms, at the Demon-Sealing Altar, and **beyond 10,000 blocks** from the world spawn.

## Dao Paths

The first time you draw qi into your body, a golden wheel of the four Daos spins on your screen and the heavens choose your **Path**. Open it with the **☯ Dao Path** button on the cultivation menu (G) or `/daopath`.

| Path | Odds | Grows by | Perks per rank |
|---|---|---|---|
| ⚔ **Sword** | 30% | dealing damage with a sword | +5% sword damage per rank; from Master, sword qi may strike again (10%, ×1.5) |
| ⚗ **Pill** | 25% | taking pills, and your sect refining them | pills also heal you (and shield you from Adept); your sect's alchemists make double pills more often |
| 🜂 **Body** | 30% | fighting bare-handed and taking blows | +2 max health and −3% damage taken per rank; bare-handed blows +6% per rank |
| ☠ **Demonic** | 15% | slaying cultivators | 3% lifesteal per rank, harder blows at night. Righteous sects are hostile on sight, and heart demons always come |

### Ranks

| Rank | Experience | Sword | Pill | Body | Demonic |
|---|---|---|---|---|---|
| 1 | 0 | Sword Novice | Pill Novice | Body Tempering | Demonic Novice |
| 2 | 300 | Sword Adept | Pill Adept | Iron Body | Blood Fiend |
| 3 | 1,200 | Sword Master | Pill Master | Bronze Skin | Demon Lord |
| 4 | 3,500 | Sword Saint | Pill Saint | Vajra Body | Demon Saint |
| 5 | 9,000 | Sword Sovereign | Pill Sovereign | Immortal Body | Demon Sovereign |

- **Your title** is shown before your name, and wandering cultivators greet a famous name.
- **Path insight** also comes from clan services, Holy Sect teachings and sect pavilions that match your path.
- **Paths also matter** for the craft minigames (a fitting path makes them a little easier).

## Mastery

Every technique and spell you know has its own **mastery**. Open the Mastery screen with **K**.

| Level | Experience | Spell damage | Spell qi cost | Technique bonuses |
|---|---|---|---|---|
| Novice | 0 | ×1.00 | ×1.00 | ×1.00 |
| Adept | 500 | ×1.05 | ×0.96 | ×1.05 |
| Expert | 2,000 | ×1.10 | ×0.92 | ×1.10 |
| Master | 6,000 | ×1.16 | ×0.88 | ×1.16 |
| Grandmaster | 15,000 | ×1.25 | ×0.80 | ×1.25 |

- **Gaining mastery:**
  - slowly with use: each spell cast, and each stretch of combat with a technique circulating;
  - far faster by slaying cultivating creatures: more for stronger ones, little for those far below you.
- **Bottlenecks:** each level is capped until you break through it. Press **Break Through** on the Mastery screen to play a breakthrough minigame. You need 65%, or 80% for Grandmaster. A failure leaves your mind unsettled for a while.
- **Disciples** have mastery too: +4% damage per level from Adept.

## Breakthroughs and Foundation

### Consolidation

After every stage you rise, a **breakthrough consolidation** minigame opens: steer the surging qi orb and keep it inside the shrinking circle.

- **80% or more:** +3% cultivation, plus Strength and Regeneration for 5 minutes.
- **50% or more:** +1%.
- **Below 50%:** qi deviation (weakened and slowed).

### Foundation quality

How cleanly you consolidated each breakthrough, together with the grade of your Foundation and Golden Core Daos, gives your **foundation quality** (0–100).

| Grade | Quality |
|---|---|
| Cracked | below 25 |
| Common | 25–44 |
| Solid | 45–59 |
| Superior | 60–74 |
| Flawless | 75–89 |
| Heavenly | 90+ |

A sound foundation:

- adds up to **+10 points** to every breakthrough chance;
- softens tribulation lightning (up to −40%);
- makes the main mod's inner-world trials easier (up to −25% damage taken, +25% dealt);
- makes consolidation gentler and pays more cultivation from it.

### Heart demons and old age

- **Heart demons:** after a major breakthrough from Foundation on, a heart demon may take form (45%, always on the Demonic Path). It's a mirror of you, with your realm, weapon and armour, and it pulls you into your **Soul Sea**.
  - **Slay it within 3 minutes:** your Dao heart steadies (Strength, Regeneration, a surge of cultivation, Path experience).
  - **Fail, die or flee:** this realm's progress is lost and you're weakened for a while.
- **Old age:** as your bone age nears your lifespan, your body grows frail. Weakness comes from three quarters of your lifespan; Slowness and Mining Fatigue in its last tenth. Each major breakthrough announces your new lifespan. **Youth Pills** push it back (refined by Master alchemists, found in inheritances and auctions).

### The Paths to Ascension

The means to break through are jealously kept. The **⛩ Ascension** button on the cultivation menu (G) lists every road to Foundation manuals, Dao Foundation Fruits, Zhuji and Jiedan pills and Golden Core materials:

| Road | What it asks |
|---|---|
| Your sect's **Scripture Pavilion** | Contribution earned in your sect |
| The **sect trial** | Once per realm, 100 contribution and a hard consolidation before the elders (70%+) |
| **A master's teaching** | A cultivator two realms above you (Golden Core at least) who holds you in high regard, and 500◆ |
| **An ally's exchange** | An allied or vassal sect trades a foundation method for 4,000◆ and 5 prestige |
| **Comprehension under the storm** | Sneak still for a minute on a high summit (y 120+, open sky) in a thunderstorm. Once a day; insight is rare |
| **The alchemist's elixir** | Alchemy rank 5+: 24 spirit herbs, 3 high spirit stones and a hard refining |
| **Other roads** | Clan adoption, the royal grant, the arena, scripture theft, caravan auctions, boss beasts, evil cultivators, secret realms, ancient ruins and abandoned caves |

### The great breakthroughs

Beyond Golden Core, no cultivator crosses a major realm on qi alone. At the peak of each realm from Golden Core to Tribulation Transcendence, the breakthrough asks a price, paid once when the attempt begins. A failed tribulation can be tried again without paying twice.

| Crossing from | Ascension Seals | Beast Soul Orbs | Spirit stones |
|---|---|---|---|
| Golden Core | 1 | 2 | 8 high |
| Nascent Soul | 2 | 4 | 4 supreme |
| Soul Formation | 3 | 6 | 8 supreme |
| Void Refining | 4 | 8 | 16 supreme |
| Body Integration | 5 | 10 | 32 supreme |
| Mahayana | 6 | 12 | 64 supreme |
| Tribulation Transcendence | 7 | 14 | 64 supreme |

- **Ascension Seals** are never found, only bought: the crown's **Seal Office** sells one a day (6,000◆) to a Knight of the Realm or higher.
- **Beast Soul Orbs** are cut from great beasts: great evils, world bosses and other mighty beasts.

### The immortal road

The cultivation mod lists the immortal realms but opens no breakthrough into them yet. The addon opens its own road from **Earth Immortal**, through Heavenly, Perfected, Mystic, Golden, Taiyi Golden and Daluo Golden Immortal.

- **After Daluo** the road forks: the **Saint path** (Quasi-Saint, Saint, Dao Ancestor) or the **Hunyuan path** (Hunyuan Golden Immortal, Hunyuan Daluo, Hunyuan Wuji Daluo). Both end at **Great Dao Saint**.
- **Each ascension asks for** Ascension Seals, Beast Soul Orbs and spirit stones, all growing with each step (4,000 × step² stones), plus **Immortal Resonance**.
- **Immortal Resonance** comes from clearing **Immortal Resonance** gates: S-Rank secret realms drawn into resonance when an immortal is within 256 blocks.

## Dantian World and Soul Sea

### 丹田世界 The Dantian World

Your own body as a world. Open it with **H** or the **☯ Dantian World** button on the cultivation menu. It has four tabs.

**Meridians (经脉)**

- **The map:** your body with **24 acupoints** along its meridians, including the three dantians, the Sea of Qi, the Gate of Life and the Niwan Palace.
- **Meridian points:** you have 2 at Qi Refining, and earn **one for every stage and great realm** you break through.
- **Opening a point:** click a glowing point next to an open one to force your qi through it. It costs 1 point and 20% of your qi. Some points need a higher realm.
- **Every open point is a permanent gift:** qi recovery, cultivation speed, max health, attack, armour, speed, attack speed, luck, soul strength, Dantian Guard strength, Dao seed growth, extra storage or an extra Dao seed slot.

**Storage (丹田)**

- **Never lost on death:** items kept inside you.
- **Size:** 9 slots per great realm (up to 54), plus 9 when the **Spirit Gate** opens.
- **Anywhere:** the **Dantian Talisman** opens it from anywhere (recipe: eye of ender / gold ingot, paper, gold ingot / amethyst shard).

**Dao Seeds (道种)**

- **Planting:** plant crafted Dao seeds in your dantian's lotus pods. Seed slots: 1 at Foundation, rising to 5 at Mahayana, plus 1 from the Niwan Palace.
- **Growing:** they grow while you're online (twice as fast meditating), drinking a little of your qi, through 5 levels, each a permanent gift.
- **Grades:** Lesser seeds grow to level 2, Greater to 4 and Supreme to 5. Click a planted seed with a higher grade of the same kind to **refine** it.
- **Uprooting:** shift-click a seed to uproot it. Its gifts are lost.

| Seed | Per level | Lesser material | Greater material | Supreme material |
|---|---|---|---|---|
| Sword | +1 attack | iron swords | diamond swords | netherite ingots |
| Vajra | +1 armour | obsidian | diamond blocks | ancient debris |
| Life | +2 max health | golden apples | earth marrow ginseng | enchanted golden apples |
| Wind | +3% speed | phantom membranes | wind feather grass | dragon's breath |
| Thunder | +4% attack speed | lightning rods | tridents | end crystals |
| Spirit | +4% cultivation speed | low cultivation pills | high cultivation pills | immortal cultivation pills |
| Tide | +1 qi recovery | prismarine crystals | nautilus shells | hearts of the sea |
| Fortune | +1 luck | emeralds | emerald blocks | totems of undying |
| Soul | +1 soul strength | echo shards | snow soul lotus | void crystals |

The recipes are in [Items and Recipes](#items-and-recipes). Possessing souls you slay leave a Lesser Soul Seed.

**Guard & Arts (护元)**

- **The Dantian Guard:** from Foundation, a ward of your own qi around your dantian, always on.
  - **Strength:** 300, +250 per great realm, plus what your open points and Soul Seeds add.
  - **Refills** 1% a second for 1% of your qi.
  - **Pills recharge it:** low 10%, mid 20%, high 35%, supreme 60%, immortal 100%. Immortal pills also **temper** it +10%, up to +50%.
- **Soul arts:** each art's key and its status (Ready, cooldown or Locked).
- **Domain arts:** element, form, Amplification and Qi Ward (see [Domain Expansion](#domain-expansion)).

### 识海 The Soul Sea

Battles of the soul are fought on a dark platform under a starry heaven, around your **Dantian Core**. **No one dies in a soul sea:** whoever falls is defeated and carried out with a **wounded soul** (Weakness for 10 minutes and a fifth of this realm's progress lost).

| Art | Key | Needs | What it does |
|---|---|---|---|
| **Soul Seize** 摄魂入识 | Shift+H | Soul Formation | Drag the foe you look at into your soul sea for 2 minutes, where you're strong and they're weak. 35% qi, 10-minute cooldown. Higher realms and strong souls may resist |
| **Soul-Piercing** 穿识 | Shift+H | Nascent Soul + the scroll | Soul Seize on a **weaker cultivator** tears into *their* soul sea: break their Dantian Guard, then strike their Core in time to **shatter their dantian** |
| **Qi Burst Escape** 爆气遁 | Ctrl+H | Foundation | Your qi bursts out, flinging foes back and you away with brief Invisibility, Speed, Resistance and Slow Falling. 15% qi; a foe's sealed domain stops it |

- **The Scroll of Soul-Piercing:** recipe eye of ender, amethyst shard, eye of ender / amethyst shard, book, amethyst shard / eye of ender, echo shard, eye of ender. Great evils sometimes drop one.
- **They can do it to you:** great evils, world bosses and some Soul Formation cultivators who know Soul-Piercing and are stronger than you may tear into your soul sea mid-fight. A strong soul makes it less likely.
- **Defending your dantian:** intruders must break your guard in time, or they're cast out. If your Core falls, **your dantian is shattered:** you drop 3 realms, cultivation slows, and breakthroughs get harder. Heal it with one immortal-grade pill, or three supreme-grade pills a step at a time.
- **Soul invasions 夺舍:** on rare nights (at most once per 2 days, from Foundation), a possessing soul tries to take your body. Slay it to absorb its essence. If your guard holds, it is driven out; if it outlasts you while your guard is broken, your soul is wounded.

## Domain Expansion

**领域展开.** A cultivator unfolds their inner world over the outer one for a short while. Every foe inside is struck each second by an attack that cannot miss, and you are strengthened (Strength II, Resistance, Regeneration and Speed). Press **V**; the right form is chosen for you.

### Forms

| Form | Who | What it is |
|---|---|---|
| **Incomplete** 领域·未成 | Golden Core | No barrier, radius 7, 12 s, sure-hit at half strength, 25% qi |
| **Sealed** | Nascent Soul | A barrier no foe can leave or enter: radius 10 at Nascent Soul, up to 20; 20 s, up to 60 s |
| **Open** | Mahayana | No walls at all, but vast: radius 28–40, 40 s, 40% qi. Toggle sealed / open on the domain page |
| **Sect domain** 宗门领域 | A sect leader (Golden Core+) on their own grounds while the sect is under attack | Spreads over the whole protection array (up to radius 64) for 45 s. The array pays: 25% of its qi to raise it, 1% a second to hold it. Strikes only what threatens the sect |

Foes of a **higher realm** take half the damage for each realm above you. Your sect, disciples, allies and tamed beasts are never struck, and they pass freely through your barrier.

### Eight domains, one per element of your spirit root

Choose among your root's elements on the domain page or with `/sectdomain element <element>`.

| Element | Domain | Each second | Signature art (B) |
|---|---|---|---|
| Metal | Ten Thousand Swords 万剑归宗 | armour-piercing sword rain, +15% | Sword Storm: sword rain and a sky-splitting aura |
| Wood | Endless Verdant Forest 万木森罗 | rooted and poisoned | Ten Thousand Thorns: Verdant Bind |
| Water | Boundless Abyssal Sea 沧海无涯 | slowed, breath runs out | Great Flood: Water Prison |
| Fire | Burning Sky Inferno 焚天炎狱 | set ablaze | Falling Sun: meteors on every foe |
| Earth | Mountain-Suppressing Prison 镇岳山牢 | pressed down, can't jump | The Mountain Falls: Heaven-Piercing cone and stone hail |
| Ice | Eternal Frost 万古玄冰 | frozen solid | Absolute Zero: 8 ice swords and a Heaven-Piercing cone |
| Lightning | Nine Heavens Thunder Prison 九霄雷狱 | a thunderbolt every 3 s (×1.6) | Heavenly Tribulation: triple palm thunder |
| Pure | Void of Stillness 寂灭虚空 | weakened, qi drains away | Annihilation: meteors and a mega sword aura |

On the **Sword Path**, the domain becomes the **Heaven-Splitting Sword Domain** 斩天剑域: its art is three mega sky-splitting sword auras on every foe, then a rain of 10 flying swords. The signature arts cast the main mod's own spells, scaled up, once each time you unfold.

### Defence and counterplay

- **Qi Ward** 护体结界 (Shift+V, Foundation): a domain's sure-hit can't touch you while it holds. It drains 1.5% of your qi a second.
- **Domain Amplification** 领域增幅 (B with no domain, Golden Core): your blows strip blessings, shatter Qi Wards and drain a cultivator's qi. Arts and sure-hits strike you at half force. It drains 1.2% qi a second.
- **Clashes:** when two domains overlap, a **6-second contest of will** begins. Mash **V** to push. The higher realm leans on the weaker by itself. The loser's domain shatters and they're burnt out for 45 s.
- **Breaking a barrier from outside:** a sealed barrier has integrity (60 + 30 per realm). Strike it, or hit it with arrows or spells. At zero it shatters and its master is burnt out for a minute.

### When it falls

A domain ends when its time runs out, or early if you step outside it, lose 45% of your health, fall, or lose a clash. You're then **burnt out** for 30 s (Weakness and Slowness), and your inner world needs 3 minutes to settle. Every block the barrier covered is put back exactly as it was, even after a crash.

### Domain mastery

- **Gaining it:** mastery (0–10, Unformed to **Absolute**) grows with every domain unfolded and every foe slain inside one.
- **Each rank:** −4% cost, +2 s duration, +3% strength and −10 s cooldown.

### Others who unfold domains

- **Your elders:** Elders and Grand Elders of Nascent Soul or above unfold sealed domains when the sect is hard pressed (under the Fight order, at most once every 10 minutes).
- **Great evils** unfold one below half health.
- **Tide Lords, Siege Marshals and world bosses** unfold one in phase III.

## The Mortal Kingdoms

Vanilla villages and villagers are gone. The world holds the walled **villages, towns and capitals** of the mortal kingdoms, hundreds of blocks across, each ruled by a cultivation clan (a capital by its mortal **king**, from his palace).

### Settlements

| Size | Across | Ruled by | What's inside |
|---|---|---|---|
| **Village** | about 220 blocks | a clan | fields, homes, shops, an inn, a shrine |
| **Town** | about 330 blocks | a clan | markets, guild halls, smithies, martial halls, an arena, inns and restaurants |
| **Capital** (City) | about 510 blocks | the King, from his palace | everything a town has, plus the royal palace, the royal guard, the bank and the House of Fortune |

- **Where:** each region of 1,280 blocks may hold one settlement (85% do), worked out from the world seed and the terrain, so the same world always has the same towns.
- **Kingdoms:** there are 20 (Wei, Zhao, Qin, Chu, Yan and the rest), and 14 ruling clans (Lin, Xiao, Mu, Ye, Su, Gu, Bai, Feng, Long, Yun, Jiang, Tang, Han and Qin).
- **Its people are mortals:** shopkeepers, cooks, innkeepers, smiths, farmers, martial artists, the gate guard, sentries on the towers and the watch patrolling the streets. They go home at night. Only the clans cultivate.
- **Appearing and replacing:** people appear a district at a time as you approach. Anyone who dies is replaced at dawn.
- **The town guard** looses arrows at monsters, wild beasts, beast tides and bandits within bowshot, and at anything attacking a townsman. Their arrows never hit townsfolk.
- **Finding them:** `/sectcity nearest`, the Jade Waypoint Slip (creative) and the lecterns in every town, which are notice boards that tell you where everything is.

### Strong and weak lands

Every kingdom has a **power** and every settlement a **might**, fixed by the world seed.

| Kingdom power | Share | Effect |
|---|---|---|
| Fallen | ~12% | pulls its towns down one step; its royal guard is few and weak |
| Minor | ~25% | |
| Middling | ~33% | |
| Great | ~20% | lifts its towns up one step |
| Imperial | ~10% | lifts its towns up one step; its royal guard is among the strongest anywhere |

| Might | Toll | Tribute | Patriarch | Town watch | Bandit raid chance | Built of |
|---|---|---|---|---|---|---|
| **Struggling** | ×0.5 | ×0.5 | Qi Refining | leather, stone blades | 30% | wattle-and-daub, holed shingle roofs, a log palisade, dirt paths, cobwebs |
| **Humble** | ×0.75 | ×0.75 | Qi Refining | chainmail cap | 24% | plaster on cobble, rubble walls |
| **Thriving** | ×1 | ×1 | Foundation | iron | 18% | the town's own style |
| **Prosperous** | ×1.5 | ×1.4 | Golden Core | iron, Strength II | 12% | lime plaster on polished deepslate, polished roads |
| **Mighty** | ×2.5 | ×2 | Golden Core (Nascent Soul in a capital) | diamond helm and blade, Resistance | 6% | marble terraces, red-lacquered pillars, glazed copper roofs, blackstone walls with gilded veins |

- **What sets might:** villages lean weak and towns lean middling. A capital follows its kingdom.
- **Holy Sects:** a settlement within 1,600 blocks of a Holy Sect gains +1 might, and its market stocks that sect's goods.
- **Trades:** a struggling settlement is always a farming village; a mighty one is never a farming town.
- **The gate sign** shows the real toll, and arriving tells you the kind of place and its kingdom's power.

### Favour with a kingdom

Your **favour** is kept per kingdom. It rises with gifts to the king, royal commissions, guild contracts, guarding the town, beating riots and more.

| Title | Favour | Gift |
|---|---|---|
| Commoner | below 10 | |
| **Royal Guest** | 10 | pass every gate of the kingdom without toll (and the outer ring) |
| **Knight of the Realm** | 40 | 10% off in the kingdom's shops; pass the inner ring free; the Seal Office sells you an **Ascension Seal** (6,000◆, one a day) |
| **Marquis** | 100 | 20% off; a daily **stipend** of 60 + 60 × size ◆; received in the palace; may petition for the crown's **foundation manual** (1,500◆, once) |
| **Duke** | 250 | may petition for a **Dao Foundation Fruit** (3,000◆, once) |

**At the palace:**

- **Present a gift:** +10 favour, three a day at most.
- **A royal commission:** a task for stones and favour, finished within two days.
- **Duel the King's Champion:** win for +20 favour and a purse.
- **The guard's trial:** defeat one of the royal guard in two minutes for +5 favour and 60◆, once a day.

### Your sect and the towns

A Sect Master can deal with a settlement's ruler:

- **Offer protection:** the town pays your sect a daily **tribute**, and you defend it from bandit raids (the raid chance depends on its might). Your sect enters without toll.
- **Demand surrender:** defeat the ruling clan's cultivators (in a capital, the royal guard and the ruling clan) within 10 minutes. You get **double tribute**, but restless subjects: a conquered town may **rise in rebellion** unless it is held.
- **Garrison:** station disciples who came with you. They keep the gates, the plaza and (in a capital) the castle bridge, fighting beside the town guard. A garrison keeps a conquered town from rising, steadies a protected one, and drives off bandit raids even while you're away.
- **When the cultivation mod's demon sieges** strike a town, the kingdom rewards its defenders and mourns a fallen town.

## Town Wards and the Underworld

Settlements first reached from 1.0.137 on are divided by inner walls into three **wards**. From 1.0.145, every ward wall keeps a 3-block clear strip on both sides, and bends around great buildings (the palace, the arena, the clan seats) so they stand whole in one ward.

| Ward | Who may enter | Looks |
|---|---|---|
| **Slums** (outer 30%) | anyone | always built poorly; beggars, rag pickers, urchins and pickpockets |
| **Outer ring** | pay the daily **toll** (free for Royal Guests, or with a pass) | the town's own style |
| **Inner ring** | **merit:** 5 favour in a village, 15 in a town, 30 in a capital, **and** 4× the toll a day. Knights pass free | one step richer than the town |
| **Palace precinct** (capitals) | a **Marquis** | the royal palace |

- **Guards:** each gate on the avenues is kept by two guards. Strength rises toward the heart: the slums' guards and folk are one might step weaker than the town, the inner ring's one step stronger.
- **Trespassers** are warned, attacked after 30 seconds, then beaten and **thrown out** after a minute. Each throw-out adds **+10 notoriety**.
- **Old towns:** towns recorded before 1.0.137 keep no wards, and towns recorded before 1.0.145 keep the first ward layout, so the parts already built still match.

### The Rat King

Somewhere deep in every town's slums sits an **Old Beggar** with no name over his head: the **Rat King**.

| Option | Price | What it does |
|---|---|---|
| Forged toll pass | 2× toll | Passes the outer ring for 3 days. Once a day the guard may see through it (20%): torn up, −5 favour, +5 notoriety |
| Smuggled into the inner ring | 60% of the inner fee | Through the drains, for today. A 25% chance you're spotted (less with underworld standing): thrown out, −10 favour, +10 notoriety |
| What fell off the carts | | The back-room stash: shady goods a grade better than the town's, up to 30% off for friends of the gang |
| Pay your dues | 20◆ | +5 underworld standing |

**Underworld standing** is kept per kingdom.

### Slum riots

In struggling (15% a day) and humble (7% a day) warded towns, the slums may boil over while you're there. 7–10 rioters led by a **Riot Leader** pour out of a slum gate and fight the guards. A riot lasts 6 minutes.

- **Stand with the guards:** +2 favour and 15◆ per rioter slain (up to +12 favour); −3 underworld standing.
- **Join the riot** (talk to the leader): the guards come for you; −12 favour, +10 notoriety. If a third of the mob still stands at the end, you get 60◆ and +12 underworld standing.
- **Pay them to go home** (40◆): the riot breaks up peacefully, +4 favour.

### Wanted posters

Three throw-outs reach the bounty threshold: the posters go up and **bounty hunters** come for you. The customs house shows your record and lets you **pay your fines** (50–150◆ for −20 notoriety).

## Life in the Cities

### Shops and services

- **Shops** sell food, pills, herbs, arms, cloth and talisman supplies for spirit stones. A thin, normal or richer stock depends on the town's might.
- **The merchant guild** buys your goods. A **guild licence** gives 10% off in every shop of the kingdom.
- **The mercenary guild** posts bounties and contracts.
- **Inns:**
  - **Book a room:** your respawn point is set there, you wake with extra health, and at night you sleep till dawn.
  - **Meals:** a hot meal, spirit wine, or a feast for the house (+2 favour).
- **Martial halls:**
  - **A lesson** (10◆): Strength and Speed for 5 minutes.
  - **Sparring** with a clan disciple.
- **The customs house:** tolls, 7-day passes and fines.

### Coins and the economy

- **Coins:** mortals buy their bread, beds and bets with the cultivation mod's **copper coins** (文). Strings are 9 coppers and guan 81. One low spirit stone is worth about 10 coppers at the posted price.
- **Money changers** buy and sell spirit stones at a moving rate.
- **The capital's bank** keeps your coin savings.
- **Market stalls:** rent one for 7 days.
- **The Royal Transit** carries you between capitals.
- **Demonic cultivators** are refused service. A **Mortal Guise Talisman** lays a mortal's face over yours for half an hour, so the towns will serve you.

### Games and pastimes

| Where | Game |
|---|---|
| **House of Fortune** | **Dice:** bet Big, Small or a triple. **The cups:** find the pea. **Card tables:** Twenty-One (blackjack: hit, stand or double; the dealer draws to 17; a natural pays 3 to 2) and Five-Card Draw (ante, hold and draw once; better hands pay a bonus) |
| **Tea house** | The scholar's riddles |
| **Inn** | The drinking contest (10◆) |
| **Martial hall** | **Arm wrestling** (5◆ → 15◆), played live: press SPACE as the needle crosses the green, and counter his surges. The hall's strongest arm (20◆) pays 60◆ or more |
| **Archery range** | Shoot a round (8◆) |
| **Market** | Chase down pickpockets |
| **Arena** | Exhibition bouts with wagers, and the arena champion's challenge for a purse: Novice, Veteran and Grand Champion of the Ring |

## Clan Estates

Each clan of craft keeps its own **estate** out in the wilds, answering to no king and paying no toll.

### Where and what

- **Where:** estates sit on their own grid between the mortal settlements (about half the regions hold one), clear of every settlement and planned sect, on dry, level land.
- **Layout:** a walled square about **145 blocks across** in three rings (from 1.0.137; buildings keep 3 blocks from every ring wall from 1.0.145):

| Ring | Who lives there | Who may enter |
|---|---|---|
| **Outer court** | outer disciples and retainers: cottages, fields, stalls, a granary, barracks | a small daily fee (10–40◆ by standing), **free from 10 regard** |
| **Inner court** | inner disciples, and the **workshops of the clan's craft** run by the elders | **30 regard** and a daily fee (60–240◆) |
| **Main branch** | the ancestral manor, the **patriarch**, the elders and the main-branch guard | only the clan's own (adopted kin) or honoured friends with **60 regard** |

- **Walls and gates:** the outer wall has four corner towers and the great south gate. The inner and main-branch walls have gates on all four sides with gatekeepers.
- **Trespassers** are warned, attacked after 30 seconds and thrown out after a minute.
- **Standing:** Minor, Established, Great or Ancient.

| People | Minor | Ancient |
|---|---|---|
| Outer disciples | Qi Refining | Foundation |
| Inner disciples | Qi Refining | Golden Core |
| Main-branch guards | Foundation | Golden Core |
| Elders | Qi Refining | Nascent Soul |
| Patriarch | Foundation | Soul Formation |

### Crafts

Every clan keeps the same craft everywhere in the world. Each craft is held by two or three of the 14 clans, chosen by the world seed.

| Craft | Built in | Their people | Their service |
|---|---|---|---|
| **Pill-Refining** | copper-green roofs, mossy stone | Regeneration | **Refine your herbs:** herbs and a fee → a Cultivation Pill and a Qi Recovery Pill |
| **Body-Refining** | slate, andesite | fight bare-handed, Strength and Resistance | **Medicinal bath** (once a day): Health Boost and Resistance, Path of the Body insight |
| **Artifact-Refining** | blackstone, forge brick with magma inlay | refined swords and armour | **Repair all your gear** |
| **Talisman** | vermilion roofs, white calcite walls | Fire Resistance, Speed | **Protective ward:** Absorption and Fire Resistance |
| **Formation** | prismarine | Resistance | **Gathering array** (once a day): a qi spring |
| **Beast-Taming** | mangrove, a log palisade | Speed, and Clan Spirit Hounds | **Buy a tamed Spirit Hound** |

- **Using a service:** talk to the patriarch or an elder (sneak + right-click) for the clan's **counter** and its **service**. Prices scale with the clan's standing.
- **Earning regard:** **pay respects** to the patriarch (+4 regard). Offer incense at the shrine through any outer disciple (50◆, +4). Pass the time with retainers (+1 a day). Each paid service gives +1.

### The clan's protection array

Every estate keeps a **real protection array** (from 1.0.145):

- **What it is:** a Formation Core Plate on a lantern-lit dais in the main branch's courtyard, linked to a protection flag beneath the manor. The grade follows standing: low, mid, high or supreme.
- **Reach:** it covers the whole estate (104 blocks from its flag).
- **Upkeep:** the clan feeds it while anyone is near and raises it whenever it is down. If the plate is broken or the array shattered, the dome goes down and is not rebuilt.
- **Who passes:** players the clan doesn't hate (regard above −15), the clan's kin, creative players, every cultivator and welcome players' beasts. Monsters and the clan's enemies are blocked.
- **Monsters inside** are driven out and burned.

### Regard, adoption and the clan's affairs

- **Regard is kept per clan.** Whatever regard you win with a clan, its **rival** clan loses half as much.
- **Avengers:** a clan that hates you (−15 or worse) may send three **avengers** after you in the wilds. Slaying them earns regard with their rival.
- **Adoption** (60 regard and 1,500◆, after passing the clan's **trial**) makes you **kin**: all three rings, a third off services, 15% off the counter and no fees.

| Clan | Trial |
|---|---|
| Pill | present a mid-grade (or better) Cultivation Pill |
| Artifact | present a mid-grade (or better) refined blade |
| Talisman | present three inscribed talismans |
| Body | **the hundred blows:** stand a minute against two bare-fisted fighters (you can't die in it) |
| Beast | slay the clan's Wild Spirit Wolf within two minutes |
| Formation | answer three array riddles |

- **Heirlooms:** every Great or Ancient clan keeps one in its ancestral hall: Ancestral Elixirs, Blade, Vajra Armour, Brush, Array Flags or Beast Blood.
  - **Entrusted** to kin with 150 regard.
  - **Stealing it** makes you the clan's enemy, hunted daily.
  - **Raiders** come for it now and then; drive them off for regard and stones.
- **Succession:** when a patriarch dies, two elders claim the seat for a day. **Back one** (200◆): the winner's backers gain +40 regard.
- **Marriage pacts:** a sect leader with 80 regard can wed their sect to the clan (3,000◆). Every member of the sect counts as kin, and two inner disciples join the sect.
- **Vassals of the Holy Sects:** a clan within 1,600 blocks of a Holy Sect is its vassal. The Holy Sect sends three disciples when raiders or besiegers come.
- **Sieges:** a clan near a **demonic sect** may be besieged (3% a day while a player is there): a Siege Lord and nine Blood Raiders storm the gate.
  - **Defend the clan:** +15 regard and stones.
  - **Join the siege:** if it wins, you share the plunder and the heirloom is lost.

### Branch estates

A sect master who was adopted into a clan (or whose sect is wed to one) can found a **branch estate** with `/sectbranch found`.

- **Cost:** 20,000 stones from the treasury and six disciples.
- **Where:** on level, dry, loaded land at least 300 blocks from your headquarters, away from towns and estates.
- **How it rises:** a full ringed estate rises around you over a few seconds, run by the clan's people under your sect's name, with its own array.
- **Every day** it sends 150 stones and puts its craft's goods in the chest of its ancestral hall.

## Demon Beasts

Every Threateningly Mobs creature that appears is a **cultivating demon beast**: a realm, a nature, spells, body techniques and a rank. Beasts are built like the main mod's own demon beasts and gather qi and break through over time.

### Beasts of the Mountains and Seas

With the default roster (`[beasts] roster = MYTHS`), **26 beasts of the *Classic of Mountains and Seas*** are each played by the Threateningly Mobs creature that looks closest to it. Each takes the myth's name (English and 中文), nature and habitat. Sixteen roam the wilds:

| Myth | Played by | Nature | Where |
|---|---|---|---|
| Jiangshi 僵尸 | Elite Zombie Warrior | Blood | plains, woods, swamps, caves, at night |
| Nine-Tailed Fox 九尾狐 | Castylosaurus | Shadow | forests, taiga, snow |
| Tiangou 天狗 | Tall Mouse | Shadow | plains, mountains, badlands, at night |
| Bifang 毕方 | Plague Bird | Fire | savanna, desert, badlands, Nether |
| Dangkang 当康 | Steelboar | Earth | plains, forests, savanna |
| Gudiao 蛊雕 | Basalt Wyvern | Wind | mountains, shores, badlands |
| Feiyi 肥遗 | Fire Lizard | Fire | deserts, badlands, Nether |
| Huashe 化蛇 | Hydra Cub | Water | rivers, swamps, shores |
| Water Ghost 水鬼 | Tide Specter | Water | rivers, swamps, the sea, at night |
| Zhuhuai 朱厌 | Copas | Earth | mountains, savanna, jungle |
| Shanxiao 山魈 | Nature Fairy | Wood | forests, jungles, mountains |
| Pixiu 貔貅 | Guardian Statue | Metal | mountains, caves (rare) |
| Baize 白泽 | Regalhart | Holy | forests, taiga, snow (rare) |
| **Luwu 陆吾** | Forest Drake | Earth | *elite:* mountains, jungles, caves |
| **Bashe 巴蛇** | Ferox Deathworm | Poison | *elite:* swamps, jungles, deserts |
| **Xingtian 刑天** | Executioner | Blood | *elite:* badlands, dark woods, at night |

- **The three elites** also serve as Cave Lords, tide bosses, world bosses and warband leaders.
- **Where they're drawn from:** caves, herb grottos, secret realms, beast tides, nests and eggs draw only from these 16.
- **The other ten** are the **Great Evils**, which never spawn by themselves.
- **With `roster = ALL`**, every Threateningly Mobs creature appears instead, still under its myth name where it has one.

### Ranks

| Rank | Spawn weight | Usual realm at birth | Sub-stage | Spell damage | Extra health |
|---|---|---|---|---|---|
| Common | 40 | Qi Refining (70%), Foundation (25%), Golden Core (5%) | Early | ×1.0 | ×1.0 |
| Uncommon | 16 | mostly Foundation, up to Nascent Soul | Middle | ×1.15 | ×1.1 |
| Rare | 6 | Golden Core to Nascent Soul, rarely higher | Late | ×1.35 | ×1.3 |
| Boss | 2 | Nascent Soul to Soul Formation, up to Mahayana | Peak | ×1.6 | ×1.7 |

- **Rare beasts and bosses** know the spells of one or two realms beyond their own, loose an extra projectile and cast faster.
- **Fury:** once per fight, when a boss falls below 40% health it roars, heals 10% and gains Strength II, Speed II and Resistance for 30 seconds.
- **Born far out:** beasts born more than 3,000 blocks from spawn may be a realm stronger, and the Almanac's Danger setting adds more.
- **Matched to you:** wild beasts are capped one realm above the strongest player near them, and bosses don't roam near players below Foundation (see [The Harsh World](#the-harsh-world)).

### Built like true demon beasts

- **Zhenyuan:** a beast gets the main mod's demon-beast zhenyuan for its realm. A Golden Core (Middle) beast gains about +456 health and +99 attack; a Void Refining beast about +792 health and +270 attack.
- **Body defence and a qi shield:** every hit is first reduced by its body defence. Then its **qi shield** soaks part of the rest: 30% at Qi Refining, rising to 95% at Tribulation.
  - The shield lasts until its qi runs out (you'll hear glass crack), and refills over time.
  - **Wear the shield down, or hit hard enough to burst through it.**
- **Techniques:** the main mod's beast techniques for its bloodline, then its own elemental ones:

  | Nature | Bloodline |
  |---|---|
  | Fire | Jin Yu |
  | Ice | Shuang Ya |
  | Water | Xuan Wu |
  | Lightning | Xuan Ting |
  | Earth | Xuan Yuan |
  | Wood and Poison | Tai Bei |
  | Wind | Qingxiao Yulin |

- **Spells:** the spells of its nature for its realm, the main mod's common beast spells, and **great divine arts** for whatever its element:

  | Realm | Great art |
  |---|---|
  | Nascent Soul | Heaven-Piercing Cone |
  | Soul Formation | Sky-Splitting Sword Aura |
  | Void Refining | Star Fall |

- **Divine might:** every realm above Golden Core adds +20% spell damage, and beasts cast faster as they rise (a Nascent Soul beast every 1.3 s or so).
- **Flight:** beasts of Nascent Soul and above, and bosses from Golden Core, take to the air when a foe is within 48 blocks. They dive at you from above, so walls and rooftops don't protect you. They land when the fight ends.
- **The status panel:** a beast shows the main mod's own overhead panel: name, realm and stage, nature, rank, qi bar and health bar.

### How wild beasts spawn

The addon spawns beasts itself, around each player, so the wilds stay dangerous by day too. By default:

- **Rate:** every 6 seconds, 2 nearby spots are tried, each of which can bring a whole pack. At night and underground the rate is 140%; by day on the surface, 80%.
- **Distance and cap:** beasts appear 24–56 blocks away, and stop once 14 wild beasts are within 64 blocks of you.
- **Spacing:** a rare beast never appears within 40 blocks of another; a boss never within 128 blocks of another.
- **Despawning:** wild beasts with no player within 128 blocks fade away (named ones stay).
- **Never on a sect's grounds**, and never inside a cave except its own guardians.

All of this is set with the *[Beast Tide Almanac](#beast-tide-almanac)*.

### Drops

- **Spirit stones** by realm, and a chance of a **spirit vein core** from Foundation upward (60% at the highest realms). Looting raises both.
- **Cave guardians** always drop their core.
- **Herb grotto keepers** drop herbs instead of stones.
- **The main mod's demon cores and bones** drop as usual.

## Great Evils and World Bosses

### ☠ The Ten Great Evils

They never wander in by themselves. They're called out at a **Demon-Sealing Altar** with the offering each one craves, or they come to their **omens**.

| Great evil | Played by | Needs | Its power |
|---|---|---|---|
| Nian 年兽 | Flamehorn | Foundation | fire, explosions and fireworks deal ×3 to it; shies from red items and torches; a slowing roar |
| White Bone Demon 白骨精 | Hypocritical Saint | Foundation | raises Bone Servants; sheds a borrowed face at ⅔ and ⅓ health |
| Taowu 梼杌 | Titan Rabbit | Golden Core | ground-shaking stomps |
| Qiongqi 穷奇 | Dracoscorpius | Golden Core | gales that hurl you away |
| Xiangliu 相柳 | Lindworm | Nascent Soul | poison pools wherever you stand |
| Jiuying 九婴 | Hydra | Nascent Soul | fire and water by turns: burning, then freezing |
| Taotie 饕餮 | Devourer | Soul Formation | inhales everything toward its maw, then bites and heals |
| Hundun 混沌 | Shadow Spider | Soul Formation | scrambles everyone nearby, with nausea |
| Zhulong 烛龙 | Earthloong | Void Refining | eyes open: everything burns; eyes shut: darkness |
| Kunpeng 鲲鹏 | Riptooth | Void Refining | lightning on you and storm gusts |

- **How strong:** each has a red boss bar and comes one realm above what it requires (or one above you, if you're higher).
- **Domains:** below half health it unfolds a domain of its nature once (radius 12, 25 s).
- **Drops:** a **Beast Soul Orb** on top of its stones and cores, and sometimes a Scroll of Soul-Piercing. It's marked ✔ on the altar.

**The Demon-Sealing Altar 封魔台**

- **Recipe:** bone block, eye of ender, bone block / gold ingot, crying obsidian, gold ingot / 3 crying obsidian.
- **Calling one:** right-click to see the ten seals. Choose one, lay its offering (for example the Nian wants 8 cooked porkchops and 8 bread) and break the seal. After a 5-second rite, lightning falls and the beast comes.
- **Limits:** a 10-minute cooldown per player, and one of each evil loose at a time. The Kunpeng must be called beside deep water.

**Omens:**

- **Nian:** on a moonless night, near players of Foundation or above.
- **Kunpeng:** in a thunderstorm over deep ocean (Void Refining and above).
- **White Bone Demon:** at dusk a **Lost Maiden** waits on the road. Strike her and she becomes a Grieving Old Woman, then a Searching Old Man. Strike the third false face and the demon shows itself.

### World bosses

- **When and where:** every **3 days** a world boss rises 180–260 blocks from a random player.
- **How strong:** two realms above the strongest player online (Nascent Soul at least, Tribulation at most), a Boss in three phases. Every player hears where it rose.
- **Tracking:** the Missions window shows its health, distance, your damage and the time left.
- **Rewards:** damage is counted, pets included. The top three get 3,000 / 1,500 / 800 × realm stones and their sects gain prestige. The slayer takes its **egg**.
- **Time limit:** unslain after a day, it sinks back into the earth.
- **Sect Affairs → World Bosses** shows its status and the last result.

### Bosses in phases

Tide Lords, Siege Marshals, War Leaders, story bosses and world bosses fight in three phases, each with its own boss bar:

| Phase | From | What happens |
|---|---|---|
| I | full health | it fights as itself |
| II · Brood Call | 66% | it roars, grows stronger and calls up lesser beasts (a raider calls disciples), and again every 30 s |
| III · Heaven-Defying Shell | 33% | a qi shell worth a quarter of its health must be broken before it can be hurt again; a miasma poisons everyone within 6 blocks; it unfolds a **domain** |

## Spirit Stone Caves and Herb Grottos

Caves are the only source of spirit stone ore. Each is a great open gateway in a rock hill, a stair down to **three maze floors**, and a huge hall where the **Cave Lord** waits. Every floor is sealed until its guardians are dead.

### Where caves appear

- **Wild caves** are always **Low-grade**. The world is split into regions of 14 × 14 chunks; by default 40% hold one (set in the Almanac). About a third of wild caves are **Herb Grottos**.
- **Sect caves:** every generated sect owns one cave near its grounds, graded by its rank: Mid for Lower sects, High for Middle sects and Supreme for Higher sects.

### Elements

Every spirit stone cave has one element: **Blazing** (fire), **Frozen** (ice), **Tidal** (water), **Stoneheart** (earth), **Verdant** (wood) or **Abyssal** (dark).

- **Guardians** share its nature. With the default roster they're the myth beasts of that nature, with the elites Luwu, Bashe or Xingtian as Cave Lords.
- **Chests** favour technique and spell manuals of that element.
- **Herb Grottos** are kept by earth and water beasts only.

### Layout and guardians

1. **The gateway:** an 11 × 11 open door framed by stone pillars, cut into a rock face.
2. **The slope:** a broad stair tunnel down.
3. **Three maze floors:** a 6 × 6 grid of rooms with many dead ends and one true route down.
4. **Stairwells:** a spiral stair around a lit pillar joins the floors.
5. **The Cave Lord's hall:** a domed cavern about 53 blocks across, ringed by eight great columns.

| Cave grade | Floor 1 minions | Floor 2–3 minions | Elites and hall patrols | Hall elites | Cave Lord |
|---|---|---|---|---|---|
| Low | Qi Refining | Qi Refining | Foundation | Foundation | Golden Core |
| Mid | Qi Refining | Foundation | Foundation | Golden Core | Nascent Soul |
| High | Foundation | Golden Core | Golden Core | Nascent Soul | Soul Formation |
| Supreme | Golden Core | Nascent Soul | Nascent Soul | Soul Formation | Body Integration |

### Seals

- **Sealed floors:** a floor stays sealed while any of its guardians lives. Sealed ore can't be mined, sealed chests can't be opened, and grotto herbs can't be picked.
- **Hunting the last guardians:** trying a sealed chest makes that floor's guardians **glow for 2 minutes**.
- **Unbreakable rock:** spells and explosions never break cave rock, and beasts can't dig through it.
- **Nothing else spawns** inside a cave.

### Ore and treasure

- **Ore:** 1.8% of the rock on floor 1, rising to 3.4% in the hall. Better grades lie deeper and in better caves; a Low cave almost never holds anything above low-grade stone.
- **Chests:** 1 on floor 1, 2 on each lower floor and 2 treasure chests in the hall. They hold spirit stones, element manuals and pills; the hall always holds a technique and a spell.
- **Herb Grottos** have no ore. They hold pill herbs, seeds, more pills and manuals instead.

## Beast Tide Almanac

The *[Beast Tide Almanac](#beast-tide-almanac)* sets how often and how strong the demon beasts come.

- **Who can change it:** anyone can read it; only the world's owner (single player) or an operator can change it. Settings are saved with the world.
- **Getting one:** it can't be crafted. Use the creative menu or `/give @s xiaoxiang_sects:beast_almanac`.

| Setting | Default | Range | Effect |
|---|---|---|---|
| A wave every | 6 s | 2–60 s | Time between spawn waves around each player |
| Spawn tries per wave | 2 | 1–8 | Spots tried; each can bring a pack |
| Up to N beasts near you | 14 | 2–40 | No new beasts while this many are within 64 blocks |
| Daytime / night activity | 80% / 140% | 0–300% | Scales the tries |
| Closest / farthest spawn | 24 / 56 blocks | | How near and far a wave reaches |
| Leave beyond | 128 blocks | 64–256 | Wild beasts with no player this close fade away |
| Common / Uncommon / Rare / Boss | 100% each | 0–500% | Weight of each rank |
| Danger | 0 | 0–4 | Each step gives every new beast a further 50% chance of one realm higher |
| Rare / bosses apart | 40 / 128 blocks | | Minimum spacing |
| Wild caves | 40% of regions | 0–100% | New land only |
| Beast tide chance / size | 20% a dusk / 100% | | Tides on your sect (generated sects get half the chance) |

- **Switches:** wild spawning, cave spawns, sea beasts and tides.
- **Presets:** Calm, Normal, Dangerous and Nightmare. Press Apply to use one.
- **Operator buttons:** call a tide on your sect or the nearest sect, stop tides, open a secret realm.
- **The live panel** reads where you stand: your biome, the beasts near you by rank, the time to the next wave, and every species that can appear here with its odds.

## Beast Tides

At dusk, a horde of demon beasts may gather against a sect and attack it in **three waves**.

### Which sects are struck

- **Your sect:** each dusk there's a chance (20% by default) if the master is online in the sect's world and the sect last had a tide at least 2 days ago.
- **Generated sects:** a sect within about 128 blocks of a player can be struck, at half that chance. Defend it and it remembers.
- **Gate breaks:** a secret realm gate left uncleared when it closes **breaks**, and its beasts pour out as a tide.
- **Limits:** at most 3 tides at once, never two within 200 blocks of each other.

### How a tide unfolds

1. **Warning:** a raid horn sounds, and nearby players and your sect are told. Your **alarm bell** rings itself. The tide strikes 30 seconds later.
2. **Wave 1:** common beasts. **Wave 2:** a heavier mix. **Final wave:** rare beasts led by a **Tide Lord** boss.
3. **Where they gather:** waves gather **outside your grounds** and march in. They never spawn inside the array.

### Breaking the array

- **Breaking the array is their first job.** Beasts head for the nearest stretch of the dome and batter it, ignoring defenders behind the barrier unless they come outside.
- **They bombard it** with their strongest ranged arts as they close in (fireballs, Star Fall, flying swords, sword auras, palm thunder and more), and raiders use the main mod's siege-barrier casting.
- **Swarm pressure:** each blow counts as the worse of its own damage or a share of the array's whole qi, so big swarms threaten even immortal arrays. A tide of 25 left unanswered breaks an immortal array in about half a minute.
- **Which foes your flags can hold:** Low flags hold Qi Refining foes, rising to Immortal flags for Mahayana. Each realm above that hits ×1.5 harder (up to ×4).
- **Blood-burst beasts** (red spores above them, about 1 in 4 of the common and uncommon) charge the wall and explode for double damage. Kill them early. Any tide beast at the wall below 30% health blows itself up against the array rather than die for nothing.
- **At 0 qi the array shatters** and the main mod's 5-minute recovery begins.
- **The array strikes back** with heavenly lightning on beasts hammering it: 1–5 bolts by core grade, each costing 0.8% of its qi. It never spends its last 15%.

### Inside the walls

- **Wrecking:** with `mobGriefing` on, beasts smash fragile things (glass, fences, torches, lanterns, crops). They never touch chests or other block entities.
- **Plunder:** beasts that reach the headquarters steal spirit stones from the treasury. Kill a looter and its stones go back.
- **If you win,** your disciples rebuild everything that was smashed.

### Winning and losing

- **Victory** when the final wave is wiped out:
  - **Your sect:** treasury stones, prestige +1 and loyalty for those who fought.
  - **A generated sect:** stones for every player who helped, and its attitude toward your sect rises by 15.
- **Defeat:**
  - **If no player stays within 96 blocks for 2 minutes**, or the tide isn't broken within 12 minutes, the tide wins.
  - **Your sect** loses part of its treasury and storehouse.
- **A battle report** opens for everyone who fought (see [Defending Your Sect](#defending-your-sect)).

## Companion Beasts

Beat a demon beast down and bind it with a **Beast Subduing Talisman**, and it becomes your companion. It fights for you, can be ridden (and flown), grows, evolves and lends you its spells.

### Taming: the battle of wills

- **Recipe:** talisman paper, demon core (tier 1), demon bone and lead → 2 talismans.
- **Weaken it:** beat the beast below **30% health** (50% if its realm is below yours), then use the talisman on it.
- **The battle of wills:** a tug-of-war bar. Tap SPACE to push your will; the beast pulls back and surges every few seconds. Reach your end within 14 seconds and it submits. It's harder the stronger and rarer the beast.
- **What can't be tamed:** a beast more than 2 realms above you, cave guardians, and beasts in a running tide.
- **How many:** 1 at Mortal, one more every two realms, up to 6.

### Living with your beast

| Action | Effect |
|---|---|
| Right-click (empty hand) | Ride it, if it's big enough. Nascent Soul beasts **fly**: jump to take off, it flies where you look, hold jump to climb, sprint for speed |
| Sneak + right-click (empty hand) | Talk with it: spend time together, ask what it wants, open its bond and orders |
| Right-click with meat / a demon core | Heals 20% / 50% |
| **R** | Your nearest companion casts one of its spells at what you look at |
| **J** | The Companion Beasts screen: locate, store and summon, stay and follow, unbind |

### Bond

A bond deepens as you feed it, fight beside it and keep it near.

| Bond | At | Gift |
|---|---|---|
| Wary | 0 | none yet |
| Familiar | 10 | +10% attack |
| Trusted | 25 | +10% health |
| Bonded | 45 | takes a fifth of the wounds meant for you (within 16 blocks) |
| Soul-linked | 70 | regenerates while near you |
| Heart-bound | 100 | once a day it refuses to fall, rising at a third of its strength |

**Orders beyond follow and stay:**

- **Guard this area:** it stays within 12 blocks and attacks every foe.
- **Hunt around me:** it attacks hostile creatures within 16 blocks of you.
- **Strike what I point at.**
- **Go with a disciple:** it's lent to your nearest disciple as their beast.

### The Beast Chamber

Each companion has its own window: sneak + right-click it, or use its row on the Companion screen. It has nine places:

- **Armour** and **two charms**.
- **Three technique manuals:** it studies them while they sit there, if they're not too profound for its realm.
- **Food:** eaten by itself when it's hurt.
- **A pill:** cultivation pills feed its qi toward breakthrough; healing pills mend it.
- **A demon core:** for evolution.

When its qi is full, press **Break through**. The chance is 55% plus its bond and evolution, at most 95%.

### Evolution, bloodlines and gear

- **Evolution:** feed it a demon core of high enough tier once its realm allows. It becomes **Awakened**, **Ascended** and finally **Sovereign**: more health, harder blows, deeper spells.
- **Bloodlines:** two beasts of one kind paired with demon cores give an offspring of a stronger line.
- **Gear:**
  - **Iron, Golden and Jade Beast Armour:** more armour, better with each metal.
  - **Flame Charm:** its blows set foes ablaze.
  - **Wind Charm:** it moves faster.
  - **Jade Vitality Charm:** it regenerates.

### Nests and eggs

- **Finding a nest:** now and then a **Demon Beast Nest** appears 48–96 blocks from you in the wild, guarded by a Rare (sometimes Boss) beast near your realm. You get the direction, and the Missions window tracks it (Shift+U hides nests).
- **Taking an egg:** slay or lure away the guardian, then take a **Demon Beast Egg**. Nests are abandoned after 3 days.
- **Hatching:** keep the egg **warm**: about 30 minutes in your pack, faster in your off hand, about 100 seconds near fire, lava or magma. Then use it. The hatchling takes you for its **parent**: your companion at once, starting at Trusted bond.

### Parley with wild beasts

Sneak + right-click a wild beast with an empty hand:

- **Bow:** a 3-minute truce.
- **Offer food:** a 20-minute truce, maybe a nest.
- **Golden Core and above:** ask what troubles it (a task, rewarded with a demon core and lasting peace), or **challenge it to an honourable duel**.
- A truce holds until you strike it. Beasts in a tide hear nothing.

### The sect's guardian beast

Appoint one of your companions as the **guardian of your headquarters**.

- **What it does:** it keeps to the grounds, fights every foe that comes and grows with your sect's prestige.
- **Upkeep:** it's fed from the treasury each payday. **Beast Keeper** disciples halve the cost and train it.
- **If it falls,** it can be called back by a rite.

## Secret Realms

Now and then a **gate** tears open in the world and stays open for **3 days**: a tall glowing oval coloured by its rank. Step through it to reach a realm of floating islands. Clear it before it closes, or it **breaks** and its beasts pour out onto the land as a beast tide.

### Gates

- **When:** each midday there's a 12% chance a gate opens 60–140 blocks from a random player, one at a time. Everyone is told where. A **Gate Key** opens one of its rank beside you.
- **Rank** is rolled by distance from world spawn: the farther out, the higher.

| Gate | Colour | Minions | Elites and Island Wardens | Realm Sovereign |
|---|---|---|---|---|
| D-Rank | blue | Foundation | Golden Core | Nascent Soul |
| B-Rank | teal | Golden Core | Nascent Soul | Soul Formation |
| A-Rank | violet | Nascent Soul | Soul Formation | Void Refining |
| S-Rank | red | Soul Formation | Void Refining | Body Integration |

**Modifiers** some gates roll:

- **Blood Moon:** every beast one realm higher, and better caches.
- **Fog.**
- **Frenzy:** faster, fiercer beasts.
- **Bountiful:** richer caches.
- **Immortal Resonance:** S-Rank gates near an immortal. Mahayana minions, Tribulation elites and an Earth Immortal Sovereign. Clearing one counts toward the immortal road.

### Entering

- **Space tear:** a cultivator **above a gate's realms** can't simply walk in: the gate is too narrow. A timed minigame opens: strike each spatial node as the sweeping qi line crosses it, before the pressure of space crushes the tear shut. Fail and you're thrown back hurt, and must wait.
- **Cultivation suppression:** inside, a cultivator above the Sovereign's realm is pressed down by its laws (weaker blows, harder blows against them), and techniques above the realm's cap are sealed. Dying while suppressed **wounds your foundation**: stage progress is lost and you're weak for a while, but never a whole realm.
- **The void:** falling below the islands is death for anyone, beast or cultivator.

### The islands

A great central island where the **Realm Sovereign** waits at its altar, ringed by islands of different lands and purposes. They're joined by bridges with gaps to leap and boards that crumble underfoot. A **sky shrine** high above is reached only by a parkour trail of floating stones.

| Island | What waits there |
|---|---|
| Pagoda, Library | Buildings full of beasts and caches |
| Killing-array isle | A deadly array; break its lodestone core to shatter it |
| Trapped shrine | Pressure plates hide arrows, fire, poison, lightning and ambushes |
| Beast nest | A swarm of beasts |
| The Great Maze | A walled maze with a cache at its heart |
| Ore crag | Spirit ore boulders |
| Brazier vault | Light all five braziers to open it |
| High / Humble Sanctum | Arrays admit only cultivators at least as strong as the elites, or no stronger than the minions |
| Spirit garden | Pill herbs |
| Sky shrine | A lone elite on a crystal peak |

**Trials along the way:**

- **Gatekeepers:** cultivators who guard a door or shrine. Challenge one to a spar (no one dies) and win to pass.
- **Rune seals:** a seal stone beside a sealed door. Break its rune rings (the lock minigame) to open it.
- **Waystones:** golden plates that carry you back to a gate.

### The rules of a realm

- **Every boss must fall.** Each island has an **Island Warden**; the Sovereign holds the centre. A bar at the top of the screen counts the guardians still standing.
- **Sealed until the end:** chests stay sealed, and nothing can be broken, built or blown up, until the Sovereign and every Warden are dead. Opening a cache makes every remaining guardian glow for 30 seconds.
- **Guardians keep to their posts:** only a player's hand can fell them, and any that go missing are raised again.
- **No flying** until the realm is conquered.
- **The Sovereign** calls its guard at two thirds health, then seals the arena and rages at one third. Four crying-obsidian eyes around its altar protect it while they stand.
- **Bait:** some chests spring an ambush.

### Loot and conquest

- **Caches** come in four qualities (Common, Rare, Epic, Legendary): spirit stones, high-level technique and spell manuals, pills, treasures and sometimes **Gate Keys**.
- **Rune locks:** even after conquest, Epic and Legendary caches are sealed by rune rings. Pick the lock to open them; fail and guardians are called.
- **Conquest:** when every boss has fallen, a **golden gate** opens at the altar. Your clear is scored (time, deaths, rank) and the best clear per rank is announced to the server. The Sovereign may drop a Gate Key.
- **Leaving:** the pale gate you arrived by always leads out. When the gate closes, everyone inside is cast out.

## Spirit Veins

Rich wellsprings of qi surface now and then in the wild (at most 6 at once). Each is a **grotto**: a shrine gate on the surface opens onto a long stair down into a great amethyst cavern around a **spirit pool**.

### Claiming and income

- **Claiming:** keep a **one-minute vigil** beside the vein's core to claim it for your sect (two minutes to seize one another sect holds).
- **Income:** a held vein pays the treasury every dawn.
- **Defending it:** generated sects covet veins. At dawn one may send a **war party** to the grotto's entrance. Be there and break it, or the vein is lost.

| Grade | Income per dawn | Pool | Bottles per day |
|---|---|---|---|
| Low | 80 | Clear Spirit Pool | 12 |
| Mid | 200 | Jade Spirit Pool | 8 |
| High | 500 | Violet Essence Pool | 6 |
| Supreme | 1,200 | Golden Marrow Pool | 4 |

### The spirit pool

- **Infusion:** stand in the pool or on its rim to gain **Spirit Spring Infusion**. While it lasts, meditating gives extra cultivation, more for finer pools.
- **Bottling:** use a glass bottle at the pool to fill **Spirit Spring Water**. Drinking it gives 3 minutes of infusion anywhere.
- **Who may use it:** only the owning sect may use a claimed pool. A sect master can grant others a timed **vein pass** from the ledger.

### Protection

Grottos are warded against building and breaking. The server setting `[spirit_vein_grottos] protection` decides how much:

- **SURFACE** (default): only the grotto, its stair and the shrine gate.
- **FULL:** the land above as well.
- **OWNERS:** as SURFACE, and the owning sect's leaders may build inside.
- **OFF:** no block protection.

No domain can unfold inside a grotto.

## Ancient Battlefields

Cursed fields where a fallen sect's last war never ended: soul soil strewn with bones, broken pillars, soul lanterns and black banners around a cracked stele.

- **When:** sometimes at dusk a battlefield surfaces 150–260 blocks from a player (at most 3 in the world). Everyone is told where, and it shows on the Sect Survey Jade Slip.
- **By day** they are quiet ruins.
- **At night** spectral cultivators rise and attack anyone on the field: 2, plus 2 per player nearby, up to 8. They're around your realm, and one in five is a stronger Spectral Elder. They fade at dawn.
- **Drops:** slain spectres drop **Broken Artifacts** (60%).
- **Repair:** use a Broken Artifact near a **Refining Core** to play the forging minigame:

  | Score | Result |
  |---|---|
  | 90%+ | a weapon or treasure **one tier higher** |
  | 60%+ | one of its own tier |
  | 30%+ | one a tier lower |
  | below 30% | it shatters |

## Encounters on the Road

### Chance meetings

Every so often, near a cultivator travelling the overworld:

- **A dying expert** lies by the way. Speak with him to receive his inheritance (or his last test).
- **A travelling auction** of the Myriad Treasure Pavilion sets up its stall. Bid against rival buyers with `/sectauction`.
- **Two sects' disciples fight a duel** nearby. Join one side with `/sectduel`, and that sect remembers it.

### The Spirit Caravan

- **When:** every **4 days** a Spirit Caravan Merchant arrives near a player for one day, selling cultivation goods and beast gear for spirit stones.
- **The auction:** it carries one rare lot, a treasure or a Gate Key. Sneak + right-click the merchant with spirit stones in hand to bid; generated sects bid too.
- **When it leaves,** the highest bidder takes the lot and outbid players are paid back, even if offline.

### Wandering cultivators

Sneak + right-click with an empty hand:

- **News and advice:** their greeting, the road's news, and a word of advice for your realm.
- **Requests:** slay or bring something, for stones and regard. Up to 4 at once, 3 days each.
- **Small talk:** +3 regard a day.
- **Teaching:** at high enough regard (90 in the harsh world), a pointer in one of their own arts.
- **Recruiting:** a sect master may invite them to join.
- **Beast tamers** travel with a companion: recruit the tamer and the beast comes too.

### Demonic threats

- **Assassins:** at night, Golden Core cultivators and above may be stalked by demonic assassins, each carrying a purse.
- **Kidnappings:** demonic cultists may kidnap a disciple of a sect with 3 or more members to a hidden camp 150–250 blocks away. Rescue them within **5 days**.
- **Heaven's trials:** when the heavens send a tribulation, your companion beasts and nearby disciples shoulder part of the lightning. Surviving brings **Heaven's Favour** (regeneration, a qi barrier and strength for 5 minutes).

### Notoriety and bounty hunters

Crimes make you famous in the wrong way. **Notoriety** is kept per player and fades a little each day.

| Deed | Notoriety |
|---|---|
| Theft from a sect library | +6 (+10 if caught) |
| Leading a raid | +6 |
| Laying a siege | +15 |
| Thrown out of a ward, palace or clan ring | +10 |
| A clan heirloom stolen | +30 |
| Joining a riot or a siege of a clan | +10 to +15 |
| A kill in war | +1 (one time in three) |

- **At 30 or more,** named **bounty hunters** come for you, each with a style of their own: Lin Feng (Swift Blade), Zhao Shan (Iron Palm), Mei Xue (Frost Lotus), Han Lei (Thunder Spear), Ye Ying (Shadow Step) and Du Qing (Poison Needle).
- **Killing one** pays 150 × realm² stones and lowers your notoriety by 15.
- **Clearing your name:** pay your fines at a town's customs house.

## Generated Sects

The main mod's sects are ranked **Lower, Middle or Higher**, follow a **speciality**, and keep their protection arrays the way a player's sect does.

### Ranks

| Rank | Share | Sect Master | Ancestor | Protection array | Cave | Pavilion grade |
|---|---|---|---|---|---|---|
| Lower | ~50% | Foundation to Golden Core | weakest | Low or Mid | Mid-grade | Mid |
| Middle | ~33% | Nascent Soul to Soul Formation | stronger | High | High-grade | High |
| Higher | ~17% | Void Refining to Mahayana | likely an immortal | Supreme or Immortal | Supreme-grade | Supreme |

- **How rank shows:** elders and disciples are scaled below their master, and members cultivate by their sect's rank.
- **Buildings** are restyled by rank and alignment, from humble cobblestone halls to quartz-and-gold or blackstone-and-crimson palaces.
- **A floating sign** above each array core shows the sect's rank, faction, name and array grade.
- **Spawn chance:** on first start the addon raises the main mod's sect spawn chance to 0.6, unless you've set your own.

### Specialities and the Holy Sects

Every sect follows one speciality: **Sword, Pill, Formation, Beast-Taming, Body-Tempering, Talisman** or **Blood Demon**. Evil sects lean demonic; righteous sects never are. The finest **Higher** sects of each speciality are its **Holy Sects** (about one sect in eleven).

| Holy Sect | Its disciples carry | Its sway brings to markets |
|---|---|---|
| Holy Sword Sect | swords, Strength II, Speed | mid-grade swords |
| Holy Pill Sect | Regeneration II, +20 health | mid pills, Marrow Cleansing, high Qi Recovery |
| Holy Formation Sect | Resistance II, +12 health, twice the array stores and refill speed | qi-gathering flags, inscription knives, compasses |
| Holy Beast Sect | Speed II, Jump II, Strength | beast blood essence |
| Holy Vajra Sect (body) | Resistance II, Strength, +40 health | body-forging pills |
| Holy Talisman Sect | Fire Resistance, Speed, Resistance | talisman paper, cinnabar, mid brushes |
| Holy Demon Sect | Strength II, +20 health, night sight | blood essence, corpse bone |

- **Ordinary sects** carry the same marks at level I.
- **Sway:** every settlement within **1,600 blocks** of a Holy Sect gains +1 might and stocks that sect's goods. Clan estates in that range are its **vassals**.
- **Teaching:** sneak + right-click a Holy Sect's disciple (regard 20) for its **teaching** (600◆, once a day). You get ten minutes of its blessing, a gift of its craft, +250 Path insight on the matching Dao Path, and +3 regard.

### Sect pavilions

Every sect keeps a **pavilion** of its speciality, run by its masters, far above any clan's craft. Sneak + right-click any of its disciples: **Visit the Pavilion** opens the counter, and **[Service] · fee** performs the masters' service.

| | Counter stocks | Regard needed | Treasures only they keep |
|---|---|---|---|
| Clan estate (for comparison) | low–mid | | |
| Lower sect | **Mid** | 0 | Marrow Cleansing Pill, Sword Aura manual, talisman supplies, Blood Spirit Pill |
| Middle sect | **High** | 10 | + Jiedan (Golden Core) Pill, Vajra Body manual |
| Higher sect | **Supreme** | 20 | + Nascent Breakthrough Pill, Sword Heart manual, Bone-Changing Pill, Blood Jiedan Pill |
| Holy Sect | **Immortal** | 30 | + Spirit Root Cleansing Pill, Heaven-Mending Pill, Natal Sword Art, Immortal Body manual |

| Speciality | Pavilion stocks | The masters' service |
|---|---|---|
| Pill | nine pill lines | refine your herbs into a Cultivation Pill and a Qi Recovery Pill of the sect's top grade |
| Sword | named swords and sword manuals | repair all gear, and **+1 Sharpness** on the sword in hand (up to II–V by rank) |
| Formation | every flag kind and formation core plates | a 10-minute **great gathering array** (once a day) |
| Beast | blood essence, Black Tortoise armour | a beast from the pens: Spirit Hound, Moon Wolf, Thunder Wolf or **Heavenly Wolf King** |
| Body | body-forging pills and manuals | **body tempering** (once a day): Health Boost II–V for 30 minutes |
| Talisman | brushes, Maoshan and Tianji robes, paper, cinnabar | a **great ward:** Absorption III–VI and Fire Resistance |
| Blood Demon | blood-burn pills, blood essence, Xuesha robes | **blood refinement:** a third of your health for Strength III–IV |

Fees rise with rank (about 150, 600, 2,000 and 6,000◆). Supreme and immortal goods are paid in supreme spirit stones.

### Their protection arrays

Every sect raises an array whose flags, core plate and spirit vein core are of the **same grade**. Spirit vein cores and core plates store and supply far more qi than the main mod's own numbers:

| Grade | Stores (qi) | Supplies (qi/s) | Damage the full dome holds | Dome mends (damage/s) |
|---|---|---|---|---|
| Low | 400,000 | 1,500 | 400 | 1.5 |
| Mid | 600,000 | 3,000 | 1,200 | 6 |
| High | 1,000,000 | 6,000 | 5,000 | 30 |
| Supreme | 2,000,000 | 12,000 | 40,000 | 240 |
| Immortal | 5,000,000 | 30,000 | 500,000 | 3,000 |

**Their people keep the array:**

- **Stores:** each sect keeps three full charges of qi, refilled by its miners. The array is kept at 90%: 5% a second in peace, 1–3% under siege.
- **Wardens:** two of its people channel qi into the core. Without a warden it refills at half speed.
- **Raised again:** a shattered array rises again by itself once it has recovered and holds a quarter charge.
- **On the wall:** members inside the dome loose **Sword Qi** through it at attackers, and the array strikes back with heavenly lightning.
- **Night watch:** two members walk the rim after dark and cut down monsters.
- **The dome lattice:** shows in the colour of the flags (green Low/Mid, blue High, gold Supreme/Immortal), and only while the array is up.

### Dealing with a sect's disciples

Sneak + right-click a generated sect's disciple with an empty hand:

| Option | What it does |
|---|---|
| How fares your sect's array? | Its charge, stores, wardens and whether it's under attack |
| Give spirit stones to your array | Everything you carry goes to their stores: regard (up to +15), and your sect rises in their esteem |
| Help the wardens: channel my qi | 25% of your qi into their array, once a day: +4 regard |
| The pavilion and its service | See [Sect pavilions](#sect-pavilions) |
| Holy teaching | Holy Sects only |

### Stealing scriptures

- **Their libraries:** generated sects keep foundation-level (Low) manuals in their chests. Higher ones come from secret realms, caves and their libraries.
- **Stealing:** sneak into a sect's pavilion or pagoda and open a chest to attempt a theft. A skill-check minigame opens: press SPACE while the needle is in the white zone (the golden sliver is a great check).
- **All checks passed:** a manual of the sect's rank.
- **A miss:** the alarm sounds, its members attack, and your notoriety rises.
- **Limit:** once every 3 days per sect.

### The Sect Survey Jade Slip

- **What it lists:** right-click it to list the nearest sects (rank, speciality, alignment, distance; your vassals show your emblem). Tabs for **Mines** (caves you've found), **Gates** (open secret realms and ancient battlefields) and **Veins** (grottos and who holds them).
- **Teleporting:** click a row to teleport beside it (a short cooldown between uses).
- **Recipe:** compass, demon bone, paper (shapeless).

## Holy Sect Fairs

- **When and where:** every **12th day**, each Holy Sect sends an **Examiner** (Nascent Soul) to the plaza of every **capital under its sway**. Players in the capital are told when the fair opens, and the sect's disciples tell you how many days remain.
- **The entrance bout** (300◆, once a day): a disciple of your own realm meets you. No one dies: the blow that would kill either of you decides it. Win within 2½ minutes to become an **outer disciple** of that Holy Sect.
- **One Holy Sect only:** you can belong to only one.

**Outer disciples get:**

- the sect's pavilion at **25% off**, with no regard required;
- its masters' services at 25% off;
- its daily teaching **free**;
- a gift of its craft on joining.

## Founding Your Sect

With the **Sect Master's Command Token** you found your own sect, recruit disciples, give them ranks and duties, pay them every dawn and send them on missions. Right-click the token to open the **sect ledger**.

### Founding

- **Cost:** 30 spirit stones carried in your inventory. Your headquarters is where you stand; move it later with *Set headquarters here*.
- **How many you can lead:** 6, plus 3 per realm (up to Tribulation), plus 6 for every immortal realm.
- **The treasury:** on the Overview tab, *Deposit all spirit stones* converts carried stones into treasury value (low 1, mid 9, high 81, supreme 729). The *Take* buttons withdraw them.
- **Command Token recipe:** gold ingot, book and 3 low spirit stones (shapeless).

### The grounds

- **Size:** 64 blocks round the headquarters, or out to the edge of your farthest bound protection array plus a margin (up to 256), whichever is larger.
- **No monster or wild beast** springs up inside them. Only things that march in from outside (tides, sieges, war parties) come.

### Recruiting

- **Who:** wandering cultivators within 32 blocks appear in the **Recruit** tab. You can also sneak and use the token on one, or invite them while talking.
- **Signing gift:** three days of their standard wage, from the treasury.
- **Chance:** 45%, plus their favour toward you, plus 2% per current disciple (up to 15%), minus 12% for each realm they stand above you. Always between 5% and 95%.
- **Stragglers:** new recruits head to the sect and take a free **work post** (Sect Gate 2, Herb Fields 4 or 8, Alchemy Workshop 5, Forge Hall 5, Training Grounds 5), or **Patrol** if none is free. Stragglers far from home walk or teleport back.

### Ranks and wages

| Rank | Wage | Needs | Limit |
|---|---|---|---|
| Grand Elder | 300% | Golden Core | 1 |
| Elder | 200% | Foundation | 4 |
| Inner Disciple | 130% | Qi Refining | |
| Outer Disciple | 100% | | |
| Servant | 60% | | |

Standard daily wage by realm (low stones): Mortal 1, Qi Refining 3, Foundation 10, Golden Core 35, Nascent Soul 120, Soul Formation 400, Void Refining 1,300, Body Integration 4,000, Mahayana 12,000, Tribulation 36,000, Immortal 100,000.

### Pay and loyalty

- **Payday** is every dawn: wage × rank × their pay setting (50% to 300%) from the treasury.
- **Paid on time:** loyalty +2 (more for higher pay). **Unpaid:** −15.
- **Reward:** two days' wage for +12 loyalty.
- **Desertion:** at 0 loyalty a disciple deserts.

### Duties

| Duty | What they do |
|---|---|
| Escort | Follows and protects you |
| Guard Post | Stands guard at their post or the headquarters |
| Patrol | Walks the whole grounds |
| Mine | Brings spirit stones and metal ore to the storehouse each day |
| Gather Herbs | Brings pill herbs each day |
| Seclusion | Cultivates quietly, taking pills from the storehouse; +3 loyalty a day |
| Tend Herb Fields | Harvests and replants the Herb Fields |
| Refine Pills | Refines storehouse herbs into pills at the Alchemy Workshop |
| Forge Weapons | Forges metals and demon cores into weapons and treasures |
| Train | Drills at the Training Grounds: mastery grows, breakthroughs come |
| Gatekeeper | Keeps the Sect Gate: collects tolls and turns away intruders |
| Beast Keeper | Tends the sect's guardian beast: halves its feed and trains it |

### Orders

- **Stance:** Protect, Attack or Hold Fire.
- **Placing them:** *Stay here* makes your spot their post; *Use HQ* sends them back.
- **Assign bed:** they sleep there at night.
- **Summon:** brings a disciple to your side.
- **Attack my target:** aim and use the token, and every disciple within 64 blocks attacks. *Stand down* calls them off.
- **Missions:** a disciple leaves the world and comes back with spoils, wounded, or not at all.

| Mission | Reward | Difficulty |
|---|---|---|
| Hunt Demon Beasts | stones, demon bones, vein cores | normal |
| Herb Expedition | rare pill herbs | +5% |
| Explore Ancient Ruins | technique and spell manuals | −10% |
| Escort a Caravan | a heavy purse of stones | +10% |
| Train at a Spirit Peak | cultivation progress | +15% |

**Mission grades:**

- **Low:** Qi Refining, 5 minutes.
- **Mid:** Foundation, 8 minutes.
- **High:** Golden Core, 11 minutes.
- **Supreme:** Nascent Soul, 14 minutes.

The success chance rises with the disciple's realm and loyalty, and a **Mission Hall** adds 10%.

### Fellow players and tokens of authority

Other players can join your sect. Invite one by sneak-using the Command Token on them, or with `/sectfellow invite <name>`. One sect per player, the cultivation mod's sects included. Members deposit, draw stipends and use the storehouse at the **Sect Hall**.

| Grade | Token | May |
|---|---|---|
| 1 | Outer Disciple Token | pass the sect's formations; deposit; see the storehouse |
| 2 | Inner Disciple Token | + take from the storehouse; the Formation Hall |
| 3 | Elder Token | + invite players; issue and revoke Outer and Inner tokens |
| 4 | Grand Elder Token | + issue Elder tokens; run production; draw on the treasury (10% a day) |
| 5 | Sect Command Token | the master and the Deputy Sect Leader: everything |

- **Issuing tokens:** only at the **Jade Token Altar** inside a **Token Pavilion** (within 10 blocks of it).
- **Binding:** a token is bound to one sect and one holder. A token handed to someone else, or revoked, is void.

### Formations and the gate

- **Claiming plates:** the master or deputy claims the main mod's formation core plates for the sect by sneak-using the Command Token on them (up to 8).
- **Passing them:** every member with a Command Token or a linked pass token passes every claimed plate, and hired disciples and members' beasts pass without one. Sneak-using the token on a claimed plate opens the **Formation Hall**.
- **The Sect Gate:** with a gate built and a disciple on Gatekeeper duty, outsiders who step onto your grounds are asked for a toll (20 by default). They pay (`/secttoll pay`, a day's pass) or are escorted out. Members and allies pass freely; enemies at war get drawn blades.
- **Wards:** see [Sect Wards and the Sect Domain](#sect-wards-and-the-sect-domain).

### The Sect Storehouse

One storehouse every member shares. Open it at any Steward's Ledger, from the Sect Hall, or with `/sectstore` near the headquarters. Takings by members other than the master are written in the sect's records.

## Buildings and Production

The **Build** tab of the ledger raises sect buildings.

1. **Choose:** pick a design, a style and a facing. The **Materials to gather** grid shows the full bill.
2. **Preview:** a glowing hologram follows you. Sneak and use the token (or press **Lay blueprint here**) to fix it.
3. **Deliver materials:** matching blocks are taken from your inventory.
4. **Building:** when everything is delivered, your disciples build it, about 60 blocks a second while the site is loaded. In creative, **Build now** needs no materials.

**Styles:** nine, combining Humble, Stately and Grand with Righteous, Neutral and Demonic.

| Design | Purpose |
|---|---|
| Sect Gate, Pillared Gatehouse | Mark your grounds; with Gatekeepers, take tolls |
| Main Hall | Where the master holds court |
| **Grand Arena** | 12 tiers of seats, a master's box and a betting house. Needed for duels, contests and tournaments |
| Disciple Residence, Servants' Quarters | Lodgings |
| Treasure Pavilion | Its formation pays 1% interest on the treasury (at most 250 a day) |
| Pavilion | Disciples meditate there: loyalty +1 for everyone |
| Alchemy Furnace, Forging Furnace | Open-air furnaces with cores |
| **Mission Hall** | Missions +10% success; the bounty board posts 8 a day |
| **Herb Fields** | Four big spirit-soil plots (low to supreme); farmers harvest and replant herbs that ripen over days |
| **Alchemy Workshop** | A hall around a true alchemy furnace; alchemists refine storehouse herbs into pills |
| **Forge Hall** | A smithy around a true refining furnace; smiths forge metals and demon cores |
| **Training Grounds** | Dummies, an archery wall and an obstacle course; trainees gain mastery and break through |
| **Scripture Pagoda** | The six-storey library (see [The Scripture Pagoda](#the-scripture-pagoda)) |
| **Token Pavilion** | The Jade Token Altar, where tokens are issued |
| Ancestor's Cave | Its spirit vein feeds qi to companion beasts near the headquarters |
| Street Lantern | Lights the paths |

### The production cycle

Everything made goes into the storehouse, and the workshops draw what they need from it:

- **Herbs to pills:** Herb Fields (farmers) grow spirit herbs, and the Alchemy Workshop (alchemists) turns them into pills for disciples in Seclusion.
- **Metals and cores to gear:** mines (miners) bring metals, and missions and beasts bring demon cores. The Forge Hall (smiths) turns them into weapons, armour and treasures.
- **Fuel:** the treasury supplies spirit stones as furnace fuel for both.

A batch is made only when every ingredient is in the storehouse and the fuel in the treasury. What's missing is reported each morning and in the building's **Steward's Ledger**, where you also assign its workers.

- **Crafts:** every trade a disciple works earns craft experience and a rank: Apprentice, Journeyman, Adept, Expert, Master, Grandmaster. Each rank brings bigger harvests, richer veins, surer and finer pills and blades, and fatter tolls.
- **The sect runs itself:**
  - stones the workers bring in go to the treasury;
  - the armoury hands forged gear to the fighting disciples;
  - when the storehouse fills, the steward sells the cheapest surplus.
- **The disciples' exchange:** disciples earn **merit** of their own (duties, missions, kills) and spend it on what they need from the storehouse: healing pills, the breakthrough pill of their realm, manuals that suit their roots, gear. What the storehouse lacks becomes a **wish** they tell you about.

## Arrays and the Reservoir

### Binding arrays

Use the main mod's formation core plates and flags to raise protection arrays on your grounds, then claim the plates for your sect with the Command Token.

- **Activating:** activating an array starts the **rune minigame** first.
- **The lattice:** your array shows the same glowing lattice as the generated sects, coloured by flag grade, only while it's up.
- **Which foes it holds:** flag grade decides the realms it holds off. Low flags hold Qi Refining foes; Immortal flags hold Mahayana. Each realm above that hits ×1.5 harder.
- **Counter-strike:** the array calls down heavenly lightning on beasts battering its wall (1–5 bolts by core). Switch it at Sect Hall → ⚡ *Array counter-strike*.

### The Spirit-Stone Reservoir

A block that keeps every formation core in its reach charged.

- **Recipe:** gold ingot, mid spirit stone, gold ingot / mid spirit stone, blast furnace, mid spirit stone / 3 polished deepslate.
- **Reach:** 24 blocks, +8 per tier of the vein core it came from.
- **Running an array is free:** the reservoir carries each core's running cost by itself, each second. An array standing in peace burns no stones and no treasury stones.
- **Stones only heal damage:** qi a core loses to attacks is recorded as damage. Spirit stones (and the treasury, if the master allows it) are spent only to give it back, at the siege refill speed. Charging a core that isn't up yet may also use stones, so the array can be raised.
- **Free qi always goes first:**
  1. qi banked from a converted vein core;
  2. what the reservoir gathers by itself (20 qi a second, +40 per tier, up to 50,000);
  3. Spirit Vein Cores in its reach, which regenerate.
- **Better stones last longer:**

| Stone | Qi in the reservoir (default ×2 worth) |
|---|---|
| Low | 20 |
| Mid | 300 (×1.5 bonus) |
| High | 4,000 (×2 bonus) |
| Supreme | 60,000 (×3 bonus) |

- **Keep at:** the level it holds cores at (50, 75, 90 or 100%). It refills 10% of a core's maximum a second in peace, faster under siege.
- **Raises a shattered array** by itself once it has recovered and is charged to a quarter. An array you switched off yourself stays off.
- **Vein cores:** by default a Spirit Vein Core stays a vein core. **Sneak + right-click one with an empty hand** to convert it (its qi is banked and its tier carries over), and sneak + right-click a converted reservoir to turn it back. The server setting `vein_core_conversion` can turn this `OFF` or make it `ALWAYS`.
- **The window:** stones by grade, the cores it feeds with their qi and drain, the state of the array (UP, SHATTERED or DOWN), **Keep at ▸** and **Treasury ▸**.

## Defending Your Sect

### The alarm

- **The Sect Alarm Bell:** recipe 3 stripped dark oak logs / stripped dark oak log, empty, stripped dark oak log / gold ingot, bell, gold ingot.
- **Ringing it:** for 2 minutes every disciple drops their work and takes a **battle station** in a ring inside the array, facing out. Sneak + ring to stand them down.
- **It rings itself** when a tide, war party, siege or invasion falls on the sect.

### How disciples fight

Every two seconds the sect looks over its grounds and plans:

| Situation | What they do |
|---|---|
| A foe one disciple can beat | The nearest such disciple fights it alone |
| A strong foe | A band forms until their combined strength is enough (up to 6). Nobody charges a boss alone |
| Too strong for anyone free | Nobody rushes it. The rest hold the line inside the array |
| It reaches the heart | Everyone closes ranks on it |
| A disciple below 30% health | Falls back to the headquarters to heal, rejoins at 70% |

- **Ranged arts:** every disciple casts arts at foes within 32 blocks and looses **Sword Qi** from 24 blocks, through your own array.
- **Domains:** Elders of Nascent Soul and above unfold domains when hard pressed.
- **Defense orders** (Sect Hall → ⚔ *Defense orders*):
  - **Fight:** go out and meet the foe.
  - **Hold the line:** stay inside the array and shoot.
  - **Retreat:** everyone to the headquarters.

### What attacks a sect

- **Beast tides** at dusk (see [Beast Tides](#beast-tides)).
- **War parties and sieges** from generated sects at war with you (see [Relations and War](#relations-and-war)).
- **Demonic invasions:**
  - **Warning:** at dusk, scouts may warn that a demonic sect marches on your sect (sects with 3+ members whose master is near; at most every 5 days).
  - **The attack:** at midnight it strikes in three waves: cultists, then an elder with his followers, then the demonic patriarch himself.
  - **Captives:** disciples it overpowers are dragged to its war camp (two at most). Rescue them within five days.
  - **The outcome:** break all three waves for spoils and prestige. If they still stand at dawn, they withdraw with part of the treasury.
  - **Gatekeepers** at the Sect Gate thin the first wave.
- **Kidnappings and assassins** (see [Encounters on the Road](#encounters-on-the-road)).

### Seeing the battle

- **The Missions window** shows tides, sieges and war parties within 160 blocks or on your sect: countdown, wave, foes left, array % or BROKEN, plunder and your kills.
- **The live sect map** (**N**) shows terrain from above, buildings, the arrays' circles with their qi, alarm bells, disciples coloured by duty (red when fighting), players and every foe, with bosses larger. It refreshes every second; scroll to zoom and drag to pan.
- **Battle reports:** after every attack a report opens for the leader and everyone who fought. It shows VICTORY or DEFEAT, the numbers, defenders ranked by damage (★ top), the fallen and a timeline. The sect keeps its last 8: Sect Affairs → Battle Reports, or `/sectreport`.

## Sect Life

### Natures, traits and dramas

- **Traits:** every disciple has one: Diligent, Lazy, Ambitious, Loyal, Greedy or Reckless. Loyal disciples never fall below 50 loyalty; greedy ones may desert with stolen stones.
- **Dramas:** on about one morning in four something happens: a rivalry, a betrayal, an inner demon, a talented youth at the gate, or a dying elder who leaves a manual.
- **Talking with them:** sneak + right-click a disciple for a heart-to-heart (+2 loyalty a day), to hear their wishes, or to ask about their past (their own missions).

### Bonds between disciples

| Bond | Affinity | In battle (within 12 blocks) |
|---|---|---|
| Friends | 50+ | Speed |
| Sworn siblings | 80+ | Strength and Speed |
| Dao companions | 90+, rare | Strength II and Resistance |
| Rivals | −50 or lower | spur each other on, and sometimes duel |

When a bonded disciple falls, the other grieves and vows vengeance. **Sect Affairs → Disciple Bonds** lists every notable bond.

### The Elder Council

- **Who:** your three highest elders vote on **war and alliances**, each by loyalty and nature.
- **Overruling:** give the same order again within a minute. Those who voted against lose 10 loyalty.
- **Plots:** an elder below 25 loyalty **plots**. You have 2 days to **appease** them (10% of the treasury, +30 loyalty) or **confront** them (they draw their blade). Ignored, they defect with a tenth of the treasury and up to 2 followers.
- **A council feast** (5% of the treasury) gives every councillor +6 loyalty.

### Rankings, ceremony and challenges

- **Rankings:** every sect in the world is ranked (prestige, titles, war kills, members, realms cleared).
- **The Grand Ceremony:** every 30 days, the top three player sects get prestige, stones and the title of the year.
- **Champion duels:** challenge a generated sect you're not at war with to send its Champion. Win within 5 minutes for stones, prestige +2 and +5 attitude. Once every 7 days per sect.
- **The weekly challenge:** each week your sect is set a hunt: 60 hostile creatures, plus 15 per disciple, slain by master, fellows, disciples and their beasts together. Reach it for treasury stones, prestige and loyalty.

### Sparring, succession and finances

- **Sparring:** spar with a disciple, in your arena if you have one. Nobody dies. Win, and their loyalty rises and every few wins they break through (never past one realm below you). Lose, and they teach you a technique as a manual. One bout per disciple per day.
- **Succession:** if you fall in a siege or to a tribulation, your Grand Elder becomes **regent**. A loyal one (40+) keeps all safe; a disloyal one stages a coup, taking a quarter of the treasury and the disloyal disciples.
- **Finances:** the **Finances** tab shows what's expected each dawn and every line booked today and yesterday.

### Sect Affairs

**Sect Hall → Sect Affairs** gathers the Elder Council, the Quest Journal, Escort Contracts, World Bosses, Battle Reports, Disciple Bonds and the Sect Map.

## The Scripture Pagoda

A great six-storey pagoda that holds your sect's technique and spell manuals. Members earn **merit** and spend it on manuals; each floor holds better ones and is watched by stronger guardians.

### Building it

1. **The altar:** craft the **Scripture Altar** (book / gold ingot, lectern, gold ingot / 3 stone bricks).
2. **The pagoda:** raise the **Scripture Pagoda** design: 31 × 31, six storeys.
3. **The floors:** each floor has an altar at its centre.

| Floor | Name | Manuals | Price in merit |
|---|---|---|---|
| 1 | Hall of Foundations | Low | 30 |
| 2 | Hall of the Golden Core | Mid | 80 |
| 3 | Hall of Souls | High | 200 |
| 4 | Hall of Heaven | Supreme | 500 |
| 5 | Immortal Sutra Hall | Immortal | 1,200 |
| 6 | Guardian's Peak | the senior guardian's post | |

- **Record:** deposit a manual at any altar; it's shelved on its grade's floor.
- **Copy:** any member may have a recorded scripture transcribed for their merit.
- **Teach:** the master assigns a scripture to a disciple, who pays from their own merit.
- **Donate:** 500 treasury stones buy 100 merit.

### Merit

| Source | Merit |
|---|---|
| Daily, by rank (Grand Elder / Elder / Inner / Outer / Servant) | 8 / 6 / 4 / 3 / 1 |
| A successful mission | 8 × (grade + 1) |
| A bounty | 5–80 |
| Breaking a beast tide | 25 for the master, 15 for each member present |
| A successful raid | 40 + 20 × the sect's tier |
| Conquering a secret realm | 60 |
| Kills by a disciple | 1 / 3 / 5 |

**Guardians:** assign Elders or above to guard a floor. They learn the techniques of their floor's tier and are raised in strength to hold it.

## Relations and War

The **Relations** tab lists every other player sect and the **20 nearest generated sects**, so diplomacy works in single player too.

### Player sects

| Standing | How it starts | Effect | How it ends |
|---|---|---|---|
| Neutral | default | | |
| Allied | you propose, they accept | no harm between you; allies come to each other's aid | either side breaks it |
| At War | either side declares it | disciples attack the enemy on sight; kills are scored | a peace offer is accepted, or one side surrenders (20% of its treasury) |

- **Offers:** alliance proposals, peace offers, **trades** (storehouse goods and stones, nothing moves until accepted) and **contest** challenges wait in the Offers view.
- **The Council:** war and alliance motions go to the Elder Council first.

### Generated sects

Each generated sect has an **attitude** toward your sect (−100 to +100): Friendly (30+), Indifferent, Wary or Hostile (−50 or lower).

| Raises attitude | Lowers attitude |
|---|---|
| Gifts from your treasury (up to +25 each) | killing one of their members (−20) |
| Helping them break a beast tide (+15) | declaring war (−40) |
| Feeding their array, helping their wardens | breaking an alliance (−20) |

- **Alliance:** at attitude 30+ (and enough prestige), they send 5, 15 or 40 stones each dawn.
- **War:** their members hunt your master and disciples, and yours hunt theirs.
  - **They can declare war on you** (attitude −50 or lower, 30% a dawn).
  - **War parties:** at dusk they may send a war party of disciples, elders and a War Leader.
  - **Demand peace** when your kill score leads by 3, or **pay tribute** to end it.
- **Lead a raid:** within 15 minutes, slay 5 / 8 / 12 of their members on their grounds. Success sacks the sect: 400 / 1,500 / 5,000 stones, prestige +2, war score +5. Once every 3 days per sect.

### Sieges

- **Sieges on you:** a generated sect at war may lay a full **siege** to your headquarters: five waves, **array-breakers** and catapult volleys every 40 seconds.
  - **Victory:** spoils, prestige +3 and **prisoners**.
  - **Defeat:** 15% of the treasury plundered.
- **Besieging them:** with a war score of 8 or more, **Lay siege** (800 / 2,500 / 8,000 stones to march).
  - **Within 25 minutes:** slay the defenders, seize the three **formation nodes** (stand by each for 15 seconds, or use a Formation-Breaking Talisman), then slay the **Patriarch**.
  - **Victory:** the sect becomes your **vassal**, with double raid loot and prestige +6.

### Vassals, prisoners and coalitions

- **Vassals** pay tribute every dawn (150 / 500 / 1,500 at Normal tax).
  - **Tax:** Light, Normal or Heavy.
  - **Troops:** muster troops to send auxiliaries into your battles.
  - **Governor:** station an elder as governor.
  - **Levy:** levy a one-off payment.
  - **Release:** set them free.
  - **Rebellion:** they rebel if resentment runs deep.
- **Prisoners** (up to 8): ransom them, recruit them (50%), trade them for peace or release them.
- **Coalitions:** with 2+ vassals or 40+ prestige, up to 3 generated sects may band together and declare war. Breaking a coalition gives prestige +5.
- **Siege engines:**
  - **Formation-Breaking Talisman:** seizes a node at once.
  - **Qi Battering Ram:** a shockwave on enemies within 8 blocks.
  - **Flame Arrow Volley:** fire on enemies within 14 blocks.

### The Wanted Board

In the **Mission Hall**, during a war, put a price on an enemy's head: their Sect Master or a disciple, or (against a generated sect) any five of its cultivators. The stones are held in escrow; whoever slays the target collects (a disciple's kill is paid to their master). Bounties lapse after seven days, or when the war ends, and are refunded.

## Tournaments and the Arena

A sect with a finished **Grand Arena** can host single-elimination tournaments of duels or group fights. Use a **Tournament Banner** (stick, wool, stick / stick, wool, stick / low spirit stone) to open the board.

### Hosting and entering

| Option | Choices |
|---|---|
| Format | Duels (1 v 1), Group 2 v 2, 3 v 3 or 5 v 5 |
| Bracket | 4, 8 or 16 entrants |
| Prize | spirit stones from your treasury |
| Entry fee | paid by other sects' entrants; it adds to the pool |
| Entrants | open to all sects, or your sect only |

- **Entering:** pick fighters (yourself and any free disciples) and enter them alone or as a team.
- **The bracket:** shuffled into the next power of two, with byes for empty places.

### Bouts

- **Nobody dies:** a finishing blow knocks the fighter out to the north stand.
- **Only the two sides** can hurt each other. A fighter who leaves the arena is out.
- **Time limit:** after 3 minutes the judges decide by remaining health.
- **The bracket screen** draws winners in gold, the bout in progress pulsing, and the champion at the end.

### Rewards

| Place | Share (4+ entrants) | Share (2) |
|---|---|---|
| Champion | 60% | 70% |
| Runner-up | 25% | 30% |
| Each losing semi-finalist | 7.5% | |

- **The champion's sect** gains 3 prestige and a title, and its disciples gain loyalty and cultivation.
- **Contests between two sects** are staked from both treasuries and split 70% to the winner, 30% to the loser.

### The stands and the betting house

- **Spectators** sit on the benches (right-click one with an empty hand).
- **Betting:** while a bout's first minute runs, anyone watching can **bet** on a side (`/sectbet`). The pool is shared among those who backed the winner; the host's betting house keeps 5%.

## Sect Wards and the Sect Domain

### Sect wards

Your sect can keep three rings around its headquarters, as the towns and clans do. Use `/sectwards` (the sect master).

| Ring | Default size | Who may enter |
|---|---|---|
| Outer | 64 blocks | anyone who pays your **entry fee** (20 stones a day, into the treasury) |
| Inner | 36 blocks | your sect's own players |
| Core | 14 blocks | the master, deputy and elders |

- **Trespassers** are warned, set upon by your disciples after 30 seconds and thrown out after a minute.
- **Wandering cultivators** passing through the outer ring pay the fee too.
- **Faint lines of light** mark each ring near where you stand.
- **Commands:** `/sectwards on|off`, `fee <stones>`, `rings <outer> <inner> <core>`.

### The Sect Domain

When its master has become an **immortal**, a sect can fold a world of its own: a great floating island in its own dimension that only the sect's token holders may enter.

- **Fold it open:** 20,000 stones from the treasury.
- **Move the sect into the Domain**, or to wherever the master stands. The headquarters grounds are carried over a slice at a time. The grounds left behind are emptied, and formations must be bound again where they now stand.
- **Enter and leave** from the Sect Hall.

## Missions and the Journal

### The Missions window

A live window on the **left middle of the screen**, shown only when something's going on. **U** cycles it full / compact / hidden; **Shift+U** hides beast nests.

- **⚔ Tides, sieges and war parties** within 160 blocks, or on your sect anywhere: countdown, wave, foes left, array %, plunder and your kills.
- **⚑ Defense orders** and the **alarm**.
- **✎ Bounties** with progress bars, and **➹ disciple missions** ("back in 4:12").
- **⚒ Construction** progress.
- **Also:** nests, story chapters, escorts, world bosses, council plots, requests, domains and the **tracked mission** with a live arrow and distance.

### The Mission Journal (O)

Every mission, request, bounty and piece of news in one place.

- **Tabs:** All, Board, Quests, Asks, Beasts, Sect, Honours.
- **Details:** each entry shows its steps (✔ done, ➤ now), the giver, the reward, the time left and an **arrow** to where you go.
- **Buttons:** **Track** pins a mission to the Missions window, **Abandon** (click twice), **Accept** (from the Board), **Bear title** (Honours) and **Resume** a closed scene.
- **Keys:** ↑ ↓ choose, T track, O or Esc close.

### Thirty missions

Missions come in steps, with scenes in the conversation window, foes and people appearing as each step starts, live arrows, time limits and rewards. Up to **5 at once** (requests and bounties don't count).

**Where to find them:** the **Board** tab (about 8 a day, plus 3 dailies and the next story chapter), wandering cultivators (*"Any greater task?"*), and your disciples (*"Ask about their past"*).

| Group | Missions |
|---|---|
| ➹ On the road | Escort the Travelling Elder · Bounty: the Rogue Cultivator · The Lost Disciple · A Duel of Honour · The Sealed Letter · The Heart-Demon (purify or end) · Guard the Royal Caravan |
| ⚑ For your sect | Recruitment Drive · The Elders' Build Order · Supply Crisis · The Inner-Sect Examination · A Traitor Within (accuse one of four) · Hold the Vein · Scouts Warn of a Tide · Weekly Challenge: The Great Hunt |
| 🐾 Beasts | The Egg and the Hatchling · Trials of the Beast King · Poachers at the Nest · A Beast for the Elders · The Great Migration (protect or hunt) · Bonds of the Hunt |
| 🌍 The world | Map the Region · Into the Secret Realm · The Moonlit Herb Route · Echoes of the Ancient Battlefield |
| ☀ Daily | Thin the Wilds · Gather Herbs · Patrol the Road, with a growing streak bonus (up to 10 days) |
| ✦ Story | **The Path of Ascension**, one chapter per realm: The Fallen Star → The Masked Sect → Blood on the Foundation → The Golden Tribulation → Dreams of the Nascent Soul → Ascension's Gate |
| ❤ Disciples' stories | Blood Debt · The Old Master · The Family Sword |

### Requests

Small quests from cultivators on the road, your disciples, your beasts and the wild beasts you parley with: slay so many of a kind (alone, or with a companion beside you), or bring so many of a thing. Up to 4 at once, 3 days each. Kills are counted as you go.

### Story chains and escort contracts

From **Sect Affairs**:

- **Story chains** (Quest Journal), one at a time:
  - *The Missing Elder:* Elder Mo joins your sect as an Elder.
  - *The Sealed Demon Beneath the Mountain:* its egg is your reward.
  - *The Rival Sect's Spy:* your elders' loyalty rises.
- **Escort contracts:**
  - **The ward:** a Spirit-Stone Caravan (a laden mule), an Envoy or a Herb Merchant's Wagon must reach a place 300–700 blocks away.
  - **Ambushes:** bandits and beasts strike every minute or so.
  - **Success:** bring the ward within 10 blocks of the destination for the purse, plus a bonus per ambush beaten.
  - **Failure:** if it falls, or you leave it behind for a minute, the contract is lost.

### Honours: reputation, achievements and titles

- **Reputation:** four powers remember what you do: the **Mortal Kingdoms**, the **Righteous Sects**, the **Wandering Cultivators** and the **Beasts of the Wild**. Ranks go Hated, Distrusted, Neutral, Known, Respected, Honoured, Exalted, and higher ranks open missions.
- **Achievements:** each comes with a title. Wear one title at a time for its small lasting gift; it's shown in your conversations.

| Achievement | Title | Gift |
|---|---|---|
| First Steps (1 mission) | the Fledgling | luck |
| Errand Runner (10 missions) | the Reliable | speed |
| A Legend of the Road (50 missions) | the Legendary | health |
| Beast Slayer (100 beasts) | Beast Slayer | attack |
| Bane of the Wilds (1,000 beasts) | Bane of the Wilds | attack |
| Beast Tamer | the Beast Tamer | armour |
| Born of Fire (hatch an egg) | Egg-Warden | health |
| Tidebreaker | Tidebreaker | armour |
| Gatherer of Talents (10 recruits) | the Gatherer | luck |
| Founder of Halls (5 buildings) | the Architect | health |
| Cartographer | the Wayfarer | speed |
| Realm Walker | Realm Walker | speed |
| Honourable Duelist (3 duels) | the Honourable | attack |
| Diligent (7-day streak) | the Diligent | luck |
| The Path Walked (the story) | the Ascendant | health |
| Beloved (Exalted with a power) | the Beloved | armour |

## Sect Bounty Board

A board block that posts **5 bounties a day** (8 with a Mission Hall) for whoever reads it, scaled to your realm.

- **Recipe:** 3 planks / paper, demon bone, paper / 3 planks.
- **When placed,** it raises a great notice board around itself: planks between timber posts under a tiled roof, lanterns and pinned notices.
- **Taking bounties:** right-click any part of it. Take up to **3** at once; new offers come every morning.

| Bounty | What to do | Reward |
|---|---|---|
| Hunt | slay 3–9 of one kind of demon beast | base |
| Slay Rare Beasts | slay rare (or stronger) beasts | ×1.5 |
| Clear Cave Guardians | slay 3–9 spirit-cave guardians | ×1.6 |
| Deliver | bring herbs, demon bones or demon cores | ×0.8 |
| Break a Beast Tide | be there when a tide is broken | ×2 |

- **Rewards:** base rewards are 40, 150, 500 and 1,500 stones by grade. Kills by your companions count.
- **Claiming:** claim at any board. Your sect gets a 20% share, plus prestige.
- **Send disciple:** a sect master can hand a hunt or cave clearing to a disciple.

## Minigames

Crafting, sealing, stealing and taming are done by hand. Each opens its own screen, and the score decides the result. A higher **profession grade** makes a game gentler and its result better: alchemy or refining rank, realm for arrays and locks, foundation quality for breakthroughs. A fitting Dao Path helps a little more.

### Crafting gates

The main mod's cores only work through a minigame: choose the recipe in the core's own screen, press its button, then play.

| Core | Minigame | Score effect |
|---|---|---|
| Alchemy Core | **Pill refining:** keep the furnace's heat inside the moving band | 90%+: chance to rise a grade; below 40%: part of the batch spoils; overheat and it explodes |
| Refining Core | **Forging:** strike as the glowing beats reach the anvil | 90%+: masterwork, a grade higher; below 30%: lesser or cracked |
| Formation Core Plate | **Array activation:** trace the runes | 60%+ activates the array |

**Inscribe a flag** (in the Formation core screen) plays the rune game to make a formation flag. It costs 50, 200, 800, 3,200 or 12,800 stones by grade. A flawless score makes two.

### Other minigames

| Minigame | When | How to play |
|---|---|---|
| Breakthrough consolidation | after rising a stage | keep the qi orb inside the shrinking circle |
| Mastery bottleneck | Break Through on the Mastery screen | the same, harder for Grandmaster |
| Theft skill checks | a chest in a sect library | press SPACE while the needle is in the zone |
| Rune lock | Epic and Legendary realm caches, rune seals | stop each sealing ring with its rune at the top |
| Space tear | a gate too narrow for your realm | tear each spatial node as the qi line crosses it |
| Herb uprooting | harvesting a spirit herb | pull steadily without tearing the root |
| Battle of wills | a Beast Subduing Talisman | tap SPACE to win the tug-of-war |
| Talisman brush | sealing at the Talisman table | trace the strokes; 40%+ seals it |
| Artifact repair | a Broken Artifact near a Refining Core | forging rhythm |
| Arm wrestling | a town's martial hall | press SPACE as the needle crosses the green |

## Items and Recipes

| Item | Recipe | Use |
|---|---|---|
| Sect Survey Jade Slip | shapeless: compass, demon bone, paper | sects, caves, gates and veins; teleport to them |
| Sect Master's Command Token | shapeless: gold ingot, book, 3 low spirit stones | founds and runs your sect |
| Outer / Inner / Elder / Grand Elder Token | issued at the Jade Token Altar | tokens of authority |
| Tournament Banner | stick, wool, stick / stick, wool, stick / low spirit stone | the tournament board |
| Sect Bounty Board | 3 planks / paper, demon bone, paper / 3 planks | daily bounties |
| Scripture Altar | book / gold ingot, lectern, gold ingot / 3 stone bricks | the pagoda's altar |
| Sect Alarm Bell | 3 stripped dark oak logs / log, empty, log / gold ingot, bell, gold ingot | calls disciples to battle stations |
| Spirit-Stone Reservoir | gold ingot, mid stone, gold ingot / mid stone, blast furnace, mid stone / 3 polished deepslate | keeps formation cores charged |
| Demon-Sealing Altar | bone block, eye of ender, bone block / gold ingot, crying obsidian, gold ingot / 3 crying obsidian | calls out the great evils |
| Beast Subduing Talisman | shapeless: talisman paper, demon core (tier 1), demon bone, lead (makes 2) | tames a beaten beast |
| Iron / Golden Beast Armour | shapeless: 5 iron or gold ingots, leather, demon bone | companion armour |
| Jade Beast Armour | shapeless: 4 emeralds, diamond, leather, demon core (tier 3) | companion armour |
| Flame / Wind / Jade Vitality Charm | shapeless: talisman paper, string, blaze powder / feather / glistering melon, and a demon core | companion charms |
| Formation-Breaking Talisman | gold nugget, paper, gold nugget / paper, amethyst shard, paper / gold nugget, paper, gold nugget (makes 2) | seizes a formation node |
| Qi Battering Ram | iron block / log / log | shockwave on enemies within 8 blocks |
| Flame Arrow Volley | 8 arrows around a fire charge | fire on enemies within 14 blocks |
| Dantian Talisman | eye of ender / gold ingot, paper, gold ingot / amethyst shard | opens your dantian storage anywhere |
| Scroll of Soul-Piercing | eye of ender, amethyst, eye of ender / amethyst, book, amethyst / eye of ender, echo shard, eye of ender | teaches Soul-Piercing (Nascent Soul) |
| Dao Seed Husk | 4 amethyst shards (corners), 4 gold ingots (edges), a Spirit Gathering Flower (centre) | the base of every Dao seed |
| Lesser seed | husk (centre), 4 low spirit stones (corners), 2 low beast blood essence, 2 of the kind's lesser material | grows to level 2 |
| Greater seed | lesser seed (centre), 4 high spirit stones, 2 tier-4 demon cores, 2 of the kind's greater material | grows to level 4 |
| Supreme seed | greater seed (centre), 4 supreme spirit stones, 2 tier-7 demon cores, 2 of the kind's supreme material | grows to level 5 |
| Spirit Spring Water | fill a glass bottle at a vein's pool | 3 minutes of infusion |
| Gate Key | realm loot, caravan auctions | opens a secret realm gate beside you |
| Ascension Seal | the Seal Office (6,000◆, Knights of the Realm) | the great breakthroughs and the immortal road |
| Beast Soul Orb | great evils, world bosses and great beasts | the great breakthroughs and the immortal road |
| Mortal Guise Talisman | the money changers | half an hour of a mortal's face |
| Demon Beast Egg | beast nests, world bosses, story quests | hatch a companion |
| Broken Artifact | spectres on ancient battlefields | mend at a Refining Core |
| Beast Tide Almanac | not craftable (creative, `/give`) | spawn settings |
| Jade Waypoint Slip | creative only | step to settlements, castles and clan estates |

The Dao seed materials for each kind are listed under [Dantian World and Soul Sea](#dantian-world-and-soul-sea). Every item is in the main mod's creative tab.
