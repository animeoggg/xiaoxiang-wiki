### Shops and services

- **Shops** sell food, pills, herbs, arms, cloth and talisman supplies for spirit stones. A thin, normal or richer stock depends on the town's might.
- **The merchant guild** buys your goods. A **guild licence** gives 10% off in every shop of the kingdom.
- **The mercenary guild** posts bounties and contracts.
- **Inns:**
  - **Book a room:** your respawn point is set there, you wake with extra health, and at night you sleep till dawn.
  - **Meals:** a hot meal, spirit wine, or a feast for the house (+2 favour).
- **Martial halls:**
  - **A lesson** (10◆): Strength and Speed for 5 minutes.
  - **Sparring** with a clan disciple.
- **The customs house:** tolls, 7-day passes and fines.

### Coins and the economy

- **Coins:** mortals buy their bread, beds and bets with the cultivation mod's **copper coins** (文). Strings are 9 coppers and guan 81. One low spirit stone is worth about 10 coppers at the posted price.
- **Money changers** buy and sell spirit stones at a moving rate.
- **The capital's bank** keeps your coin savings.
- **Market stalls:** rent one for 7 days.
- **The Royal Transit** carries you between capitals.
- **Demonic cultivators** are refused service. A **Mortal Guise Talisman** lays a mortal's face over yours for half an hour, so the towns will serve you.

### Games and pastimes

| Where | Game |
|---|---|
| **House of Fortune** | **Dice:** bet Big, Small or a triple. **The cups:** find the pea. **Card tables:** Twenty-One (blackjack: hit, stand or double; the dealer draws to 17; a natural pays 3 to 2) and Five-Card Draw (ante, hold and draw once; better hands pay a bonus) |
| **Tea house** | The scholar's riddles |
| **Inn** | The drinking contest (10◆) |
| **Martial hall** | **Arm wrestling** (5◆ → 15◆), played live: press SPACE as the needle crosses the green, and counter his surges. The hall's strongest arm (20◆) pays 60◆ or more |
| **Archery range** | Shoot a round (8◆) |
| **Market** | Chase down pickpockets |
| **Arena** | Exhibition bouts with wagers, and the arena champion's challenge for a purse: Novice, Veteran and Grand Champion of the Ring |
