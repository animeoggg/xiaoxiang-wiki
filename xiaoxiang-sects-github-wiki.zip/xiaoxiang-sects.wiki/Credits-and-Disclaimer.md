**I do not own anything.** Xiaoxiang Sects Expanded is an unofficial, fan-made addon. I claim no copyright and no credit for the mods it builds on.

- **Xiaoxiang Cultivation World:** all credit to the main mod and its author. Everything this addon adds is built on their work. The addon needs the original, unmodified mod and doesn't include or redistribute any of its files.
- **Threateningly Mobs:** all credit to its author. Its creatures, models and textures are its own. This addon only changes how they spawn and fight, and doesn't include its files.
- **Domains:** the idea of a domain was inspired by JujutsuCraft's domain expansion. None of its code, models or textures is used.
- **Not affiliated:** this addon isn't affiliated with or endorsed by any of those mods' authors, Mojang or Microsoft. Minecraft is a trademark of Mojang Studios.

**If anything has to be removed, I will remove it.** If the author of any of these mods asks for this addon, or any part of it, to be taken down or changed, it will be done. Please download Xiaoxiang Cultivation World and Threateningly Mobs from their official pages to support their creators.
