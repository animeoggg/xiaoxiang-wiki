### ☠ The Ten Great Evils

They never wander in by themselves. They're called out at a **Demon-Sealing Altar** with the offering each one craves, or they come to their **omens**.

| Great evil | Played by | Needs | Its power |
|---|---|---|---|
| Nian 年兽 | Flamehorn | Foundation | fire, explosions and fireworks deal ×3 to it; shies from red items and torches; a slowing roar |
| White Bone Demon 白骨精 | Hypocritical Saint | Foundation | raises Bone Servants; sheds a borrowed face at ⅔ and ⅓ health |
| Taowu 梼杌 | Titan Rabbit | Golden Core | ground-shaking stomps |
| Qiongqi 穷奇 | Dracoscorpius | Golden Core | gales that hurl you away |
| Xiangliu 相柳 | Lindworm | Nascent Soul | poison pools wherever you stand |
| Jiuying 九婴 | Hydra | Nascent Soul | fire and water by turns: burning, then freezing |
| Taotie 饕餮 | Devourer | Soul Formation | inhales everything toward its maw, then bites and heals |
| Hundun 混沌 | Shadow Spider | Soul Formation | scrambles everyone nearby, with nausea |
| Zhulong 烛龙 | Earthloong | Void Refining | eyes open: everything burns; eyes shut: darkness |
| Kunpeng 鲲鹏 | Riptooth | Void Refining | lightning on you and storm gusts |

- **How strong:** each has a red boss bar and comes one realm above what it requires (or one above you, if you're higher).
- **Domains:** below half health it unfolds a domain of its nature once (radius 12, 25 s).
- **Drops:** a **Beast Soul Orb** on top of its stones and cores, and sometimes a Scroll of Soul-Piercing. It's marked ✔ on the altar.

**The Demon-Sealing Altar 封魔台**

- **Recipe:** bone block, eye of ender, bone block / gold ingot, crying obsidian, gold ingot / 3 crying obsidian.
- **Calling one:** right-click to see the ten seals. Choose one, lay its offering (for example the Nian wants 8 cooked porkchops and 8 bread) and break the seal. After a 5-second rite, lightning falls and the beast comes.
- **Limits:** a 10-minute cooldown per player, and one of each evil loose at a time. The Kunpeng must be called beside deep water.

**Omens:**

- **Nian:** on a moonless night, near players of Foundation or above.
- **Kunpeng:** in a thunderstorm over deep ocean (Void Refining and above).
- **White Bone Demon:** at dusk a **Lost Maiden** waits on the road. Strike her and she becomes a Grieving Old Woman, then a Searching Old Man. Strike the third false face and the demon shows itself.

### World bosses

- **When and where:** every **3 days** a world boss rises 180–260 blocks from a random player.
- **How strong:** two realms above the strongest player online (Nascent Soul at least, Tribulation at most), a Boss in three phases. Every player hears where it rose.
- **Tracking:** the Missions window shows its health, distance, your damage and the time left.
- **Rewards:** damage is counted, pets included. The top three get 3,000 / 1,500 / 800 × realm stones and their sects gain prestige. The slayer takes its **egg**.
- **Time limit:** unslain after a day, it sinks back into the earth.
- **Sect Affairs → World Bosses** shows its status and the last result.

### Bosses in phases

Tide Lords, Siege Marshals, War Leaders, story bosses and world bosses fight in three phases, each with its own boss bar:

| Phase | From | What happens |
|---|---|---|
| I | full health | it fights as itself |
| II · Brood Call | 66% | it roars, grows stronger and calls up lesser beasts (a raider calls disciples), and again every 30 s |
| III · Heaven-Defying Shell | 33% | a qi shell worth a quarter of its health must be broken before it can be hurt again; a miasma poisons everyone within 6 blocks; it unfolds a **domain** |
