Each clan of craft keeps its own **estate** out in the wilds, answering to no king and paying no toll.

### Where and what

- **Where:** estates sit on their own grid between the mortal settlements (about half the regions hold one), clear of every settlement and planned sect, on dry, level land.
- **Layout:** a walled square about **145 blocks across** in three rings (from 1.0.137; buildings keep 3 blocks from every ring wall from 1.0.145):

| Ring | Who lives there | Who may enter |
|---|---|---|
| **Outer court** | outer disciples and retainers: cottages, fields, stalls, a granary, barracks | a small daily fee (10–40◆ by standing), **free from 10 regard** |
| **Inner court** | inner disciples, and the **workshops of the clan's craft** run by the elders | **30 regard** and a daily fee (60–240◆) |
| **Main branch** | the ancestral manor, the **patriarch**, the elders and the main-branch guard | only the clan's own (adopted kin) or honoured friends with **60 regard** |

- **Walls and gates:** the outer wall has four corner towers and the great south gate. The inner and main-branch walls have gates on all four sides with gatekeepers.
- **Trespassers** are warned, attacked after 30 seconds and thrown out after a minute.
- **Standing:** Minor, Established, Great or Ancient.

| People | Minor | Ancient |
|---|---|---|
| Outer disciples | Qi Refining | Foundation |
| Inner disciples | Qi Refining | Golden Core |
| Main-branch guards | Foundation | Golden Core |
| Elders | Qi Refining | Nascent Soul |
| Patriarch | Foundation | Soul Formation |

### Crafts

Every clan keeps the same craft everywhere in the world. Each craft is held by two or three of the 14 clans, chosen by the world seed.

| Craft | Built in | Their people | Their service |
|---|---|---|---|
| **Pill-Refining** | copper-green roofs, mossy stone | Regeneration | **Refine your herbs:** herbs and a fee → a Cultivation Pill and a Qi Recovery Pill |
| **Body-Refining** | slate, andesite | fight bare-handed, Strength and Resistance | **Medicinal bath** (once a day): Health Boost and Resistance, Path of the Body insight |
| **Artifact-Refining** | blackstone, forge brick with magma inlay | refined swords and armour | **Repair all your gear** |
| **Talisman** | vermilion roofs, white calcite walls | Fire Resistance, Speed | **Protective ward:** Absorption and Fire Resistance |
| **Formation** | prismarine | Resistance | **Gathering array** (once a day): a qi spring |
| **Beast-Taming** | mangrove, a log palisade | Speed, and Clan Spirit Hounds | **Buy a tamed Spirit Hound** |

- **Using a service:** talk to the patriarch or an elder (sneak + right-click) for the clan's **counter** and its **service**. Prices scale with the clan's standing.
- **Earning regard:** **pay respects** to the patriarch (+4 regard). Offer incense at the shrine through any outer disciple (50◆, +4). Pass the time with retainers (+1 a day). Each paid service gives +1.

### The clan's protection array

Every estate keeps a **real protection array** (from 1.0.145):

- **What it is:** a Formation Core Plate on a lantern-lit dais in the main branch's courtyard, linked to a protection flag beneath the manor. The grade follows standing: low, mid, high or supreme.
- **Reach:** it covers the whole estate (104 blocks from its flag).
- **Upkeep:** the clan feeds it while anyone is near and raises it whenever it is down. If the plate is broken or the array shattered, the dome goes down and is not rebuilt.
- **Who passes:** players the clan doesn't hate (regard above −15), the clan's kin, creative players, every cultivator and welcome players' beasts. Monsters and the clan's enemies are blocked.
- **Monsters inside** are driven out and burned.

### Regard, adoption and the clan's affairs

- **Regard is kept per clan.** Whatever regard you win with a clan, its **rival** clan loses half as much.
- **Avengers:** a clan that hates you (−15 or worse) may send three **avengers** after you in the wilds. Slaying them earns regard with their rival.
- **Adoption** (60 regard and 1,500◆, after passing the clan's **trial**) makes you **kin**: all three rings, a third off services, 15% off the counter and no fees.

| Clan | Trial |
|---|---|
| Pill | present a mid-grade (or better) Cultivation Pill |
| Artifact | present a mid-grade (or better) refined blade |
| Talisman | present three inscribed talismans |
| Body | **the hundred blows:** stand a minute against two bare-fisted fighters (you can't die in it) |
| Beast | slay the clan's Wild Spirit Wolf within two minutes |
| Formation | answer three array riddles |

- **Heirlooms:** every Great or Ancient clan keeps one in its ancestral hall: Ancestral Elixirs, Blade, Vajra Armour, Brush, Array Flags or Beast Blood.
  - **Entrusted** to kin with 150 regard.
  - **Stealing it** makes you the clan's enemy, hunted daily.
  - **Raiders** come for it now and then; drive them off for regard and stones.
- **Succession:** when a patriarch dies, two elders claim the seat for a day. **Back one** (200◆): the winner's backers gain +40 regard.
- **Marriage pacts:** a sect leader with 80 regard can wed their sect to the clan (3,000◆). Every member of the sect counts as kin, and two inner disciples join the sect.
- **Vassals of the Holy Sects:** a clan within 1,600 blocks of a Holy Sect is its vassal. The Holy Sect sends three disciples when raiders or besiegers come.
- **Sieges:** a clan near a **demonic sect** may be besieged (3% a day while a player is there): a Siege Lord and nine Blood Raiders storm the gate.
  - **Defend the clan:** +15 regard and stones.
  - **Join the siege:** if it wins, you share the plunder and the heirloom is lost.

### Branch estates

A sect master who was adopted into a clan (or whose sect is wed to one) can found a **branch estate** with `/sectbranch found`.

- **Cost:** 20,000 stones from the treasury and six disciples.
- **Where:** on level, dry, loaded land at least 300 blocks from your headquarters, away from towns and estates.
- **How it rises:** a full ringed estate rises around you over a few seconds, run by the clan's people under your sect's name, with its own array.
- **Every day** it sends 150 stones and puts its craft's goods in the chest of its ancestral hall.
