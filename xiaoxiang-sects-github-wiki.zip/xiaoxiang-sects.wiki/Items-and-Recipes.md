| Item | Recipe | Use |
|---|---|---|
| Sect Survey Jade Slip | shapeless: compass, demon bone, paper | sects, caves, gates and veins; teleport to them |
| Sect Master's Command Token | shapeless: gold ingot, book, 3 low spirit stones | founds and runs your sect |
| Outer / Inner / Elder / Grand Elder Token | issued at the Jade Token Altar | tokens of authority |
| Tournament Banner | stick, wool, stick / stick, wool, stick / low spirit stone | the tournament board |
| Sect Bounty Board | 3 planks / paper, demon bone, paper / 3 planks | daily bounties |
| Scripture Altar | book / gold ingot, lectern, gold ingot / 3 stone bricks | the pagoda's altar |
| Sect Alarm Bell | 3 stripped dark oak logs / log, empty, log / gold ingot, bell, gold ingot | calls disciples to battle stations |
| Spirit-Stone Reservoir | gold ingot, mid stone, gold ingot / mid stone, blast furnace, mid stone / 3 polished deepslate | keeps formation cores charged |
| Demon-Sealing Altar | bone block, eye of ender, bone block / gold ingot, crying obsidian, gold ingot / 3 crying obsidian | calls out the great evils |
| Beast Subduing Talisman | shapeless: talisman paper, demon core (tier 1), demon bone, lead (makes 2) | tames a beaten beast |
| Iron / Golden Beast Armour | shapeless: 5 iron or gold ingots, leather, demon bone | companion armour |
| Jade Beast Armour | shapeless: 4 emeralds, diamond, leather, demon core (tier 3) | companion armour |
| Flame / Wind / Jade Vitality Charm | shapeless: talisman paper, string, blaze powder / feather / glistering melon, and a demon core | companion charms |
| Formation-Breaking Talisman | gold nugget, paper, gold nugget / paper, amethyst shard, paper / gold nugget, paper, gold nugget (makes 2) | seizes a formation node |
| Qi Battering Ram | iron block / log / log | shockwave on enemies within 8 blocks |
| Flame Arrow Volley | 8 arrows around a fire charge | fire on enemies within 14 blocks |
| Dantian Talisman | eye of ender / gold ingot, paper, gold ingot / amethyst shard | opens your dantian storage anywhere |
| Scroll of Soul-Piercing | eye of ender, amethyst, eye of ender / amethyst, book, amethyst / eye of ender, echo shard, eye of ender | teaches Soul-Piercing (Nascent Soul) |
| Dao Seed Husk | 4 amethyst shards (corners), 4 gold ingots (edges), a Spirit Gathering Flower (centre) | the base of every Dao seed |
| Lesser seed | husk (centre), 4 low spirit stones (corners), 2 low beast blood essence, 2 of the kind's lesser material | grows to level 2 |
| Greater seed | lesser seed (centre), 4 high spirit stones, 2 tier-4 demon cores, 2 of the kind's greater material | grows to level 4 |
| Supreme seed | greater seed (centre), 4 supreme spirit stones, 2 tier-7 demon cores, 2 of the kind's supreme material | grows to level 5 |
| Spirit Spring Water | fill a glass bottle at a vein's pool | 3 minutes of infusion |
| Gate Key | realm loot, caravan auctions | opens a secret realm gate beside you |
| Ascension Seal | the Seal Office (6,000◆, Knights of the Realm) | the great breakthroughs and the immortal road |
| Beast Soul Orb | great evils, world bosses and great beasts | the great breakthroughs and the immortal road |
| Mortal Guise Talisman | the money changers | half an hour of a mortal's face |
| Demon Beast Egg | beast nests, world bosses, story quests | hatch a companion |
| Broken Artifact | spectres on ancient battlefields | mend at a Refining Core |
| Beast Tide Almanac | not craftable (creative, `/give`) | spawn settings |
| Jade Waypoint Slip | creative only | step to settlements, castles and clan estates |

The Dao seed materials for each kind are listed under [Dantian World and Soul Sea](Dantian-World-and-Soul-Sea). Every item is in the main mod's creative tab.
