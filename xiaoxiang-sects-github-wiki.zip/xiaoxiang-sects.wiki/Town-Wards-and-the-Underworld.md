Settlements first reached from 1.0.137 on are divided by inner walls into three **wards**. From 1.0.145, every ward wall keeps a 3-block clear strip on both sides, and bends around great buildings (the palace, the arena, the clan seats) so they stand whole in one ward.

| Ward | Who may enter | Looks |
|---|---|---|
| **Slums** (outer 30%) | anyone | always built poorly; beggars, rag pickers, urchins and pickpockets |
| **Outer ring** | pay the daily **toll** (free for Royal Guests, or with a pass) | the town's own style |
| **Inner ring** | **merit:** 5 favour in a village, 15 in a town, 30 in a capital, **and** 4× the toll a day. Knights pass free | one step richer than the town |
| **Palace precinct** (capitals) | a **Marquis** | the royal palace |

- **Guards:** each gate on the avenues is kept by two guards. Strength rises toward the heart: the slums' guards and folk are one might step weaker than the town, the inner ring's one step stronger.
- **Trespassers** are warned, attacked after 30 seconds, then beaten and **thrown out** after a minute. Each throw-out adds **+10 notoriety**.
- **Old towns:** towns recorded before 1.0.137 keep no wards, and towns recorded before 1.0.145 keep the first ward layout, so the parts already built still match.

### The Rat King

Somewhere deep in every town's slums sits an **Old Beggar** with no name over his head: the **Rat King**.

| Option | Price | What it does |
|---|---|---|
| Forged toll pass | 2× toll | Passes the outer ring for 3 days. Once a day the guard may see through it (20%): torn up, −5 favour, +5 notoriety |
| Smuggled into the inner ring | 60% of the inner fee | Through the drains, for today. A 25% chance you're spotted (less with underworld standing): thrown out, −10 favour, +10 notoriety |
| What fell off the carts | | The back-room stash: shady goods a grade better than the town's, up to 30% off for friends of the gang |
| Pay your dues | 20◆ | +5 underworld standing |

**Underworld standing** is kept per kingdom.

### Slum riots

In struggling (15% a day) and humble (7% a day) warded towns, the slums may boil over while you're there. 7–10 rioters led by a **Riot Leader** pour out of a slum gate and fight the guards. A riot lasts 6 minutes.

- **Stand with the guards:** +2 favour and 15◆ per rioter slain (up to +12 favour); −3 underworld standing.
- **Join the riot** (talk to the leader): the guards come for you; −12 favour, +10 notoriety. If a third of the mob still stands at the end, you get 60◆ and +12 underworld standing.
- **Pay them to go home** (40◆): the riot breaks up peacefully, +4 favour.

### Wanted posters

Three throw-outs reach the bounty threshold: the posters go up and **bounty hunters** come for you. The customs house shows your record and lets you **pay your fines** (50–150◆ for −20 notoriety).
