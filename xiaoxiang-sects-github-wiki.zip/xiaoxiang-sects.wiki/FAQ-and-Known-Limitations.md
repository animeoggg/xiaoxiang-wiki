**Where do I find spirit stones?**
Caves (ore and chests), slain beasts, bounties, missions, miners, veins, vassals, tributes, trade and the money changers. They don't generate as ore in the open world.

**Everything is too hard / too easy.**
The harsh world is on by default. Ease it with `/harshworld speed 0.75` and `/harshworld predators 10`, or turn it off with `/harshworld off`. Wild spawns are matched to your strength by `[wild_scaling]`.

**I keep getting one-shot at the start.**
Make sure `[wild_scaling] enabled = true`. Within 10,000 blocks of spawn, wild beasts stay within one realm of the strongest player near them, and bosses wait until Foundation. Structures, nests, tides and realms are not matched.

**My array runs out of stones.**
From 1.0.147 a reservoir pays an array's running cost for free and spends stones only to repair damage. Keep Spirit Vein Cores in its reach for free qi.

**Placing a Spirit Vein Core turned it into a reservoir.**
That was the old behaviour. From 1.0.141, conversion happens only on a sneaking, empty-handed right-click (or never, with `vein_core_conversion = OFF`). Sneak + right-click a reservoir to turn it back.

**My alchemy core, refining core or formation plate does nothing.**
Every craft goes through a minigame. Choose the recipe, press the core's button, then play.

**I can't enter a clan estate.**
Its array lets through anyone the clan doesn't count as an enemy (regard above −15). The rings inside ask fees and regard.

**The game lags when new land loads.**
Freezes marked `Qingqiu region … planned … urgent=true` in the log come from Xiaoxiang Cultivation World planning its fox-spirit lands in brand-new terrain. They're worst after a long teleport into unexplored land, and the addon can't change them.

**Do I need a new world?**
Strongly recommended. Caves, settlements, wards, clan estates, sect arrays, grottos and realms appear only in newly generated land. Settlements already recorded keep their old layout so the built parts still match.

**Something crashed.**
Send `latest.log` (or the crash report).

### Known limitations

- **Interrupted battles:** a bout, tide, siege, raid or minigame interrupted by a restart ends quietly. A bout replays, and the materials for an unfinished craft are returned.
- **Online only:** bounty hunters, sieges, invasions and kidnappings need the player online.
- **Main mod updates:** if the main mod changes code a hook relies on, that hook switches off quietly. Report it so the addon can be updated.
- **Inner Heaven:** the old Inner Heaven island (1.0.124–1.0.127) is retired. Its treasures moved into the Dantian World.
