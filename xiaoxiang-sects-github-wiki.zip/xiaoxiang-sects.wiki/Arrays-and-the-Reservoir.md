### Binding arrays

Use the main mod's formation core plates and flags to raise protection arrays on your grounds, then claim the plates for your sect with the Command Token.

- **Activating:** activating an array starts the **rune minigame** first.
- **The lattice:** your array shows the same glowing lattice as the generated sects, coloured by flag grade, only while it's up.
- **Which foes it holds:** flag grade decides the realms it holds off. Low flags hold Qi Refining foes; Immortal flags hold Mahayana. Each realm above that hits ×1.5 harder.
- **Counter-strike:** the array calls down heavenly lightning on beasts battering its wall (1–5 bolts by core). Switch it at Sect Hall → ⚡ *Array counter-strike*.

### The Spirit-Stone Reservoir

A block that keeps every formation core in its reach charged.

- **Recipe:** gold ingot, mid spirit stone, gold ingot / mid spirit stone, blast furnace, mid spirit stone / 3 polished deepslate.
- **Reach:** 24 blocks, +8 per tier of the vein core it came from.
- **Running an array is free:** the reservoir carries each core's running cost by itself, each second. An array standing in peace burns no stones and no treasury stones.
- **Stones only heal damage:** qi a core loses to attacks is recorded as damage. Spirit stones (and the treasury, if the master allows it) are spent only to give it back, at the siege refill speed. Charging a core that isn't up yet may also use stones, so the array can be raised.
- **Free qi always goes first:**
  1. qi banked from a converted vein core;
  2. what the reservoir gathers by itself (20 qi a second, +40 per tier, up to 50,000);
  3. Spirit Vein Cores in its reach, which regenerate.
- **Better stones last longer:**

| Stone | Qi in the reservoir (default ×2 worth) |
|---|---|
| Low | 20 |
| Mid | 300 (×1.5 bonus) |
| High | 4,000 (×2 bonus) |
| Supreme | 60,000 (×3 bonus) |

- **Keep at:** the level it holds cores at (50, 75, 90 or 100%). It refills 10% of a core's maximum a second in peace, faster under siege.
- **Raises a shattered array** by itself once it has recovered and is charged to a quarter. An array you switched off yourself stays off.
- **Vein cores:** by default a Spirit Vein Core stays a vein core. **Sneak + right-click one with an empty hand** to convert it (its qi is banked and its tier carries over), and sneak + right-click a converted reservoir to turn it back. The server setting `vein_core_conversion` can turn this `OFF` or make it `ALWAYS`.
- **The window:** stones by grade, the cores it feeds with their qi and drain, the state of the array (UP, SHATTERED or DOWN), **Keep at ▸** and **Treasury ▸**.
