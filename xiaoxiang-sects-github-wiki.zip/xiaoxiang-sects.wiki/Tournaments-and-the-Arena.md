A sect with a finished **Grand Arena** can host single-elimination tournaments of duels or group fights. Use a **Tournament Banner** (stick, wool, stick / stick, wool, stick / low spirit stone) to open the board.

### Hosting and entering

| Option | Choices |
|---|---|
| Format | Duels (1 v 1), Group 2 v 2, 3 v 3 or 5 v 5 |
| Bracket | 4, 8 or 16 entrants |
| Prize | spirit stones from your treasury |
| Entry fee | paid by other sects' entrants; it adds to the pool |
| Entrants | open to all sects, or your sect only |

- **Entering:** pick fighters (yourself and any free disciples) and enter them alone or as a team.
- **The bracket:** shuffled into the next power of two, with byes for empty places.

### Bouts

- **Nobody dies:** a finishing blow knocks the fighter out to the north stand.
- **Only the two sides** can hurt each other. A fighter who leaves the arena is out.
- **Time limit:** after 3 minutes the judges decide by remaining health.
- **The bracket screen** draws winners in gold, the bout in progress pulsing, and the champion at the end.

### Rewards

| Place | Share (4+ entrants) | Share (2) |
|---|---|---|
| Champion | 60% | 70% |
| Runner-up | 25% | 30% |
| Each losing semi-finalist | 7.5% | |

- **The champion's sect** gains 3 prestige and a title, and its disciples gain loyalty and cultivation.
- **Contests between two sects** are staked from both treasuries and split 70% to the winner, 30% to the loser.

### The stands and the betting house

- **Spectators** sit on the benches (right-click one with an empty hand).
- **Betting:** while a bout's first minute runs, anyone watching can **bet** on a side (`/sectbet`). The pool is shared among those who backed the winner; the host's betting house keeps 5%.
