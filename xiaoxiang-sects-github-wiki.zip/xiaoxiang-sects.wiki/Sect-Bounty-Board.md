A board block that posts **5 bounties a day** (8 with a Mission Hall) for whoever reads it, scaled to your realm.

- **Recipe:** 3 planks / paper, demon bone, paper / 3 planks.
- **When placed,** it raises a great notice board around itself: planks between timber posts under a tiled roof, lanterns and pinned notices.
- **Taking bounties:** right-click any part of it. Take up to **3** at once; new offers come every morning.

| Bounty | What to do | Reward |
|---|---|---|
| Hunt | slay 3–9 of one kind of demon beast | base |
| Slay Rare Beasts | slay rare (or stronger) beasts | ×1.5 |
| Clear Cave Guardians | slay 3–9 spirit-cave guardians | ×1.6 |
| Deliver | bring herbs, demon bones or demon cores | ×0.8 |
| Break a Beast Tide | be there when a tide is broken | ×2 |

- **Rewards:** base rewards are 40, 150, 500 and 1,500 stones by grade. Kills by your companions count.
- **Claiming:** claim at any board. Your sect gets a 20% share, plus prestige.
- **Send disciple:** a sect master can hand a hunt or cave clearing to a disciple.
