With the **Sect Master's Command Token** you found your own sect, recruit disciples, give them ranks and duties, pay them every dawn and send them on missions. Right-click the token to open the **sect ledger**.

### Founding

- **Cost:** 30 spirit stones carried in your inventory. Your headquarters is where you stand; move it later with *Set headquarters here*.
- **How many you can lead:** 6, plus 3 per realm (up to Tribulation), plus 6 for every immortal realm.
- **The treasury:** on the Overview tab, *Deposit all spirit stones* converts carried stones into treasury value (low 1, mid 9, high 81, supreme 729). The *Take* buttons withdraw them.
- **Command Token recipe:** gold ingot, book and 3 low spirit stones (shapeless).

### The grounds

- **Size:** 64 blocks round the headquarters, or out to the edge of your farthest bound protection array plus a margin (up to 256), whichever is larger.
- **No monster or wild beast** springs up inside them. Only things that march in from outside (tides, sieges, war parties) come.

### Recruiting

- **Who:** wandering cultivators within 32 blocks appear in the **Recruit** tab. You can also sneak and use the token on one, or invite them while talking.
- **Signing gift:** three days of their standard wage, from the treasury.
- **Chance:** 45%, plus their favour toward you, plus 2% per current disciple (up to 15%), minus 12% for each realm they stand above you. Always between 5% and 95%.
- **Stragglers:** new recruits head to the sect and take a free **work post** (Sect Gate 2, Herb Fields 4 or 8, Alchemy Workshop 5, Forge Hall 5, Training Grounds 5), or **Patrol** if none is free. Stragglers far from home walk or teleport back.

### Ranks and wages

| Rank | Wage | Needs | Limit |
|---|---|---|---|
| Grand Elder | 300% | Golden Core | 1 |
| Elder | 200% | Foundation | 4 |
| Inner Disciple | 130% | Qi Refining | |
| Outer Disciple | 100% | | |
| Servant | 60% | | |

Standard daily wage by realm (low stones): Mortal 1, Qi Refining 3, Foundation 10, Golden Core 35, Nascent Soul 120, Soul Formation 400, Void Refining 1,300, Body Integration 4,000, Mahayana 12,000, Tribulation 36,000, Immortal 100,000.

### Pay and loyalty

- **Payday** is every dawn: wage × rank × their pay setting (50% to 300%) from the treasury.
- **Paid on time:** loyalty +2 (more for higher pay). **Unpaid:** −15.
- **Reward:** two days' wage for +12 loyalty.
- **Desertion:** at 0 loyalty a disciple deserts.

### Duties

| Duty | What they do |
|---|---|
| Escort | Follows and protects you |
| Guard Post | Stands guard at their post or the headquarters |
| Patrol | Walks the whole grounds |
| Mine | Brings spirit stones and metal ore to the storehouse each day |
| Gather Herbs | Brings pill herbs each day |
| Seclusion | Cultivates quietly, taking pills from the storehouse; +3 loyalty a day |
| Tend Herb Fields | Harvests and replants the Herb Fields |
| Refine Pills | Refines storehouse herbs into pills at the Alchemy Workshop |
| Forge Weapons | Forges metals and demon cores into weapons and treasures |
| Train | Drills at the Training Grounds: mastery grows, breakthroughs come |
| Gatekeeper | Keeps the Sect Gate: collects tolls and turns away intruders |
| Beast Keeper | Tends the sect's guardian beast: halves its feed and trains it |

### Orders

- **Stance:** Protect, Attack or Hold Fire.
- **Placing them:** *Stay here* makes your spot their post; *Use HQ* sends them back.
- **Assign bed:** they sleep there at night.
- **Summon:** brings a disciple to your side.
- **Attack my target:** aim and use the token, and every disciple within 64 blocks attacks. *Stand down* calls them off.
- **Missions:** a disciple leaves the world and comes back with spoils, wounded, or not at all.

| Mission | Reward | Difficulty |
|---|---|---|
| Hunt Demon Beasts | stones, demon bones, vein cores | normal |
| Herb Expedition | rare pill herbs | +5% |
| Explore Ancient Ruins | technique and spell manuals | −10% |
| Escort a Caravan | a heavy purse of stones | +10% |
| Train at a Spirit Peak | cultivation progress | +15% |

**Mission grades:**

- **Low:** Qi Refining, 5 minutes.
- **Mid:** Foundation, 8 minutes.
- **High:** Golden Core, 11 minutes.
- **Supreme:** Nascent Soul, 14 minutes.

The success chance rises with the disciple's realm and loyalty, and a **Mission Hall** adds 10%.

### Fellow players and tokens of authority

Other players can join your sect. Invite one by sneak-using the Command Token on them, or with `/sectfellow invite <name>`. One sect per player, the cultivation mod's sects included. Members deposit, draw stipends and use the storehouse at the **Sect Hall**.

| Grade | Token | May |
|---|---|---|
| 1 | Outer Disciple Token | pass the sect's formations; deposit; see the storehouse |
| 2 | Inner Disciple Token | + take from the storehouse; the Formation Hall |
| 3 | Elder Token | + invite players; issue and revoke Outer and Inner tokens |
| 4 | Grand Elder Token | + issue Elder tokens; run production; draw on the treasury (10% a day) |
| 5 | Sect Command Token | the master and the Deputy Sect Leader: everything |

- **Issuing tokens:** only at the **Jade Token Altar** inside a **Token Pavilion** (within 10 blocks of it).
- **Binding:** a token is bound to one sect and one holder. A token handed to someone else, or revoked, is void.

### Formations and the gate

- **Claiming plates:** the master or deputy claims the main mod's formation core plates for the sect by sneak-using the Command Token on them (up to 8).
- **Passing them:** every member with a Command Token or a linked pass token passes every claimed plate, and hired disciples and members' beasts pass without one. Sneak-using the token on a claimed plate opens the **Formation Hall**.
- **The Sect Gate:** with a gate built and a disciple on Gatekeeper duty, outsiders who step onto your grounds are asked for a toll (20 by default). They pay (`/secttoll pay`, a day's pass) or are escorted out. Members and allies pass freely; enemies at war get drawn blades.
- **Wards:** see [Sect Wards and the Sect Domain](Sect-Wards-and-the-Sect-Domain).

### The Sect Storehouse

One storehouse every member shares. Open it at any Steward's Ledger, from the Sect Hall, or with `/sectstore` near the headquarters. Takings by members other than the master are written in the sect's records.
