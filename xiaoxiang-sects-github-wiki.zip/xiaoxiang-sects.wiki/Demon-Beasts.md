Every Threateningly Mobs creature that appears is a **cultivating demon beast**: a realm, a nature, spells, body techniques and a rank. Beasts are built like the main mod's own demon beasts and gather qi and break through over time.

### Beasts of the Mountains and Seas

With the default roster (`[beasts] roster = MYTHS`), **26 beasts of the *Classic of Mountains and Seas*** are each played by the Threateningly Mobs creature that looks closest to it. Each takes the myth's name (English and 中文), nature and habitat. Sixteen roam the wilds:

| Myth | Played by | Nature | Where |
|---|---|---|---|
| Jiangshi 僵尸 | Elite Zombie Warrior | Blood | plains, woods, swamps, caves, at night |
| Nine-Tailed Fox 九尾狐 | Castylosaurus | Shadow | forests, taiga, snow |
| Tiangou 天狗 | Tall Mouse | Shadow | plains, mountains, badlands, at night |
| Bifang 毕方 | Plague Bird | Fire | savanna, desert, badlands, Nether |
| Dangkang 当康 | Steelboar | Earth | plains, forests, savanna |
| Gudiao 蛊雕 | Basalt Wyvern | Wind | mountains, shores, badlands |
| Feiyi 肥遗 | Fire Lizard | Fire | deserts, badlands, Nether |
| Huashe 化蛇 | Hydra Cub | Water | rivers, swamps, shores |
| Water Ghost 水鬼 | Tide Specter | Water | rivers, swamps, the sea, at night |
| Zhuhuai 朱厌 | Copas | Earth | mountains, savanna, jungle |
| Shanxiao 山魈 | Nature Fairy | Wood | forests, jungles, mountains |
| Pixiu 貔貅 | Guardian Statue | Metal | mountains, caves (rare) |
| Baize 白泽 | Regalhart | Holy | forests, taiga, snow (rare) |
| **Luwu 陆吾** | Forest Drake | Earth | *elite:* mountains, jungles, caves |
| **Bashe 巴蛇** | Ferox Deathworm | Poison | *elite:* swamps, jungles, deserts |
| **Xingtian 刑天** | Executioner | Blood | *elite:* badlands, dark woods, at night |

- **The three elites** also serve as Cave Lords, tide bosses, world bosses and warband leaders.
- **Where they're drawn from:** caves, herb grottos, secret realms, beast tides, nests and eggs draw only from these 16.
- **The other ten** are the **Great Evils**, which never spawn by themselves.
- **With `roster = ALL`**, every Threateningly Mobs creature appears instead, still under its myth name where it has one.

### Ranks

| Rank | Spawn weight | Usual realm at birth | Sub-stage | Spell damage | Extra health |
|---|---|---|---|---|---|
| Common | 40 | Qi Refining (70%), Foundation (25%), Golden Core (5%) | Early | ×1.0 | ×1.0 |
| Uncommon | 16 | mostly Foundation, up to Nascent Soul | Middle | ×1.15 | ×1.1 |
| Rare | 6 | Golden Core to Nascent Soul, rarely higher | Late | ×1.35 | ×1.3 |
| Boss | 2 | Nascent Soul to Soul Formation, up to Mahayana | Peak | ×1.6 | ×1.7 |

- **Rare beasts and bosses** know the spells of one or two realms beyond their own, loose an extra projectile and cast faster.
- **Fury:** once per fight, when a boss falls below 40% health it roars, heals 10% and gains Strength II, Speed II and Resistance for 30 seconds.
- **Born far out:** beasts born more than 3,000 blocks from spawn may be a realm stronger, and the Almanac's Danger setting adds more.
- **Matched to you:** wild beasts are capped one realm above the strongest player near them, and bosses don't roam near players below Foundation (see [The Harsh World](The-Harsh-World)).

### Built like true demon beasts

- **Zhenyuan:** a beast gets the main mod's demon-beast zhenyuan for its realm. A Golden Core (Middle) beast gains about +456 health and +99 attack; a Void Refining beast about +792 health and +270 attack.
- **Body defence and a qi shield:** every hit is first reduced by its body defence. Then its **qi shield** soaks part of the rest: 30% at Qi Refining, rising to 95% at Tribulation.
  - The shield lasts until its qi runs out (you'll hear glass crack), and refills over time.
  - **Wear the shield down, or hit hard enough to burst through it.**
- **Techniques:** the main mod's beast techniques for its bloodline, then its own elemental ones:

  | Nature | Bloodline |
  |---|---|
  | Fire | Jin Yu |
  | Ice | Shuang Ya |
  | Water | Xuan Wu |
  | Lightning | Xuan Ting |
  | Earth | Xuan Yuan |
  | Wood and Poison | Tai Bei |
  | Wind | Qingxiao Yulin |

- **Spells:** the spells of its nature for its realm, the main mod's common beast spells, and **great divine arts** for whatever its element:

  | Realm | Great art |
  |---|---|
  | Nascent Soul | Heaven-Piercing Cone |
  | Soul Formation | Sky-Splitting Sword Aura |
  | Void Refining | Star Fall |

- **Divine might:** every realm above Golden Core adds +20% spell damage, and beasts cast faster as they rise (a Nascent Soul beast every 1.3 s or so).
- **Flight:** beasts of Nascent Soul and above, and bosses from Golden Core, take to the air when a foe is within 48 blocks. They dive at you from above, so walls and rooftops don't protect you. They land when the fight ends.
- **The status panel:** a beast shows the main mod's own overhead panel: name, realm and stage, nature, rank, qi bar and health bar.

### How wild beasts spawn

The addon spawns beasts itself, around each player, so the wilds stay dangerous by day too. By default:

- **Rate:** every 6 seconds, 2 nearby spots are tried, each of which can bring a whole pack. At night and underground the rate is 140%; by day on the surface, 80%.
- **Distance and cap:** beasts appear 24–56 blocks away, and stop once 14 wild beasts are within 64 blocks of you.
- **Spacing:** a rare beast never appears within 40 blocks of another; a boss never within 128 blocks of another.
- **Despawning:** wild beasts with no player within 128 blocks fade away (named ones stay).
- **Never on a sect's grounds**, and never inside a cave except its own guardians.

All of this is set with the *[Beast Tide Almanac](Beast-Tide-Almanac)*.

### Drops

- **Spirit stones** by realm, and a chance of a **spirit vein core** from Foundation upward (60% at the highest realms). Looting raises both.
- **Cave guardians** always drop their core.
- **Herb grotto keepers** drop herbs instead of stones.
- **The main mod's demon cores and bones** drop as usual.
