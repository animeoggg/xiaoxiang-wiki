**[Home](Home)**

**Start here**
- [Overview](Overview)
- [Getting Started](Getting-Started)
- [Keys and Commands](Keys-and-Commands)
- [Server Settings](Server-Settings)
- [FAQ and Known Limitations](FAQ-and-Known-Limitations)
- [Version History](Version-History)
- [Credits and Disclaimer](Credits-and-Disclaimer)

**Cultivation**
- [The Harsh World](The-Harsh-World)
- [Dao Paths](Dao-Paths)
- [Mastery](Mastery)
- [Breakthroughs and Foundation](Breakthroughs-and-Foundation)
- [Dantian World and Soul Sea](Dantian-World-and-Soul-Sea)
- [Domain Expansion](Domain-Expansion)

**The mortal world**
- [The Mortal Kingdoms](The-Mortal-Kingdoms)
- [Town Wards and the Underworld](Town-Wards-and-the-Underworld)
- [Life in the Cities](Life-in-the-Cities)
- [Clan Estates](Clan-Estates)

**The wilds**
- [Demon Beasts](Demon-Beasts)
- [Great Evils and World Bosses](Great-Evils-and-World-Bosses)
- [Spirit Stone Caves and Herb Grottos](Spirit-Stone-Caves-and-Herb-Grottos)
- [Beast Tide Almanac](Beast-Tide-Almanac)
- [Beast Tides](Beast-Tides)
- [Companion Beasts](Companion-Beasts)
- [Secret Realms](Secret-Realms)
- [Spirit Veins](Spirit-Veins)
- [Ancient Battlefields](Ancient-Battlefields)
- [Encounters on the Road](Encounters-on-the-Road)

**Sects of the world**
- [Generated Sects](Generated-Sects)
- [Holy Sect Fairs](Holy-Sect-Fairs)

**Your sect**
- [Founding Your Sect](Founding-Your-Sect)
- [Buildings and Production](Buildings-and-Production)
- [Arrays and the Reservoir](Arrays-and-the-Reservoir)
- [Defending Your Sect](Defending-Your-Sect)
- [Sect Life](Sect-Life)
- [The Scripture Pagoda](The-Scripture-Pagoda)
- [Relations and War](Relations-and-War)
- [Tournaments and the Arena](Tournaments-and-the-Arena)
- [Sect Wards and the Sect Domain](Sect-Wards-and-the-Sect-Domain)

**Missions**
- [Missions and the Journal](Missions-and-the-Journal)
- [Sect Bounty Board](Sect-Bounty-Board)

**Crafting and items**
- [Minigames](Minigames)
- [Items and Recipes](Items-and-Recipes)
