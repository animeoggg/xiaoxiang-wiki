The **Build** tab of the ledger raises sect buildings.

1. **Choose:** pick a design, a style and a facing. The **Materials to gather** grid shows the full bill.
2. **Preview:** a glowing hologram follows you. Sneak and use the token (or press **Lay blueprint here**) to fix it.
3. **Deliver materials:** matching blocks are taken from your inventory.
4. **Building:** when everything is delivered, your disciples build it, about 60 blocks a second while the site is loaded. In creative, **Build now** needs no materials.

**Styles:** nine, combining Humble, Stately and Grand with Righteous, Neutral and Demonic.

| Design | Purpose |
|---|---|
| Sect Gate, Pillared Gatehouse | Mark your grounds; with Gatekeepers, take tolls |
| Main Hall | Where the master holds court |
| **Grand Arena** | 12 tiers of seats, a master's box and a betting house. Needed for duels, contests and tournaments |
| Disciple Residence, Servants' Quarters | Lodgings |
| Treasure Pavilion | Its formation pays 1% interest on the treasury (at most 250 a day) |
| Pavilion | Disciples meditate there: loyalty +1 for everyone |
| Alchemy Furnace, Forging Furnace | Open-air furnaces with cores |
| **Mission Hall** | Missions +10% success; the bounty board posts 8 a day |
| **Herb Fields** | Four big spirit-soil plots (low to supreme); farmers harvest and replant herbs that ripen over days |
| **Alchemy Workshop** | A hall around a true alchemy furnace; alchemists refine storehouse herbs into pills |
| **Forge Hall** | A smithy around a true refining furnace; smiths forge metals and demon cores |
| **Training Grounds** | Dummies, an archery wall and an obstacle course; trainees gain mastery and break through |
| **Scripture Pagoda** | The six-storey library (see [The Scripture Pagoda](The-Scripture-Pagoda)) |
| **Token Pavilion** | The Jade Token Altar, where tokens are issued |
| Ancestor's Cave | Its spirit vein feeds qi to companion beasts near the headquarters |
| Street Lantern | Lights the paths |

### The production cycle

Everything made goes into the storehouse, and the workshops draw what they need from it:

- **Herbs to pills:** Herb Fields (farmers) grow spirit herbs, and the Alchemy Workshop (alchemists) turns them into pills for disciples in Seclusion.
- **Metals and cores to gear:** mines (miners) bring metals, and missions and beasts bring demon cores. The Forge Hall (smiths) turns them into weapons, armour and treasures.
- **Fuel:** the treasury supplies spirit stones as furnace fuel for both.

A batch is made only when every ingredient is in the storehouse and the fuel in the treasury. What's missing is reported each morning and in the building's **Steward's Ledger**, where you also assign its workers.

- **Crafts:** every trade a disciple works earns craft experience and a rank: Apprentice, Journeyman, Adept, Expert, Master, Grandmaster. Each rank brings bigger harvests, richer veins, surer and finer pills and blades, and fatter tolls.
- **The sect runs itself:**
  - stones the workers bring in go to the treasury;
  - the armoury hands forged gear to the fighting disciples;
  - when the storehouse fills, the steward sells the cheapest surplus.
- **The disciples' exchange:** disciples earn **merit** of their own (duties, missions, kills) and spend it on what they need from the storehouse: healing pills, the breakthrough pill of their realm, manuals that suit their roots, gear. What the storehouse lacks becomes a **wish** they tell you about.
