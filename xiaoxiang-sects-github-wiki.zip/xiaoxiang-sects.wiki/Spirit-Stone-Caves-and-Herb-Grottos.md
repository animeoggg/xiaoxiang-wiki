Caves are the only source of spirit stone ore. Each is a great open gateway in a rock hill, a stair down to **three maze floors**, and a huge hall where the **Cave Lord** waits. Every floor is sealed until its guardians are dead.

### Where caves appear

- **Wild caves** are always **Low-grade**. The world is split into regions of 14 × 14 chunks; by default 40% hold one (set in the Almanac). About a third of wild caves are **Herb Grottos**.
- **Sect caves:** every generated sect owns one cave near its grounds, graded by its rank: Mid for Lower sects, High for Middle sects and Supreme for Higher sects.

### Elements

Every spirit stone cave has one element: **Blazing** (fire), **Frozen** (ice), **Tidal** (water), **Stoneheart** (earth), **Verdant** (wood) or **Abyssal** (dark).

- **Guardians** share its nature. With the default roster they're the myth beasts of that nature, with the elites Luwu, Bashe or Xingtian as Cave Lords.
- **Chests** favour technique and spell manuals of that element.
- **Herb Grottos** are kept by earth and water beasts only.

### Layout and guardians

1. **The gateway:** an 11 × 11 open door framed by stone pillars, cut into a rock face.
2. **The slope:** a broad stair tunnel down.
3. **Three maze floors:** a 6 × 6 grid of rooms with many dead ends and one true route down.
4. **Stairwells:** a spiral stair around a lit pillar joins the floors.
5. **The Cave Lord's hall:** a domed cavern about 53 blocks across, ringed by eight great columns.

| Cave grade | Floor 1 minions | Floor 2–3 minions | Elites and hall patrols | Hall elites | Cave Lord |
|---|---|---|---|---|---|
| Low | Qi Refining | Qi Refining | Foundation | Foundation | Golden Core |
| Mid | Qi Refining | Foundation | Foundation | Golden Core | Nascent Soul |
| High | Foundation | Golden Core | Golden Core | Nascent Soul | Soul Formation |
| Supreme | Golden Core | Nascent Soul | Nascent Soul | Soul Formation | Body Integration |

### Seals

- **Sealed floors:** a floor stays sealed while any of its guardians lives. Sealed ore can't be mined, sealed chests can't be opened, and grotto herbs can't be picked.
- **Hunting the last guardians:** trying a sealed chest makes that floor's guardians **glow for 2 minutes**.
- **Unbreakable rock:** spells and explosions never break cave rock, and beasts can't dig through it.
- **Nothing else spawns** inside a cave.

### Ore and treasure

- **Ore:** 1.8% of the rock on floor 1, rising to 3.4% in the hall. Better grades lie deeper and in better caves; a Low cave almost never holds anything above low-grade stone.
- **Chests:** 1 on floor 1, 2 on each lower floor and 2 treasure chests in the hall. They hold spirit stones, element manuals and pills; the hall always holds a technique and a spell.
- **Herb Grottos** have no ore. They hold pill herbs, seeds, more pills and manuals instead.
