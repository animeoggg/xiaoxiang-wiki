### The alarm

- **The Sect Alarm Bell:** recipe 3 stripped dark oak logs / stripped dark oak log, empty, stripped dark oak log / gold ingot, bell, gold ingot.
- **Ringing it:** for 2 minutes every disciple drops their work and takes a **battle station** in a ring inside the array, facing out. Sneak + ring to stand them down.
- **It rings itself** when a tide, war party, siege or invasion falls on the sect.

### How disciples fight

Every two seconds the sect looks over its grounds and plans:

| Situation | What they do |
|---|---|
| A foe one disciple can beat | The nearest such disciple fights it alone |
| A strong foe | A band forms until their combined strength is enough (up to 6). Nobody charges a boss alone |
| Too strong for anyone free | Nobody rushes it. The rest hold the line inside the array |
| It reaches the heart | Everyone closes ranks on it |
| A disciple below 30% health | Falls back to the headquarters to heal, rejoins at 70% |

- **Ranged arts:** every disciple casts arts at foes within 32 blocks and looses **Sword Qi** from 24 blocks, through your own array.
- **Domains:** Elders of Nascent Soul and above unfold domains when hard pressed.
- **Defense orders** (Sect Hall → ⚔ *Defense orders*):
  - **Fight:** go out and meet the foe.
  - **Hold the line:** stay inside the array and shoot.
  - **Retreat:** everyone to the headquarters.

### What attacks a sect

- **Beast tides** at dusk (see [Beast Tides](Beast-Tides)).
- **War parties and sieges** from generated sects at war with you (see [Relations and War](Relations-and-War)).
- **Demonic invasions:**
  - **Warning:** at dusk, scouts may warn that a demonic sect marches on your sect (sects with 3+ members whose master is near; at most every 5 days).
  - **The attack:** at midnight it strikes in three waves: cultists, then an elder with his followers, then the demonic patriarch himself.
  - **Captives:** disciples it overpowers are dragged to its war camp (two at most). Rescue them within five days.
  - **The outcome:** break all three waves for spoils and prestige. If they still stand at dawn, they withdraw with part of the treasury.
  - **Gatekeepers** at the Sect Gate thin the first wave.
- **Kidnappings and assassins** (see [Encounters on the Road](Encounters-on-the-Road)).

### Seeing the battle

- **The Missions window** shows tides, sieges and war parties within 160 blocks or on your sect: countdown, wave, foes left, array % or BROKEN, plunder and your kills.
- **The live sect map** (**N**) shows terrain from above, buildings, the arrays' circles with their qi, alarm bells, disciples coloured by duty (red when fighting), players and every foe, with bosses larger. It refreshes every second; scroll to zoom and drag to pan.
- **Battle reports:** after every attack a report opens for the leader and everyone who fought. It shows VICTORY or DEFEAT, the numbers, defenders ranked by damage (★ top), the fallen and a timeline. The sect keeps its last 8: Sect Affairs → Battle Reports, or `/sectreport`.
