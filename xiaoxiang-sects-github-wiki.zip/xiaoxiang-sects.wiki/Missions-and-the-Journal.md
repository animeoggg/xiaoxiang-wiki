### The Missions window

A live window on the **left middle of the screen**, shown only when something's going on. **U** cycles it full / compact / hidden; **Shift+U** hides beast nests.

- **⚔ Tides, sieges and war parties** within 160 blocks, or on your sect anywhere: countdown, wave, foes left, array %, plunder and your kills.
- **⚑ Defense orders** and the **alarm**.
- **✎ Bounties** with progress bars, and **➹ disciple missions** ("back in 4:12").
- **⚒ Construction** progress.
- **Also:** nests, story chapters, escorts, world bosses, council plots, requests, domains and the **tracked mission** with a live arrow and distance.

### The Mission Journal (O)

Every mission, request, bounty and piece of news in one place.

- **Tabs:** All, Board, Quests, Asks, Beasts, Sect, Honours.
- **Details:** each entry shows its steps (✔ done, ➤ now), the giver, the reward, the time left and an **arrow** to where you go.
- **Buttons:** **Track** pins a mission to the Missions window, **Abandon** (click twice), **Accept** (from the Board), **Bear title** (Honours) and **Resume** a closed scene.
- **Keys:** ↑ ↓ choose, T track, O or Esc close.

### Thirty missions

Missions come in steps, with scenes in the conversation window, foes and people appearing as each step starts, live arrows, time limits and rewards. Up to **5 at once** (requests and bounties don't count).

**Where to find them:** the **Board** tab (about 8 a day, plus 3 dailies and the next story chapter), wandering cultivators (*"Any greater task?"*), and your disciples (*"Ask about their past"*).

| Group | Missions |
|---|---|
| ➹ On the road | Escort the Travelling Elder · Bounty: the Rogue Cultivator · The Lost Disciple · A Duel of Honour · The Sealed Letter · The Heart-Demon (purify or end) · Guard the Royal Caravan |
| ⚑ For your sect | Recruitment Drive · The Elders' Build Order · Supply Crisis · The Inner-Sect Examination · A Traitor Within (accuse one of four) · Hold the Vein · Scouts Warn of a Tide · Weekly Challenge: The Great Hunt |
| 🐾 Beasts | The Egg and the Hatchling · Trials of the Beast King · Poachers at the Nest · A Beast for the Elders · The Great Migration (protect or hunt) · Bonds of the Hunt |
| 🌍 The world | Map the Region · Into the Secret Realm · The Moonlit Herb Route · Echoes of the Ancient Battlefield |
| ☀ Daily | Thin the Wilds · Gather Herbs · Patrol the Road, with a growing streak bonus (up to 10 days) |
| ✦ Story | **The Path of Ascension**, one chapter per realm: The Fallen Star → The Masked Sect → Blood on the Foundation → The Golden Tribulation → Dreams of the Nascent Soul → Ascension's Gate |
| ❤ Disciples' stories | Blood Debt · The Old Master · The Family Sword |

### Requests

Small quests from cultivators on the road, your disciples, your beasts and the wild beasts you parley with: slay so many of a kind (alone, or with a companion beside you), or bring so many of a thing. Up to 4 at once, 3 days each. Kills are counted as you go.

### Story chains and escort contracts

From **Sect Affairs**:

- **Story chains** (Quest Journal), one at a time:
  - *The Missing Elder:* Elder Mo joins your sect as an Elder.
  - *The Sealed Demon Beneath the Mountain:* its egg is your reward.
  - *The Rival Sect's Spy:* your elders' loyalty rises.
- **Escort contracts:**
  - **The ward:** a Spirit-Stone Caravan (a laden mule), an Envoy or a Herb Merchant's Wagon must reach a place 300–700 blocks away.
  - **Ambushes:** bandits and beasts strike every minute or so.
  - **Success:** bring the ward within 10 blocks of the destination for the purse, plus a bonus per ambush beaten.
  - **Failure:** if it falls, or you leave it behind for a minute, the contract is lost.

### Honours: reputation, achievements and titles

- **Reputation:** four powers remember what you do: the **Mortal Kingdoms**, the **Righteous Sects**, the **Wandering Cultivators** and the **Beasts of the Wild**. Ranks go Hated, Distrusted, Neutral, Known, Respected, Honoured, Exalted, and higher ranks open missions.
- **Achievements:** each comes with a title. Wear one title at a time for its small lasting gift; it's shown in your conversations.

| Achievement | Title | Gift |
|---|---|---|
| First Steps (1 mission) | the Fledgling | luck |
| Errand Runner (10 missions) | the Reliable | speed |
| A Legend of the Road (50 missions) | the Legendary | health |
| Beast Slayer (100 beasts) | Beast Slayer | attack |
| Bane of the Wilds (1,000 beasts) | Bane of the Wilds | attack |
| Beast Tamer | the Beast Tamer | armour |
| Born of Fire (hatch an egg) | Egg-Warden | health |
| Tidebreaker | Tidebreaker | armour |
| Gatherer of Talents (10 recruits) | the Gatherer | luck |
| Founder of Halls (5 buildings) | the Architect | health |
| Cartographer | the Wayfarer | speed |
| Realm Walker | Realm Walker | speed |
| Honourable Duelist (3 duels) | the Honourable | attack |
| Diligent (7-day streak) | the Diligent | luck |
| The Path Walked (the story) | the Ascendant | health |
| Beloved (Exalted with a power) | the Beloved | armour |
