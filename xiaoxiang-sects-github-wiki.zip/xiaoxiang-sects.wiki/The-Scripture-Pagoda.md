A great six-storey pagoda that holds your sect's technique and spell manuals. Members earn **merit** and spend it on manuals; each floor holds better ones and is watched by stronger guardians.

### Building it

1. **The altar:** craft the **Scripture Altar** (book / gold ingot, lectern, gold ingot / 3 stone bricks).
2. **The pagoda:** raise the **Scripture Pagoda** design: 31 × 31, six storeys.
3. **The floors:** each floor has an altar at its centre.

| Floor | Name | Manuals | Price in merit |
|---|---|---|---|
| 1 | Hall of Foundations | Low | 30 |
| 2 | Hall of the Golden Core | Mid | 80 |
| 3 | Hall of Souls | High | 200 |
| 4 | Hall of Heaven | Supreme | 500 |
| 5 | Immortal Sutra Hall | Immortal | 1,200 |
| 6 | Guardian's Peak | the senior guardian's post | |

- **Record:** deposit a manual at any altar; it's shelved on its grade's floor.
- **Copy:** any member may have a recorded scripture transcribed for their merit.
- **Teach:** the master assigns a scripture to a disciple, who pays from their own merit.
- **Donate:** 500 treasury stones buy 100 merit.

### Merit

| Source | Merit |
|---|---|
| Daily, by rank (Grand Elder / Elder / Inner / Outer / Servant) | 8 / 6 / 4 / 3 / 1 |
| A successful mission | 8 × (grade + 1) |
| A bounty | 5–80 |
| Breaking a beast tide | 25 for the master, 15 for each member present |
| A successful raid | 40 + 20 × the sect's tier |
| Conquering a secret realm | 60 |
| Kills by a disciple | 1 / 3 / 5 |

**Guardians:** assign Elders or above to guard a floor. They learn the techniques of their floor's tier and are raised in strength to hold it.
