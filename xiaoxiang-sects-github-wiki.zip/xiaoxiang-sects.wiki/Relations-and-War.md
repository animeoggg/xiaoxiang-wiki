The **Relations** tab lists every other player sect and the **20 nearest generated sects**, so diplomacy works in single player too.

### Player sects

| Standing | How it starts | Effect | How it ends |
|---|---|---|---|
| Neutral | default | | |
| Allied | you propose, they accept | no harm between you; allies come to each other's aid | either side breaks it |
| At War | either side declares it | disciples attack the enemy on sight; kills are scored | a peace offer is accepted, or one side surrenders (20% of its treasury) |

- **Offers:** alliance proposals, peace offers, **trades** (storehouse goods and stones, nothing moves until accepted) and **contest** challenges wait in the Offers view.
- **The Council:** war and alliance motions go to the Elder Council first.

### Generated sects

Each generated sect has an **attitude** toward your sect (−100 to +100): Friendly (30+), Indifferent, Wary or Hostile (−50 or lower).

| Raises attitude | Lowers attitude |
|---|---|
| Gifts from your treasury (up to +25 each) | killing one of their members (−20) |
| Helping them break a beast tide (+15) | declaring war (−40) |
| Feeding their array, helping their wardens | breaking an alliance (−20) |

- **Alliance:** at attitude 30+ (and enough prestige), they send 5, 15 or 40 stones each dawn.
- **War:** their members hunt your master and disciples, and yours hunt theirs.
  - **They can declare war on you** (attitude −50 or lower, 30% a dawn).
  - **War parties:** at dusk they may send a war party of disciples, elders and a War Leader.
  - **Demand peace** when your kill score leads by 3, or **pay tribute** to end it.
- **Lead a raid:** within 15 minutes, slay 5 / 8 / 12 of their members on their grounds. Success sacks the sect: 400 / 1,500 / 5,000 stones, prestige +2, war score +5. Once every 3 days per sect.

### Sieges

- **Sieges on you:** a generated sect at war may lay a full **siege** to your headquarters: five waves, **array-breakers** and catapult volleys every 40 seconds.
  - **Victory:** spoils, prestige +3 and **prisoners**.
  - **Defeat:** 15% of the treasury plundered.
- **Besieging them:** with a war score of 8 or more, **Lay siege** (800 / 2,500 / 8,000 stones to march).
  - **Within 25 minutes:** slay the defenders, seize the three **formation nodes** (stand by each for 15 seconds, or use a Formation-Breaking Talisman), then slay the **Patriarch**.
  - **Victory:** the sect becomes your **vassal**, with double raid loot and prestige +6.

### Vassals, prisoners and coalitions

- **Vassals** pay tribute every dawn (150 / 500 / 1,500 at Normal tax).
  - **Tax:** Light, Normal or Heavy.
  - **Troops:** muster troops to send auxiliaries into your battles.
  - **Governor:** station an elder as governor.
  - **Levy:** levy a one-off payment.
  - **Release:** set them free.
  - **Rebellion:** they rebel if resentment runs deep.
- **Prisoners** (up to 8): ransom them, recruit them (50%), trade them for peace or release them.
- **Coalitions:** with 2+ vassals or 40+ prestige, up to 3 generated sects may band together and declare war. Breaking a coalition gives prestige +5.
- **Siege engines:**
  - **Formation-Breaking Talisman:** seizes a node at once.
  - **Qi Battering Ram:** a shockwave on enemies within 8 blocks.
  - **Flame Arrow Volley:** fire on enemies within 14 blocks.

### The Wanted Board

In the **Mission Hall**, during a war, put a price on an enemy's head: their Sect Master or a disciple, or (against a generated sect) any five of its cultivators. The stones are held in escrow; whoever slays the target collects (a disciple's kill is paid to their master). Bounties lapse after seven days, or when the war ends, and are refunded.
