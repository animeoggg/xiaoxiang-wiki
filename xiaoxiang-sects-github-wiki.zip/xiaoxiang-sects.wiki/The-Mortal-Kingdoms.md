Vanilla villages and villagers are gone. The world holds the walled **villages, towns and capitals** of the mortal kingdoms, hundreds of blocks across, each ruled by a cultivation clan (a capital by its mortal **king**, from his palace).

### Settlements

| Size | Across | Ruled by | What's inside |
|---|---|---|---|
| **Village** | about 220 blocks | a clan | fields, homes, shops, an inn, a shrine |
| **Town** | about 330 blocks | a clan | markets, guild halls, smithies, martial halls, an arena, inns and restaurants |
| **Capital** (City) | about 510 blocks | the King, from his palace | everything a town has, plus the royal palace, the royal guard, the bank and the House of Fortune |

- **Where:** each region of 1,280 blocks may hold one settlement (85% do), worked out from the world seed and the terrain, so the same world always has the same towns.
- **Kingdoms:** there are 20 (Wei, Zhao, Qin, Chu, Yan and the rest), and 14 ruling clans (Lin, Xiao, Mu, Ye, Su, Gu, Bai, Feng, Long, Yun, Jiang, Tang, Han and Qin).
- **Its people are mortals:** shopkeepers, cooks, innkeepers, smiths, farmers, martial artists, the gate guard, sentries on the towers and the watch patrolling the streets. They go home at night. Only the clans cultivate.
- **Appearing and replacing:** people appear a district at a time as you approach. Anyone who dies is replaced at dawn.
- **The town guard** looses arrows at monsters, wild beasts, beast tides and bandits within bowshot, and at anything attacking a townsman. Their arrows never hit townsfolk.
- **Finding them:** `/sectcity nearest`, the Jade Waypoint Slip (creative) and the lecterns in every town, which are notice boards that tell you where everything is.

### Strong and weak lands

Every kingdom has a **power** and every settlement a **might**, fixed by the world seed.

| Kingdom power | Share | Effect |
|---|---|---|
| Fallen | ~12% | pulls its towns down one step; its royal guard is few and weak |
| Minor | ~25% | |
| Middling | ~33% | |
| Great | ~20% | lifts its towns up one step |
| Imperial | ~10% | lifts its towns up one step; its royal guard is among the strongest anywhere |

| Might | Toll | Tribute | Patriarch | Town watch | Bandit raid chance | Built of |
|---|---|---|---|---|---|---|
| **Struggling** | ×0.5 | ×0.5 | Qi Refining | leather, stone blades | 30% | wattle-and-daub, holed shingle roofs, a log palisade, dirt paths, cobwebs |
| **Humble** | ×0.75 | ×0.75 | Qi Refining | chainmail cap | 24% | plaster on cobble, rubble walls |
| **Thriving** | ×1 | ×1 | Foundation | iron | 18% | the town's own style |
| **Prosperous** | ×1.5 | ×1.4 | Golden Core | iron, Strength II | 12% | lime plaster on polished deepslate, polished roads |
| **Mighty** | ×2.5 | ×2 | Golden Core (Nascent Soul in a capital) | diamond helm and blade, Resistance | 6% | marble terraces, red-lacquered pillars, glazed copper roofs, blackstone walls with gilded veins |

- **What sets might:** villages lean weak and towns lean middling. A capital follows its kingdom.
- **Holy Sects:** a settlement within 1,600 blocks of a Holy Sect gains +1 might, and its market stocks that sect's goods.
- **Trades:** a struggling settlement is always a farming village; a mighty one is never a farming town.
- **The gate sign** shows the real toll, and arriving tells you the kind of place and its kingdom's power.

### Favour with a kingdom

Your **favour** is kept per kingdom. It rises with gifts to the king, royal commissions, guild contracts, guarding the town, beating riots and more.

| Title | Favour | Gift |
|---|---|---|
| Commoner | below 10 | |
| **Royal Guest** | 10 | pass every gate of the kingdom without toll (and the outer ring) |
| **Knight of the Realm** | 40 | 10% off in the kingdom's shops; pass the inner ring free; the Seal Office sells you an **Ascension Seal** (6,000◆, one a day) |
| **Marquis** | 100 | 20% off; a daily **stipend** of 60 + 60 × size ◆; received in the palace; may petition for the crown's **foundation manual** (1,500◆, once) |
| **Duke** | 250 | may petition for a **Dao Foundation Fruit** (3,000◆, once) |

**At the palace:**

- **Present a gift:** +10 favour, three a day at most.
- **A royal commission:** a task for stones and favour, finished within two days.
- **Duel the King's Champion:** win for +20 favour and a purse.
- **The guard's trial:** defeat one of the royal guard in two minutes for +5 favour and 60◆, once a day.

### Your sect and the towns

A Sect Master can deal with a settlement's ruler:

- **Offer protection:** the town pays your sect a daily **tribute**, and you defend it from bandit raids (the raid chance depends on its might). Your sect enters without toll.
- **Demand surrender:** defeat the ruling clan's cultivators (in a capital, the royal guard and the ruling clan) within 10 minutes. You get **double tribute**, but restless subjects: a conquered town may **rise in rebellion** unless it is held.
- **Garrison:** station disciples who came with you. They keep the gates, the plaza and (in a capital) the castle bridge, fighting beside the town guard. A garrison keeps a conquered town from rising, steadies a protected one, and drives off bandit raids even while you're away.
- **When the cultivation mod's demon sieges** strike a town, the kingdom rewards its defenders and mourns a fallen town.
