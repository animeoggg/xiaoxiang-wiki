### Chance meetings

Every so often, near a cultivator travelling the overworld:

- **A dying expert** lies by the way. Speak with him to receive his inheritance (or his last test).
- **A travelling auction** of the Myriad Treasure Pavilion sets up its stall. Bid against rival buyers with `/sectauction`.
- **Two sects' disciples fight a duel** nearby. Join one side with `/sectduel`, and that sect remembers it.

### The Spirit Caravan

- **When:** every **4 days** a Spirit Caravan Merchant arrives near a player for one day, selling cultivation goods and beast gear for spirit stones.
- **The auction:** it carries one rare lot, a treasure or a Gate Key. Sneak + right-click the merchant with spirit stones in hand to bid; generated sects bid too.
- **When it leaves,** the highest bidder takes the lot and outbid players are paid back, even if offline.

### Wandering cultivators

Sneak + right-click with an empty hand:

- **News and advice:** their greeting, the road's news, and a word of advice for your realm.
- **Requests:** slay or bring something, for stones and regard. Up to 4 at once, 3 days each.
- **Small talk:** +3 regard a day.
- **Teaching:** at high enough regard (90 in the harsh world), a pointer in one of their own arts.
- **Recruiting:** a sect master may invite them to join.
- **Beast tamers** travel with a companion: recruit the tamer and the beast comes too.

### Demonic threats

- **Assassins:** at night, Golden Core cultivators and above may be stalked by demonic assassins, each carrying a purse.
- **Kidnappings:** demonic cultists may kidnap a disciple of a sect with 3 or more members to a hidden camp 150–250 blocks away. Rescue them within **5 days**.
- **Heaven's trials:** when the heavens send a tribulation, your companion beasts and nearby disciples shoulder part of the lightning. Surviving brings **Heaven's Favour** (regeneration, a qi barrier and strength for 5 minutes).

### Notoriety and bounty hunters

Crimes make you famous in the wrong way. **Notoriety** is kept per player and fades a little each day.

| Deed | Notoriety |
|---|---|
| Theft from a sect library | +6 (+10 if caught) |
| Leading a raid | +6 |
| Laying a siege | +15 |
| Thrown out of a ward, palace or clan ring | +10 |
| A clan heirloom stolen | +30 |
| Joining a riot or a siege of a clan | +10 to +15 |
| A kill in war | +1 (one time in three) |

- **At 30 or more,** named **bounty hunters** come for you, each with a style of their own: Lin Feng (Swift Blade), Zhao Shan (Iron Palm), Mei Xue (Frost Lotus), Han Lei (Thunder Spear), Ye Ying (Shadow Step) and Du Qing (Poison Needle).
- **Killing one** pays 150 × realm² stones and lowers your notoriety by 15.
- **Clearing your name:** pay your fines at a town's customs house.
