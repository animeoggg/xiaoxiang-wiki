The settings live in `<world>/serverconfig/xiaoxiang_sects-server.toml`. Edit the file with the world closed, or use the in-game commands, which save to it. The Beast Tide Almanac's spawn settings are saved with the world instead (see [Beast Tide Almanac](Beast-Tide-Almanac)).

### `[harsh_world]`

| Key | Default | What it does |
|---|---|---|
| `enabled` | true | The whole harsh world on or off (every value below applies only while on) |
| `cultivation_speed` | 0.5 | Multiplier on cultivation from absorbing qi and meditating |
| `breakthrough_penalty` | 15 | Percentage points off every breakthrough chance (never below 1%) |
| `realm_gap_damage_up` | 0.4 | Extra damage per great realm when the stronger strikes the weaker (up to ×4) |
| `realm_gap_damage_down` | 0.7 | Damage kept per great realm when the weaker strikes the stronger (never below 15%) |
| `realm_pressure` | true | The aura of cultivators two or more realms above you slows and weakens you |
| `predator_chance` | 20 | % chance a far stronger loose cultivator in the wilds preys on you |
| `price_multiplier` | 1.5 | Price of cultivation goods in the addon's shops and counters |
| `technique_rarity` | 0.35 | How often wandering cultivators still carry spell books and manuals |
| `teaching_regard` | 90 | Regard a wandering cultivator needs before teaching you an art |
| `chest_loot_keep` | 0.4 | Chance a stack of cultivation goods in a chest is kept (kept stacks are halved) |

### `[wild_scaling]`

| Key | Default | What it does |
|---|---|---|
| `enabled` | true | Match wild spawns to the nearest player's realm |
| `realms_above_player` | 1 | How far above you a wild demon beast may be |
| `boss_min_realm` | 2 | Realm needed before boss-rank beasts roam near you (2 = Foundation) |
| `unmatched_beyond_blocks` | 10000 | Beyond this distance from spawn the wilds are not matched (0 = matched everywhere) |
| `natural_max_health` | 60 | Health limit on other mods' natural monster spawns near a Mortal or Qi Refining player |
| `natural_health_growth` | 2.5 | How much that limit grows per great realm |

### `[reservoir]`

| Key | Default | What it does |
|---|---|---|
| `vein_core_conversion` | `SNEAK_USE` | `OFF`, `SNEAK_USE` (sneak + empty-hand right-click) or `ALWAYS` |
| `peace_rate_percent` | 10 | Refill per second in peace, % of the core's maximum |
| `siege_rate_multiplier` | 2.0 | Multiplier on the refill speed under attack |
| `stone_worth_multiplier` | 2.0 | Qi per stone (and per treasury stone), as a multiple |
| `draw_from_vein_cores` | true | Draw on nearby Spirit Vein Cores before using stones |
| `passive_qi_per_second` | 20 | Qi a reservoir gathers by itself each second |
| `passive_qi_per_tier` | 40 | Extra passive qi per tier of the vein core it came from |
| `passive_qi_cap` | 50000 | Most passive qi it keeps banked |

### `[spirit_vein_grottos]` and `[beasts]`

| Key | Default | What it does |
|---|---|---|
| `protection` | `SURFACE` | `FULL` (grotto and the land above), `SURFACE` (only the grotto, its stair and gate), `OWNERS` (as SURFACE, and the owning sect's leaders may build inside) or `OFF` |
| `roster` | `MYTHS` | `MYTHS`: only the Mountains-and-Seas beasts, with the great evils only at the altar or their omens. `ALL`: every Threateningly Mobs creature |
