Crafting, sealing, stealing and taming are done by hand. Each opens its own screen, and the score decides the result. A higher **profession grade** makes a game gentler and its result better: alchemy or refining rank, realm for arrays and locks, foundation quality for breakthroughs. A fitting Dao Path helps a little more.

### Crafting gates

The main mod's cores only work through a minigame: choose the recipe in the core's own screen, press its button, then play.

| Core | Minigame | Score effect |
|---|---|---|
| Alchemy Core | **Pill refining:** keep the furnace's heat inside the moving band | 90%+: chance to rise a grade; below 40%: part of the batch spoils; overheat and it explodes |
| Refining Core | **Forging:** strike as the glowing beats reach the anvil | 90%+: masterwork, a grade higher; below 30%: lesser or cracked |
| Formation Core Plate | **Array activation:** trace the runes | 60%+ activates the array |

**Inscribe a flag** (in the Formation core screen) plays the rune game to make a formation flag. It costs 50, 200, 800, 3,200 or 12,800 stones by grade. A flawless score makes two.

### Other minigames

| Minigame | When | How to play |
|---|---|---|
| Breakthrough consolidation | after rising a stage | keep the qi orb inside the shrinking circle |
| Mastery bottleneck | Break Through on the Mastery screen | the same, harder for Grandmaster |
| Theft skill checks | a chest in a sect library | press SPACE while the needle is in the zone |
| Rune lock | Epic and Legendary realm caches, rune seals | stop each sealing ring with its rune at the top |
| Space tear | a gate too narrow for your realm | tear each spatial node as the qi line crosses it |
| Herb uprooting | harvesting a spirit herb | pull steadily without tearing the root |
| Battle of wills | a Beast Subduing Talisman | tap SPACE to win the tug-of-war |
| Talisman brush | sealing at the Talisman table | trace the strokes; 40%+ seals it |
| Artifact repair | a Broken Artifact near a Refining Core | forging rhythm |
| Arm wrestling | a town's martial hall | press SPACE as the needle crosses the green |
