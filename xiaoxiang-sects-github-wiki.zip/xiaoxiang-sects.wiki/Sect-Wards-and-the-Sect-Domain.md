### Sect wards

Your sect can keep three rings around its headquarters, as the towns and clans do. Use `/sectwards` (the sect master).

| Ring | Default size | Who may enter |
|---|---|---|
| Outer | 64 blocks | anyone who pays your **entry fee** (20 stones a day, into the treasury) |
| Inner | 36 blocks | your sect's own players |
| Core | 14 blocks | the master, deputy and elders |

- **Trespassers** are warned, set upon by your disciples after 30 seconds and thrown out after a minute.
- **Wandering cultivators** passing through the outer ring pay the fee too.
- **Faint lines of light** mark each ring near where you stand.
- **Commands:** `/sectwards on|off`, `fee <stones>`, `rings <outer> <inner> <core>`.

### The Sect Domain

When its master has become an **immortal**, a sect can fold a world of its own: a great floating island in its own dimension that only the sect's token holders may enter.

- **Fold it open:** 20,000 stones from the treasury.
- **Move the sect into the Domain**, or to wherever the master stands. The headquarters grounds are carried over a slice at a time. The grounds left behind are emptied, and formations must be bound again where they now stand.
- **Enter and leave** from the Sect Hall.
