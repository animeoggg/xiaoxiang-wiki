Now and then a **gate** tears open in the world and stays open for **3 days**: a tall glowing oval coloured by its rank. Step through it to reach a realm of floating islands. Clear it before it closes, or it **breaks** and its beasts pour out onto the land as a beast tide.

### Gates

- **When:** each midday there's a 12% chance a gate opens 60–140 blocks from a random player, one at a time. Everyone is told where. A **Gate Key** opens one of its rank beside you.
- **Rank** is rolled by distance from world spawn: the farther out, the higher.

| Gate | Colour | Minions | Elites and Island Wardens | Realm Sovereign |
|---|---|---|---|---|
| D-Rank | blue | Foundation | Golden Core | Nascent Soul |
| B-Rank | teal | Golden Core | Nascent Soul | Soul Formation |
| A-Rank | violet | Nascent Soul | Soul Formation | Void Refining |
| S-Rank | red | Soul Formation | Void Refining | Body Integration |

**Modifiers** some gates roll:

- **Blood Moon:** every beast one realm higher, and better caches.
- **Fog.**
- **Frenzy:** faster, fiercer beasts.
- **Bountiful:** richer caches.
- **Immortal Resonance:** S-Rank gates near an immortal. Mahayana minions, Tribulation elites and an Earth Immortal Sovereign. Clearing one counts toward the immortal road.

### Entering

- **Space tear:** a cultivator **above a gate's realms** can't simply walk in: the gate is too narrow. A timed minigame opens: strike each spatial node as the sweeping qi line crosses it, before the pressure of space crushes the tear shut. Fail and you're thrown back hurt, and must wait.
- **Cultivation suppression:** inside, a cultivator above the Sovereign's realm is pressed down by its laws (weaker blows, harder blows against them), and techniques above the realm's cap are sealed. Dying while suppressed **wounds your foundation**: stage progress is lost and you're weak for a while, but never a whole realm.
- **The void:** falling below the islands is death for anyone, beast or cultivator.

### The islands

A great central island where the **Realm Sovereign** waits at its altar, ringed by islands of different lands and purposes. They're joined by bridges with gaps to leap and boards that crumble underfoot. A **sky shrine** high above is reached only by a parkour trail of floating stones.

| Island | What waits there |
|---|---|
| Pagoda, Library | Buildings full of beasts and caches |
| Killing-array isle | A deadly array; break its lodestone core to shatter it |
| Trapped shrine | Pressure plates hide arrows, fire, poison, lightning and ambushes |
| Beast nest | A swarm of beasts |
| The Great Maze | A walled maze with a cache at its heart |
| Ore crag | Spirit ore boulders |
| Brazier vault | Light all five braziers to open it |
| High / Humble Sanctum | Arrays admit only cultivators at least as strong as the elites, or no stronger than the minions |
| Spirit garden | Pill herbs |
| Sky shrine | A lone elite on a crystal peak |

**Trials along the way:**

- **Gatekeepers:** cultivators who guard a door or shrine. Challenge one to a spar (no one dies) and win to pass.
- **Rune seals:** a seal stone beside a sealed door. Break its rune rings (the lock minigame) to open it.
- **Waystones:** golden plates that carry you back to a gate.

### The rules of a realm

- **Every boss must fall.** Each island has an **Island Warden**; the Sovereign holds the centre. A bar at the top of the screen counts the guardians still standing.
- **Sealed until the end:** chests stay sealed, and nothing can be broken, built or blown up, until the Sovereign and every Warden are dead. Opening a cache makes every remaining guardian glow for 30 seconds.
- **Guardians keep to their posts:** only a player's hand can fell them, and any that go missing are raised again.
- **No flying** until the realm is conquered.
- **The Sovereign** calls its guard at two thirds health, then seals the arena and rages at one third. Four crying-obsidian eyes around its altar protect it while they stand.
- **Bait:** some chests spring an ambush.

### Loot and conquest

- **Caches** come in four qualities (Common, Rare, Epic, Legendary): spirit stones, high-level technique and spell manuals, pills, treasures and sometimes **Gate Keys**.
- **Rune locks:** even after conquest, Epic and Legendary caches are sealed by rune rings. Pick the lock to open them; fail and guardians are called.
- **Conquest:** when every boss has fallen, a **golden gate** opens at the altar. Your clear is scored (time, deaths, rank) and the best clear per rank is announced to the server. The Sovereign may drop a Gate Key.
- **Leaving:** the pale gate you arrived by always leads out. When the gate closes, everyone inside is cast out.
