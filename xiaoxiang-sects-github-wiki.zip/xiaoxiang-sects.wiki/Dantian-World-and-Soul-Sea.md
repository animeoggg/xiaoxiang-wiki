### 丹田世界 The Dantian World

Your own body as a world. Open it with **H** or the **☯ Dantian World** button on the cultivation menu. It has four tabs.

**Meridians (经脉)**

- **The map:** your body with **24 acupoints** along its meridians, including the three dantians, the Sea of Qi, the Gate of Life and the Niwan Palace.
- **Meridian points:** you have 2 at Qi Refining, and earn **one for every stage and great realm** you break through.
- **Opening a point:** click a glowing point next to an open one to force your qi through it. It costs 1 point and 20% of your qi. Some points need a higher realm.
- **Every open point is a permanent gift:** qi recovery, cultivation speed, max health, attack, armour, speed, attack speed, luck, soul strength, Dantian Guard strength, Dao seed growth, extra storage or an extra Dao seed slot.

**Storage (丹田)**

- **Never lost on death:** items kept inside you.
- **Size:** 9 slots per great realm (up to 54), plus 9 when the **Spirit Gate** opens.
- **Anywhere:** the **Dantian Talisman** opens it from anywhere (recipe: eye of ender / gold ingot, paper, gold ingot / amethyst shard).

**Dao Seeds (道种)**

- **Planting:** plant crafted Dao seeds in your dantian's lotus pods. Seed slots: 1 at Foundation, rising to 5 at Mahayana, plus 1 from the Niwan Palace.
- **Growing:** they grow while you're online (twice as fast meditating), drinking a little of your qi, through 5 levels, each a permanent gift.
- **Grades:** Lesser seeds grow to level 2, Greater to 4 and Supreme to 5. Click a planted seed with a higher grade of the same kind to **refine** it.
- **Uprooting:** shift-click a seed to uproot it. Its gifts are lost.

| Seed | Per level | Lesser material | Greater material | Supreme material |
|---|---|---|---|---|
| Sword | +1 attack | iron swords | diamond swords | netherite ingots |
| Vajra | +1 armour | obsidian | diamond blocks | ancient debris |
| Life | +2 max health | golden apples | earth marrow ginseng | enchanted golden apples |
| Wind | +3% speed | phantom membranes | wind feather grass | dragon's breath |
| Thunder | +4% attack speed | lightning rods | tridents | end crystals |
| Spirit | +4% cultivation speed | low cultivation pills | high cultivation pills | immortal cultivation pills |
| Tide | +1 qi recovery | prismarine crystals | nautilus shells | hearts of the sea |
| Fortune | +1 luck | emeralds | emerald blocks | totems of undying |
| Soul | +1 soul strength | echo shards | snow soul lotus | void crystals |

The recipes are in [Items and Recipes](Items-and-Recipes). Possessing souls you slay leave a Lesser Soul Seed.

**Guard & Arts (护元)**

- **The Dantian Guard:** from Foundation, a ward of your own qi around your dantian, always on.
  - **Strength:** 300, +250 per great realm, plus what your open points and Soul Seeds add.
  - **Refills** 1% a second for 1% of your qi.
  - **Pills recharge it:** low 10%, mid 20%, high 35%, supreme 60%, immortal 100%. Immortal pills also **temper** it +10%, up to +50%.
- **Soul arts:** each art's key and its status (Ready, cooldown or Locked).
- **Domain arts:** element, form, Amplification and Qi Ward (see [Domain Expansion](Domain-Expansion)).

### 识海 The Soul Sea

Battles of the soul are fought on a dark platform under a starry heaven, around your **Dantian Core**. **No one dies in a soul sea:** whoever falls is defeated and carried out with a **wounded soul** (Weakness for 10 minutes and a fifth of this realm's progress lost).

| Art | Key | Needs | What it does |
|---|---|---|---|
| **Soul Seize** 摄魂入识 | Shift+H | Soul Formation | Drag the foe you look at into your soul sea for 2 minutes, where you're strong and they're weak. 35% qi, 10-minute cooldown. Higher realms and strong souls may resist |
| **Soul-Piercing** 穿识 | Shift+H | Nascent Soul + the scroll | Soul Seize on a **weaker cultivator** tears into *their* soul sea: break their Dantian Guard, then strike their Core in time to **shatter their dantian** |
| **Qi Burst Escape** 爆气遁 | Ctrl+H | Foundation | Your qi bursts out, flinging foes back and you away with brief Invisibility, Speed, Resistance and Slow Falling. 15% qi; a foe's sealed domain stops it |

- **The Scroll of Soul-Piercing:** recipe eye of ender, amethyst shard, eye of ender / amethyst shard, book, amethyst shard / eye of ender, echo shard, eye of ender. Great evils sometimes drop one.
- **They can do it to you:** great evils, world bosses and some Soul Formation cultivators who know Soul-Piercing and are stronger than you may tear into your soul sea mid-fight. A strong soul makes it less likely.
- **Defending your dantian:** intruders must break your guard in time, or they're cast out. If your Core falls, **your dantian is shattered:** you drop 3 realms, cultivation slows, and breakthroughs get harder. Heal it with one immortal-grade pill, or three supreme-grade pills a step at a time.
- **Soul invasions 夺舍:** on rare nights (at most once per 2 days, from Foundation), a possessing soul tries to take your body. Slay it to absorb its essence. If your guard holds, it is driven out; if it outlasts you while your guard is broken, your soul is wounded.
