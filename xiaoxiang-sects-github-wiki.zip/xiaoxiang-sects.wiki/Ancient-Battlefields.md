Cursed fields where a fallen sect's last war never ended: soul soil strewn with bones, broken pillars, soul lanterns and black banners around a cracked stele.

- **When:** sometimes at dusk a battlefield surfaces 150–260 blocks from a player (at most 3 in the world). Everyone is told where, and it shows on the Sect Survey Jade Slip.
- **By day** they are quiet ruins.
- **At night** spectral cultivators rise and attack anyone on the field: 2, plus 2 per player nearby, up to 8. They're around your realm, and one in five is a stronger Spectral Elder. They fade at dawn.
- **Drops:** slain spectres drop **Broken Artifacts** (60%).
- **Repair:** use a Broken Artifact near a **Refining Core** to play the forging minigame:

  | Score | Result |
  |---|---|
  | 90%+ | a weapon or treasure **one tier higher** |
  | 60%+ | one of its own tier |
  | 30%+ | one a tier lower |
  | below 30% | it shatters |
