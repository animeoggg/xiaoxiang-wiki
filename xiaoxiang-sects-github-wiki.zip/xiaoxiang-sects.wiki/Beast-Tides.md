At dusk, a horde of demon beasts may gather against a sect and attack it in **three waves**.

### Which sects are struck

- **Your sect:** each dusk there's a chance (20% by default) if the master is online in the sect's world and the sect last had a tide at least 2 days ago.
- **Generated sects:** a sect within about 128 blocks of a player can be struck, at half that chance. Defend it and it remembers.
- **Gate breaks:** a secret realm gate left uncleared when it closes **breaks**, and its beasts pour out as a tide.
- **Limits:** at most 3 tides at once, never two within 200 blocks of each other.

### How a tide unfolds

1. **Warning:** a raid horn sounds, and nearby players and your sect are told. Your **alarm bell** rings itself. The tide strikes 30 seconds later.
2. **Wave 1:** common beasts. **Wave 2:** a heavier mix. **Final wave:** rare beasts led by a **Tide Lord** boss.
3. **Where they gather:** waves gather **outside your grounds** and march in. They never spawn inside the array.

### Breaking the array

- **Breaking the array is their first job.** Beasts head for the nearest stretch of the dome and batter it, ignoring defenders behind the barrier unless they come outside.
- **They bombard it** with their strongest ranged arts as they close in (fireballs, Star Fall, flying swords, sword auras, palm thunder and more), and raiders use the main mod's siege-barrier casting.
- **Swarm pressure:** each blow counts as the worse of its own damage or a share of the array's whole qi, so big swarms threaten even immortal arrays. A tide of 25 left unanswered breaks an immortal array in about half a minute.
- **Which foes your flags can hold:** Low flags hold Qi Refining foes, rising to Immortal flags for Mahayana. Each realm above that hits ×1.5 harder (up to ×4).
- **Blood-burst beasts** (red spores above them, about 1 in 4 of the common and uncommon) charge the wall and explode for double damage. Kill them early. Any tide beast at the wall below 30% health blows itself up against the array rather than die for nothing.
- **At 0 qi the array shatters** and the main mod's 5-minute recovery begins.
- **The array strikes back** with heavenly lightning on beasts hammering it: 1–5 bolts by core grade, each costing 0.8% of its qi. It never spends its last 15%.

### Inside the walls

- **Wrecking:** with `mobGriefing` on, beasts smash fragile things (glass, fences, torches, lanterns, crops). They never touch chests or other block entities.
- **Plunder:** beasts that reach the headquarters steal spirit stones from the treasury. Kill a looter and its stones go back.
- **If you win,** your disciples rebuild everything that was smashed.

### Winning and losing

- **Victory** when the final wave is wiped out:
  - **Your sect:** treasury stones, prestige +1 and loyalty for those who fought.
  - **A generated sect:** stones for every player who helped, and its attitude toward your sect rises by 15.
- **Defeat:**
  - **If no player stays within 96 blocks for 2 minutes**, or the tide isn't broken within 12 minutes, the tide wins.
  - **Your sect** loses part of its treasury and storehouse.
- **A battle report** opens for everyone who fought (see [Defending Your Sect](Defending-Your-Sect)).
