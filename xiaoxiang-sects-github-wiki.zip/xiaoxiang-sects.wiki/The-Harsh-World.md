Cultivation is hard, the means to it are scarce, and the strong rule the weak. **On by default.** Every part can be tuned under `[harsh_world]` (see [Server Settings](Server-Settings)) or live with `/harshworld` (operators).

### Cultivating is slow

- **Half speed:** cultivation from absorbing qi and meditating is halved (`cultivation_speed` 0.5). Pills are not affected.
- **Breakthroughs:** every breakthrough chance loses 15 percentage points (never below 1%). Guaranteed breakthroughs are unaffected.
- **The cultivation mod's own difficulty** (Easy, Normal, Hard or Inferno) stacks with all of this.

### Resources and techniques are earned

- **Prices:** cultivation goods cost ×1.5 in every addon shop, pavilion, clan counter and back room. Mortal goods are unchanged.
- **Techniques:** wandering cultivators carry spell books and technique manuals only 35% as often, one at a time. They teach you one of their arts only at **90 regard**.
- **Chests:** in every chest loot table of the world, each stack of cultivation goods is kept only 40% of the time and halved. Spell books and manuals are kept at the technique rarity. Mortal loot is untouched, and so are earned rewards (secret realm spoils, boss drops, quests, bounties, heirlooms). Generated sects' storehouses are thinned the same way.
- **Breakthrough materials** (Foundation and Golden Core) are always scarce, harsh world or not:
  - The Dao Foundation Fruit and Foundation Secret are not found in ordinary chests.
  - Sect storehouses keep at most one of a kind.
  - Wandering cultivators rarely carry them, and sell them at four times the price.

### The strong rule the weak

- **Realm suppression:** in a fight between cultivators (players and cultivator NPCs):
  - the stronger one's blows hit the weaker **+40% per great realm** of difference, up to ×4;
  - the weaker one's blows on the stronger keep **70% per great realm** (70%, 49%, 34%…), never below 15%.
- **Realm pressure:** within 14 blocks of a cultivator two or more great realms above you, their aura gives you Slowness and Weakness (Mining Fatigue at three realms or more). Your own sect's people never press on you.
- **Predators:** a **loose** cultivator two or more great realms above you, met in the wilds, may decide you are prey: 20%, more if they dislike you, less if they like you. Each checks once every 10 minutes. They either:
  - **demand your spirit stones:** sneak within 10 seconds to kneel and pay a third of what you carry, or they attack; or
  - **attack outright.**
- **No predators** inside town walls, clan estates or your own sect's grounds. Townsfolk, clan folk, sect members, avengers and examiners never prey on you.

### The wilds are matched to you

Creatures that spawn by themselves are matched to the **strongest player within 128 blocks**. Settings are under `[wild_scaling]`.

- **Demon beasts:** a wild demon beast is at most **one great realm above** that player. A Mortal or Qi Refining player meets Qi Refining and Foundation beasts.
- **Bosses:** boss-rank beasts roam only near players of **Foundation** or higher.
- **Other monsters** (other mods' and the cultivation mod's own) spawning naturally near a Mortal or Qi Refining player may have at most **60 health**. The limit grows ×2.5 with each great realm. Vanilla monsters are never affected.
- **Full danger stays** in structures, nests, beast tides, warbands, secret realms, at the Demon-Sealing Altar, and **beyond 10,000 blocks** from the world spawn.
