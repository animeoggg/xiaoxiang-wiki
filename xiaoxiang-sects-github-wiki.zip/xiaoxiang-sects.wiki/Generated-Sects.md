The main mod's sects are ranked **Lower, Middle or Higher**, follow a **speciality**, and keep their protection arrays the way a player's sect does.

### Ranks

| Rank | Share | Sect Master | Ancestor | Protection array | Cave | Pavilion grade |
|---|---|---|---|---|---|---|
| Lower | ~50% | Foundation to Golden Core | weakest | Low or Mid | Mid-grade | Mid |
| Middle | ~33% | Nascent Soul to Soul Formation | stronger | High | High-grade | High |
| Higher | ~17% | Void Refining to Mahayana | likely an immortal | Supreme or Immortal | Supreme-grade | Supreme |

- **How rank shows:** elders and disciples are scaled below their master, and members cultivate by their sect's rank.
- **Buildings** are restyled by rank and alignment, from humble cobblestone halls to quartz-and-gold or blackstone-and-crimson palaces.
- **A floating sign** above each array core shows the sect's rank, faction, name and array grade.
- **Spawn chance:** on first start the addon raises the main mod's sect spawn chance to 0.6, unless you've set your own.

### Specialities and the Holy Sects

Every sect follows one speciality: **Sword, Pill, Formation, Beast-Taming, Body-Tempering, Talisman** or **Blood Demon**. Evil sects lean demonic; righteous sects never are. The finest **Higher** sects of each speciality are its **Holy Sects** (about one sect in eleven).

| Holy Sect | Its disciples carry | Its sway brings to markets |
|---|---|---|
| Holy Sword Sect | swords, Strength II, Speed | mid-grade swords |
| Holy Pill Sect | Regeneration II, +20 health | mid pills, Marrow Cleansing, high Qi Recovery |
| Holy Formation Sect | Resistance II, +12 health, twice the array stores and refill speed | qi-gathering flags, inscription knives, compasses |
| Holy Beast Sect | Speed II, Jump II, Strength | beast blood essence |
| Holy Vajra Sect (body) | Resistance II, Strength, +40 health | body-forging pills |
| Holy Talisman Sect | Fire Resistance, Speed, Resistance | talisman paper, cinnabar, mid brushes |
| Holy Demon Sect | Strength II, +20 health, night sight | blood essence, corpse bone |

- **Ordinary sects** carry the same marks at level I.
- **Sway:** every settlement within **1,600 blocks** of a Holy Sect gains +1 might and stocks that sect's goods. Clan estates in that range are its **vassals**.
- **Teaching:** sneak + right-click a Holy Sect's disciple (regard 20) for its **teaching** (600◆, once a day). You get ten minutes of its blessing, a gift of its craft, +250 Path insight on the matching Dao Path, and +3 regard.

### Sect pavilions

Every sect keeps a **pavilion** of its speciality, run by its masters, far above any clan's craft. Sneak + right-click any of its disciples: **Visit the Pavilion** opens the counter, and **[Service] · fee** performs the masters' service.

| | Counter stocks | Regard needed | Treasures only they keep |
|---|---|---|---|
| Clan estate (for comparison) | low–mid | | |
| Lower sect | **Mid** | 0 | Marrow Cleansing Pill, Sword Aura manual, talisman supplies, Blood Spirit Pill |
| Middle sect | **High** | 10 | + Jiedan (Golden Core) Pill, Vajra Body manual |
| Higher sect | **Supreme** | 20 | + Nascent Breakthrough Pill, Sword Heart manual, Bone-Changing Pill, Blood Jiedan Pill |
| Holy Sect | **Immortal** | 30 | + Spirit Root Cleansing Pill, Heaven-Mending Pill, Natal Sword Art, Immortal Body manual |

| Speciality | Pavilion stocks | The masters' service |
|---|---|---|
| Pill | nine pill lines | refine your herbs into a Cultivation Pill and a Qi Recovery Pill of the sect's top grade |
| Sword | named swords and sword manuals | repair all gear, and **+1 Sharpness** on the sword in hand (up to II–V by rank) |
| Formation | every flag kind and formation core plates | a 10-minute **great gathering array** (once a day) |
| Beast | blood essence, Black Tortoise armour | a beast from the pens: Spirit Hound, Moon Wolf, Thunder Wolf or **Heavenly Wolf King** |
| Body | body-forging pills and manuals | **body tempering** (once a day): Health Boost II–V for 30 minutes |
| Talisman | brushes, Maoshan and Tianji robes, paper, cinnabar | a **great ward:** Absorption III–VI and Fire Resistance |
| Blood Demon | blood-burn pills, blood essence, Xuesha robes | **blood refinement:** a third of your health for Strength III–IV |

Fees rise with rank (about 150, 600, 2,000 and 6,000◆). Supreme and immortal goods are paid in supreme spirit stones.

### Their protection arrays

Every sect raises an array whose flags, core plate and spirit vein core are of the **same grade**. Spirit vein cores and core plates store and supply far more qi than the main mod's own numbers:

| Grade | Stores (qi) | Supplies (qi/s) | Damage the full dome holds | Dome mends (damage/s) |
|---|---|---|---|---|
| Low | 400,000 | 1,500 | 400 | 1.5 |
| Mid | 600,000 | 3,000 | 1,200 | 6 |
| High | 1,000,000 | 6,000 | 5,000 | 30 |
| Supreme | 2,000,000 | 12,000 | 40,000 | 240 |
| Immortal | 5,000,000 | 30,000 | 500,000 | 3,000 |

**Their people keep the array:**

- **Stores:** each sect keeps three full charges of qi, refilled by its miners. The array is kept at 90%: 5% a second in peace, 1–3% under siege.
- **Wardens:** two of its people channel qi into the core. Without a warden it refills at half speed.
- **Raised again:** a shattered array rises again by itself once it has recovered and holds a quarter charge.
- **On the wall:** members inside the dome loose **Sword Qi** through it at attackers, and the array strikes back with heavenly lightning.
- **Night watch:** two members walk the rim after dark and cut down monsters.
- **The dome lattice:** shows in the colour of the flags (green Low/Mid, blue High, gold Supreme/Immortal), and only while the array is up.

### Dealing with a sect's disciples

Sneak + right-click a generated sect's disciple with an empty hand:

| Option | What it does |
|---|---|
| How fares your sect's array? | Its charge, stores, wardens and whether it's under attack |
| Give spirit stones to your array | Everything you carry goes to their stores: regard (up to +15), and your sect rises in their esteem |
| Help the wardens: channel my qi | 25% of your qi into their array, once a day: +4 regard |
| The pavilion and its service | See [Sect pavilions](Generated-Sects#sect-pavilions) |
| Holy teaching | Holy Sects only |

### Stealing scriptures

- **Their libraries:** generated sects keep foundation-level (Low) manuals in their chests. Higher ones come from secret realms, caves and their libraries.
- **Stealing:** sneak into a sect's pavilion or pagoda and open a chest to attempt a theft. A skill-check minigame opens: press SPACE while the needle is in the white zone (the golden sliver is a great check).
- **All checks passed:** a manual of the sect's rank.
- **A miss:** the alarm sounds, its members attack, and your notoriety rises.
- **Limit:** once every 3 days per sect.

### The Sect Survey Jade Slip

- **What it lists:** right-click it to list the nearest sects (rank, speciality, alignment, distance; your vassals show your emblem). Tabs for **Mines** (caves you've found), **Gates** (open secret realms and ancient battlefields) and **Veins** (grottos and who holds them).
- **Teleporting:** click a row to teleport beside it (a short cooldown between uses).
- **Recipe:** compass, demon bone, paper (shapeless).
