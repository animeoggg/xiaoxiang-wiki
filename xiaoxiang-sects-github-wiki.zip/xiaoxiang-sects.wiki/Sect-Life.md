### Natures, traits and dramas

- **Traits:** every disciple has one: Diligent, Lazy, Ambitious, Loyal, Greedy or Reckless. Loyal disciples never fall below 50 loyalty; greedy ones may desert with stolen stones.
- **Dramas:** on about one morning in four something happens: a rivalry, a betrayal, an inner demon, a talented youth at the gate, or a dying elder who leaves a manual.
- **Talking with them:** sneak + right-click a disciple for a heart-to-heart (+2 loyalty a day), to hear their wishes, or to ask about their past (their own missions).

### Bonds between disciples

| Bond | Affinity | In battle (within 12 blocks) |
|---|---|---|
| Friends | 50+ | Speed |
| Sworn siblings | 80+ | Strength and Speed |
| Dao companions | 90+, rare | Strength II and Resistance |
| Rivals | −50 or lower | spur each other on, and sometimes duel |

When a bonded disciple falls, the other grieves and vows vengeance. **Sect Affairs → Disciple Bonds** lists every notable bond.

### The Elder Council

- **Who:** your three highest elders vote on **war and alliances**, each by loyalty and nature.
- **Overruling:** give the same order again within a minute. Those who voted against lose 10 loyalty.
- **Plots:** an elder below 25 loyalty **plots**. You have 2 days to **appease** them (10% of the treasury, +30 loyalty) or **confront** them (they draw their blade). Ignored, they defect with a tenth of the treasury and up to 2 followers.
- **A council feast** (5% of the treasury) gives every councillor +6 loyalty.

### Rankings, ceremony and challenges

- **Rankings:** every sect in the world is ranked (prestige, titles, war kills, members, realms cleared).
- **The Grand Ceremony:** every 30 days, the top three player sects get prestige, stones and the title of the year.
- **Champion duels:** challenge a generated sect you're not at war with to send its Champion. Win within 5 minutes for stones, prestige +2 and +5 attitude. Once every 7 days per sect.
- **The weekly challenge:** each week your sect is set a hunt: 60 hostile creatures, plus 15 per disciple, slain by master, fellows, disciples and their beasts together. Reach it for treasury stones, prestige and loyalty.

### Sparring, succession and finances

- **Sparring:** spar with a disciple, in your arena if you have one. Nobody dies. Win, and their loyalty rises and every few wins they break through (never past one realm below you). Lose, and they teach you a technique as a manual. One bout per disciple per day.
- **Succession:** if you fall in a siege or to a tribulation, your Grand Elder becomes **regent**. A loyal one (40+) keeps all safe; a disloyal one stages a coup, taking a quarter of the treasury and the disloyal disciples.
- **Finances:** the **Finances** tab shows what's expected each dawn and every line booked today and yesterday.

### Sect Affairs

**Sect Hall → Sect Affairs** gathers the Elder Council, the Quest Journal, Escort Contracts, World Bosses, Battle Reports, Disciple Bonds and the Sect Map.
