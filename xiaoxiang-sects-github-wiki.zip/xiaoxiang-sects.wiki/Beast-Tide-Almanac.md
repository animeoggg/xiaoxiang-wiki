The *[Beast Tide Almanac](Beast-Tide-Almanac)* sets how often and how strong the demon beasts come.

- **Who can change it:** anyone can read it; only the world's owner (single player) or an operator can change it. Settings are saved with the world.
- **Getting one:** it can't be crafted. Use the creative menu or `/give @s xiaoxiang_sects:beast_almanac`.

| Setting | Default | Range | Effect |
|---|---|---|---|
| A wave every | 6 s | 2–60 s | Time between spawn waves around each player |
| Spawn tries per wave | 2 | 1–8 | Spots tried; each can bring a pack |
| Up to N beasts near you | 14 | 2–40 | No new beasts while this many are within 64 blocks |
| Daytime / night activity | 80% / 140% | 0–300% | Scales the tries |
| Closest / farthest spawn | 24 / 56 blocks | | How near and far a wave reaches |
| Leave beyond | 128 blocks | 64–256 | Wild beasts with no player this close fade away |
| Common / Uncommon / Rare / Boss | 100% each | 0–500% | Weight of each rank |
| Danger | 0 | 0–4 | Each step gives every new beast a further 50% chance of one realm higher |
| Rare / bosses apart | 40 / 128 blocks | | Minimum spacing |
| Wild caves | 40% of regions | 0–100% | New land only |
| Beast tide chance / size | 20% a dusk / 100% | | Tides on your sect (generated sects get half the chance) |

- **Switches:** wild spawning, cave spawns, sea beasts and tides.
- **Presets:** Calm, Normal, Dangerous and Nightmare. Press Apply to use one.
- **Operator buttons:** call a tide on your sect or the nearest sect, stop tides, open a secret realm.
- **The live panel** reads where you stand: your biome, the beasts near you by rank, the time to the next wave, and every species that can appear here with its odds.
