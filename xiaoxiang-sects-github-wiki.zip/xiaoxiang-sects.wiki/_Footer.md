Xiaoxiang Sects Expanded 1.0.148 · Built as an addon for Xiaoxiang Cultivation World. Thanks also to Threateningly Mobs. I don't own those mods; anything will be removed on request.
