# Xiaoxiang Sects Expanded

*Addon 1.0.148 · Minecraft 1.20.1 · Forge 47.x · needs Xiaoxiang Cultivation World 0.2.106+ and Threateningly Mobs 1.1+*

> **Disclaimer: I do not own anything.** This is an unofficial, fan-made addon. All credit goes to the main mod, **Xiaoxiang Cultivation World**, and its author, and to **Threateningly Mobs** and its author. If any author asks me to take this addon (or any part of it) down, I will remove it.

**Xiaoxiang Sects Expanded** (shown in game as *Xiaoxiang Sects & Beasts*) is an unofficial addon for **Xiaoxiang Cultivation World**. It turns the main mod's world into a living cultivation world:

- **Harder cultivation:** cultivation is slow, breakthroughs are risky, resources and techniques are scarce, and stronger cultivators are a real threat to weaker ones.
- **The wilds:** demon beasts of the *Classic of Mountains and Seas* that cultivate, cast spells and fly. There are spirit stone caves and herb grottos, beast nests, world bosses and ten great evils sealed under altars.
- **Mortal kingdoms:** walled villages, towns and capitals with kings, clans, shops, inns, arenas and gambling houses. Towns are split into slums, an outer ring and an inner ring, and each has its own underworld.
- **Clans and sects:** clan estates out in the wilds, each with its own craft. Generated sects are ranked and specialised, and the finest of them are **Holy Sects** with pavilions far above any clan's.
- **Your own sect:** recruit disciples, raise buildings, run production, keep protection arrays, and defend against beast tides, war parties, sieges and demonic invasions. You can also take on missions, form alliances, fight wars, take vassals and hold tournaments.
- **Your inner world:** the Dantian World (meridians, storage, Dao seeds and the Dantian Guard), battles in the Soul Sea, and *[Domain Expansion](Domain-Expansion)*.
- **Missions:** a Mission Journal with thirty kinds of missions, story chains, requests from the people you meet, reputation, achievements and titles.

The demon beasts come from **Threateningly Mobs**. Each creature keeps its own body and attacks, and gains a cultivation realm, a nature, spells and techniques.

### Requirements

| Requirement | Version | Notes |
|---|---|---|
| Minecraft | 1.20.1 | |
| Forge | 47.x | |
| Xiaoxiang Cultivation World | **0.2.106** or newer | The main mod, unmodified |
| Threateningly Mobs | 1.1 or newer | Required: it supplies the demon beasts |

### Installation

1. Install Forge 1.20.1.
2. Put the Xiaoxiang Cultivation World jar, the Threateningly Mobs jar and the addon jar in your `mods` folder. Keep **only one** addon jar: remove the old one when you update.
3. Install the **same addon version on the client and the server**. The network version must match (it is currently **24**).
4. A **new world** is strongly recommended. Caves, settlements, clan estates, sect arrays, grottos and secret realm layouts only appear in newly generated land.

### What the addon changes in the base game

- **Spawning:** only creatures that cultivate spawn by themselves. Vanilla monsters and animals no longer spawn naturally, but spawners, eggs, breeding and commands still work.
- **Wild spawns follow your strength:** creatures that spawn by themselves are matched to the strongest player nearby (see [The Harsh World](The-Harsh-World)).
- **Villages:** vanilla villages and villagers are replaced by the mortal kingdoms' walled settlements.
- **Spirit stones:** spirit stone ore and spirit vein springs no longer generate in the open world. Ore is found only in the caves.
- **Threateningly Mobs structures** (palaces, nests, altars, dungeons) never generate. Its creatures remain.
- **Arrays:** spirit vein cores and formation core plates store and supply far more qi, so protection arrays can stay up.
- **Crafting by hand:** the alchemy core, refining core and formation plate only work through hands-on minigames, and talismans are sealed with a brush minigame.
- **Scarcity:** breakthrough materials (Foundation and Golden Core) are rare in chests, rare with wandering cultivators and sold at four times the price.
- **A harsh world (on by default):** half-speed cultivation, harder breakthroughs, dearer goods, thinner chests and realm suppression. All of it can be configured.

### Compatibility

The addon hooks the main mod with small, optional mixins and never changes the main mod's jar. If a future main mod update changes the code a hook relies on, that hook switches itself off quietly instead of crashing.

## Contents

**Start here**

- [Getting Started](Getting-Started)
- [Keys and Commands](Keys-and-Commands)
- [Server Settings](Server-Settings)
- [FAQ and Known Limitations](FAQ-and-Known-Limitations)
- [Version History](Version-History)
- [Credits and Disclaimer](Credits-and-Disclaimer)

**Cultivation**

- [The Harsh World](The-Harsh-World)
- [Dao Paths](Dao-Paths)
- [Mastery](Mastery)
- [Breakthroughs and Foundation](Breakthroughs-and-Foundation)
- [Dantian World and Soul Sea](Dantian-World-and-Soul-Sea)
- [Domain Expansion](Domain-Expansion)

**The mortal world**

- [The Mortal Kingdoms](The-Mortal-Kingdoms)
- [Town Wards and the Underworld](Town-Wards-and-the-Underworld)
- [Life in the Cities](Life-in-the-Cities)
- [Clan Estates](Clan-Estates)

**The wilds**

- [Demon Beasts](Demon-Beasts)
- [Great Evils and World Bosses](Great-Evils-and-World-Bosses)
- [Spirit Stone Caves and Herb Grottos](Spirit-Stone-Caves-and-Herb-Grottos)
- [Beast Tide Almanac](Beast-Tide-Almanac)
- [Beast Tides](Beast-Tides)
- [Companion Beasts](Companion-Beasts)
- [Secret Realms](Secret-Realms)
- [Spirit Veins](Spirit-Veins)
- [Ancient Battlefields](Ancient-Battlefields)
- [Encounters on the Road](Encounters-on-the-Road)

**Sects of the world**

- [Generated Sects](Generated-Sects)
- [Holy Sect Fairs](Holy-Sect-Fairs)

**Your sect**

- [Founding Your Sect](Founding-Your-Sect)
- [Buildings and Production](Buildings-and-Production)
- [Arrays and the Reservoir](Arrays-and-the-Reservoir)
- [Defending Your Sect](Defending-Your-Sect)
- [Sect Life](Sect-Life)
- [The Scripture Pagoda](The-Scripture-Pagoda)
- [Relations and War](Relations-and-War)
- [Tournaments and the Arena](Tournaments-and-the-Arena)
- [Sect Wards and the Sect Domain](Sect-Wards-and-the-Sect-Domain)

**Missions**

- [Missions and the Journal](Missions-and-the-Journal)
- [Sect Bounty Board](Sect-Bounty-Board)

**Crafting and items**

- [Minigames](Minigames)
- [Items and Recipes](Items-and-Recipes)
