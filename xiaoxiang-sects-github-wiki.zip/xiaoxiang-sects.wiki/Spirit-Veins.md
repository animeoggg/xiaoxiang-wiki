Rich wellsprings of qi surface now and then in the wild (at most 6 at once). Each is a **grotto**: a shrine gate on the surface opens onto a long stair down into a great amethyst cavern around a **spirit pool**.

### Claiming and income

- **Claiming:** keep a **one-minute vigil** beside the vein's core to claim it for your sect (two minutes to seize one another sect holds).
- **Income:** a held vein pays the treasury every dawn.
- **Defending it:** generated sects covet veins. At dawn one may send a **war party** to the grotto's entrance. Be there and break it, or the vein is lost.

| Grade | Income per dawn | Pool | Bottles per day |
|---|---|---|---|
| Low | 80 | Clear Spirit Pool | 12 |
| Mid | 200 | Jade Spirit Pool | 8 |
| High | 500 | Violet Essence Pool | 6 |
| Supreme | 1,200 | Golden Marrow Pool | 4 |

### The spirit pool

- **Infusion:** stand in the pool or on its rim to gain **Spirit Spring Infusion**. While it lasts, meditating gives extra cultivation, more for finer pools.
- **Bottling:** use a glass bottle at the pool to fill **Spirit Spring Water**. Drinking it gives 3 minutes of infusion anywhere.
- **Who may use it:** only the owning sect may use a claimed pool. A sect master can grant others a timed **vein pass** from the ledger.

### Protection

Grottos are warded against building and breaking. The server setting `[spirit_vein_grottos] protection` decides how much:

- **SURFACE** (default): only the grotto, its stair and the shrine gate.
- **FULL:** the land above as well.
- **OWNERS:** as SURFACE, and the owning sect's leaders may build inside.
- **OFF:** no block protection.

No domain can unfold inside a grotto.
