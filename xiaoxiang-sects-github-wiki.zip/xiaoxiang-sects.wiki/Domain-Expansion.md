**领域展开.** A cultivator unfolds their inner world over the outer one for a short while. Every foe inside is struck each second by an attack that cannot miss, and you are strengthened (Strength II, Resistance, Regeneration and Speed). Press **V**; the right form is chosen for you.

### Forms

| Form | Who | What it is |
|---|---|---|
| **Incomplete** 领域·未成 | Golden Core | No barrier, radius 7, 12 s, sure-hit at half strength, 25% qi |
| **Sealed** | Nascent Soul | A barrier no foe can leave or enter: radius 10 at Nascent Soul, up to 20; 20 s, up to 60 s |
| **Open** | Mahayana | No walls at all, but vast: radius 28–40, 40 s, 40% qi. Toggle sealed / open on the domain page |
| **Sect domain** 宗门领域 | A sect leader (Golden Core+) on their own grounds while the sect is under attack | Spreads over the whole protection array (up to radius 64) for 45 s. The array pays: 25% of its qi to raise it, 1% a second to hold it. Strikes only what threatens the sect |

Foes of a **higher realm** take half the damage for each realm above you. Your sect, disciples, allies and tamed beasts are never struck, and they pass freely through your barrier.

### Eight domains, one per element of your spirit root

Choose among your root's elements on the domain page or with `/sectdomain element <element>`.

| Element | Domain | Each second | Signature art (B) |
|---|---|---|---|
| Metal | Ten Thousand Swords 万剑归宗 | armour-piercing sword rain, +15% | Sword Storm: sword rain and a sky-splitting aura |
| Wood | Endless Verdant Forest 万木森罗 | rooted and poisoned | Ten Thousand Thorns: Verdant Bind |
| Water | Boundless Abyssal Sea 沧海无涯 | slowed, breath runs out | Great Flood: Water Prison |
| Fire | Burning Sky Inferno 焚天炎狱 | set ablaze | Falling Sun: meteors on every foe |
| Earth | Mountain-Suppressing Prison 镇岳山牢 | pressed down, can't jump | The Mountain Falls: Heaven-Piercing cone and stone hail |
| Ice | Eternal Frost 万古玄冰 | frozen solid | Absolute Zero: 8 ice swords and a Heaven-Piercing cone |
| Lightning | Nine Heavens Thunder Prison 九霄雷狱 | a thunderbolt every 3 s (×1.6) | Heavenly Tribulation: triple palm thunder |
| Pure | Void of Stillness 寂灭虚空 | weakened, qi drains away | Annihilation: meteors and a mega sword aura |

On the **Sword Path**, the domain becomes the **Heaven-Splitting Sword Domain** 斩天剑域: its art is three mega sky-splitting sword auras on every foe, then a rain of 10 flying swords. The signature arts cast the main mod's own spells, scaled up, once each time you unfold.

### Defence and counterplay

- **Qi Ward** 护体结界 (Shift+V, Foundation): a domain's sure-hit can't touch you while it holds. It drains 1.5% of your qi a second.
- **Domain Amplification** 领域增幅 (B with no domain, Golden Core): your blows strip blessings, shatter Qi Wards and drain a cultivator's qi. Arts and sure-hits strike you at half force. It drains 1.2% qi a second.
- **Clashes:** when two domains overlap, a **6-second contest of will** begins. Mash **V** to push. The higher realm leans on the weaker by itself. The loser's domain shatters and they're burnt out for 45 s.
- **Breaking a barrier from outside:** a sealed barrier has integrity (60 + 30 per realm). Strike it, or hit it with arrows or spells. At zero it shatters and its master is burnt out for a minute.

### When it falls

A domain ends when its time runs out, or early if you step outside it, lose 45% of your health, fall, or lose a clash. You're then **burnt out** for 30 s (Weakness and Slowness), and your inner world needs 3 minutes to settle. Every block the barrier covered is put back exactly as it was, even after a crash.

### Domain mastery

- **Gaining it:** mastery (0–10, Unformed to **Absolute**) grows with every domain unfolded and every foe slain inside one.
- **Each rank:** −4% cost, +2 s duration, +3% strength and −10 s cooldown.

### Others who unfold domains

- **Your elders:** Elders and Grand Elders of Nascent Soul or above unfold sealed domains when the sect is hard pressed (under the Fight order, at most once every 10 minutes).
- **Great evils** unfold one below half health.
- **Tide Lords, Siege Marshals and world bosses** unfold one in phase III.
