A suggested path for a new world. You don't have to follow it in this order.

### Your first days (Mortal to Qi Refining)

- **Find a settlement.** Mortal towns sell food, pills, herbs, arms and talisman supplies, and their inns, guilds and arenas have work. Use `/sectcity nearest` to find one.
- **Wild beasts are matched to you.** While you're weak, the beasts that spawn near you stay within one realm of you, and boss-rank beasts don't roam near you until you reach Foundation. Beyond 10,000 blocks from spawn the wilds are not matched to you at all.
- **Talk to people:** sneak and right-click with an empty hand. Wandering cultivators give news, advice and requests. Townsfolk, clan disciples, sect disciples and even wild beasts can be talked to.
- **The Mission Journal (O)** lists daily missions and the Mission Board. The Missions window on the left of the screen tracks what you're doing.
- **The Dao Awakening:** when you first draw qi into your body, the heavens choose your **Dao Path** (Sword, Pill, Body or Demonic). Your path grows with deeds that suit it.
- **Spirit stones** come from caves, slain beasts, bounties, missions and trade. The first wild caves are Low-grade.

### Building strength (Foundation to Golden Core)

- **Breakthroughs** need scarce materials. The **Paths to Ascension** (cultivation menu, G) list every road to them: your sect's Scripture Pavilion, the sect trial, a master's teaching, an ally's exchange, comprehension under a storm, a royal grant, clan adoption and more.
- **Found a sect** with a Sect Master's Command Token, recruit wandering cultivators and raise buildings.
- **Tame a companion beast** with a Beast Subduing Talisman.
- **Join a Holy Sect** by winning its recruitment fair in a capital under its sway.
- **Explore** spirit stone caves of higher grades, secret realm gates, spirit vein grottos and clan estates.

### Becoming a power (Nascent Soul and beyond)

- *[Domain Expansion](Domain-Expansion)* (V) unfolds from Golden Core (incomplete), sealed from Nascent Soul and open from Mahayana.
- **The great breakthroughs** beyond Golden Core cost Ascension Seals, Beast Soul Orbs and spirit stones.
- **Take on the great powers:** world bosses, the great evils at the Demon-Sealing Altar, S-Rank gates, wars, sieges and vassals.
- **Beyond Earth Immortal**, the addon opens its own road through the immortal realms, and an immortal master can fold the sect into a **Sect Domain** of its own.
