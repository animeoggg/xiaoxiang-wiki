Every technique and spell you know has its own **mastery**. Open the Mastery screen with **K**.

| Level | Experience | Spell damage | Spell qi cost | Technique bonuses |
|---|---|---|---|---|
| Novice | 0 | ×1.00 | ×1.00 | ×1.00 |
| Adept | 500 | ×1.05 | ×0.96 | ×1.05 |
| Expert | 2,000 | ×1.10 | ×0.92 | ×1.10 |
| Master | 6,000 | ×1.16 | ×0.88 | ×1.16 |
| Grandmaster | 15,000 | ×1.25 | ×0.80 | ×1.25 |

- **Gaining mastery:**
  - slowly with use: each spell cast, and each stretch of combat with a technique circulating;
  - far faster by slaying cultivating creatures: more for stronger ones, little for those far below you.
- **Bottlenecks:** each level is capped until you break through it. Press **Break Through** on the Mastery screen to play a breakthrough minigame. You need 65%, or 80% for Grandmaster. A failure leaves your mind unsettled for a while.
- **Disciples** have mastery too: +4% damage per level from Adept.
