### Keys

All keys can be rebound under *Controls → Xiaoxiang Sects*.

| Key | What it does |
|---|---|
| **G** | The cultivation mod's menu, with the addon's **Dao Path**, **Dantian World** and **Paths to Ascension** buttons |
| **H** | Open the **Dantian World** |
| **Shift+H** | **Soul Seize** (Soul Formation and above; Soul-Piercing if you know the scroll's art) |
| **Ctrl+H** | **Qi Burst Escape** (Foundation and above) |
| **V** | *[Domain Expansion](Domain-Expansion)* (in a clash: push) |
| **Shift+V** | Raise or lower a **Qi Ward** |
| **B** | Your domain's **signature art**, or **Domain Amplification** when no domain stands |
| **O** | **Mission Journal** |
| **U** | Missions window: full / compact / hidden |
| **Shift+U** | Show or hide beast nests in the Missions window |
| **N** | **Live sect map** |
| **J** | *[Companion Beasts](Companion-Beasts)* screen |
| **R** | Your nearest companion beast casts a spell at what you look at |
| **K** | *[Mastery](Mastery)* of your techniques and spells |

In conversations, keys **1–9** pick a choice, **Enter** takes the first, **Space** finishes the text and **Esc** closes.

### Commands for everyone

| Command | What it does |
|---|---|
| `/sectcity` | About the settlement you stand in |
| `/sectcity nearest [any\|village\|town\|city\|castle]` | The nearest settlements, with their kingdoms and rulers |
| `/sectcity find <place>` | Inns, the arena, the castle, the House of Fortune and other places in the town you're in |
| `/sectcity list` | Settlements you have visited |
| `/sectfellow ...` | Invite, accept, leave and other actions for player members of a sect |
| `/sectstore` | Open the Sect Storehouse near your headquarters |
| `/sectreport [0-7]` | Reopen one of your sect's last eight battle reports |
| `/sectmissions nests [show\|hide]` | Show or hide beast nests in the Missions window |
| `/sectdomain expand \| ward \| art \| amplify \| form \| element [e] \| info` | Domain Expansion |
| `/dantian`, `/dantian burst`, `/dantian seize` | Dantian World, Qi Burst Escape, Soul Seize |
| `/daopath` | Your Dao Path |
| `/sectwards [on\|off\|fee <n>\|rings <outer> <inner> <core>]` | Wards around your sect's headquarters (sect master) |
| `/sectbranch`, `/sectbranch found` | Branch clan estates |
| `/sectreservoir` | Show the reservoir settings |
| `/harshworld` | Show the harsh-world settings |
| `/sectbet` | Bet on a bout in the arena you're watching |
| `/sectauction`, `/sectduel` | Bid at a travelling auction on the road, or join a side in a duel between two sects' disciples |
| `/secttoll pay`, `/secttoll leave` | Pay a sect gate's toll, or turn back |
| `/sectkingdom`, `/sectvillage` | Your standing with the kingdom, and the settlement you're in |

### Commands for operators

| Command | What it does |
|---|---|
| `/sectcity tp <x> <z>` | Go to the south gate of a settlement |
| `/sectrealm <player> <realm> [early\|middle\|late\|peak]` | Set a player's cultivation realm |
| `/sectgrotto protection <FULL\|SURFACE\|OWNERS\|OFF>` | Spirit vein grotto protection |
| `/sectreservoir conversion\|rate\|siege\|worth\|veins\|regen ...` | Reservoir settings (saved to the config) |
| `/harshworld on\|off\|speed\|breakthrough\|predators\|prices\|chests ...` | Harsh-world settings (saved to the config) |
| `/sectinvasion now` | Send a demonic invasion against your sect now |
