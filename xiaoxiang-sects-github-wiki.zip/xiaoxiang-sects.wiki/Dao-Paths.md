The first time you draw qi into your body, a golden wheel of the four Daos spins on your screen and the heavens choose your **Path**. Open it with the **☯ Dao Path** button on the cultivation menu (G) or `/daopath`.

| Path | Odds | Grows by | Perks per rank |
|---|---|---|---|
| ⚔ **Sword** | 30% | dealing damage with a sword | +5% sword damage per rank; from Master, sword qi may strike again (10%, ×1.5) |
| ⚗ **Pill** | 25% | taking pills, and your sect refining them | pills also heal you (and shield you from Adept); your sect's alchemists make double pills more often |
| 🜂 **Body** | 30% | fighting bare-handed and taking blows | +2 max health and −3% damage taken per rank; bare-handed blows +6% per rank |
| ☠ **Demonic** | 15% | slaying cultivators | 3% lifesteal per rank, harder blows at night. Righteous sects are hostile on sight, and heart demons always come |

### Ranks

| Rank | Experience | Sword | Pill | Body | Demonic |
|---|---|---|---|---|---|
| 1 | 0 | Sword Novice | Pill Novice | Body Tempering | Demonic Novice |
| 2 | 300 | Sword Adept | Pill Adept | Iron Body | Blood Fiend |
| 3 | 1,200 | Sword Master | Pill Master | Bronze Skin | Demon Lord |
| 4 | 3,500 | Sword Saint | Pill Saint | Vajra Body | Demon Saint |
| 5 | 9,000 | Sword Sovereign | Pill Sovereign | Immortal Body | Demon Sovereign |

- **Your title** is shown before your name, and wandering cultivators greet a famous name.
- **Path insight** also comes from clan services, Holy Sect teachings and sect pavilions that match your path.
- **Paths also matter** for the craft minigames (a fitting path makes them a little easier).
