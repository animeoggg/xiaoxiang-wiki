| Versions | Highlights |
|---|---|
| 1.0.10 – 1.0.30 | Caves, demon beasts, beast tides, the almanac, generated sects, player sects, buildings, relations, tournaments, companions, the bounty board, secret realms, spirit veins, sect life, the Scripture Pagoda, sieges and vassals, minigames, ancient battlefields |
| 1.0.31 – 1.0.97 | The mortal kingdoms and their cities, coins and games; Dao Paths; mastery; foundation quality and the Paths to Ascension; the great breakthroughs and the immortal road; heart demons; working sect buildings and production; disciple crafts, merit and orders; fellow players and tokens; the Sect Gate; demonic invasions; garrisons; the Wanted Board; honours; the Sect Domain |
| 1.0.98 – 1.0.102 | Beast tides lay real sieges; smarter defenders; beasts built like true demon beasts (zhenyuan, qi shield); great arts and flight |
| 1.0.103 – 1.0.120 | The Missions window and Mission Journal; thirty missions; honours; cinematic conversations; the Spirit-Stone Reservoir; bosses in phases; the alarm bell; battle reports; the sect map; the Elder Council; disciple bonds; beast nests and eggs; the Beast Chamber; flying mounts; world bosses; the beasts of the Mountains and Seas and the ten great evils |
| 1.0.121 – 1.0.123 | Domain Expansion: four forms, signature arts, clashes, barriers, mastery |
| 1.0.124 – 1.0.127 | The Inner Heaven world (since retired) |
| 1.0.128 – 1.0.130 | The Dantian World and the Soul Sea; crafted Dao seeds; the dark jade and gold interface |
| 1.0.131 – 1.0.136 | Generated sects keep their arrays like you do; strong and weak lands; specialities and the Holy Sects; clans of craft and their estates; sect pavilions |
| 1.0.137 – 1.0.140 | Town wards and the underworld; ringed clan estates; clan rivalries, trials, heirlooms, succession and marriage; Holy Sect fairs; vassal clans and sieges; sect wards; branch estates |
| 1.0.141 | The reservoir made configurable and renewable |
| 1.0.142 – 1.0.143 | The harsh world, and harsh loot chests |
| 1.0.144 | Lag fixes; the jade slip on its own thread |
| 1.0.145 | Room along ward walls; real clan protection arrays |
| 1.0.146 | Wild spawns matched to the nearest player |
| 1.0.147 | Running an array is free; stones only repair damage; better stones last longer |
| 1.0.148 | Fixed: sealed and open domains can be unfolded again from Nascent Soul and Mahayana |
