Beat a demon beast down and bind it with a **Beast Subduing Talisman**, and it becomes your companion. It fights for you, can be ridden (and flown), grows, evolves and lends you its spells.

### Taming: the battle of wills

- **Recipe:** talisman paper, demon core (tier 1), demon bone and lead → 2 talismans.
- **Weaken it:** beat the beast below **30% health** (50% if its realm is below yours), then use the talisman on it.
- **The battle of wills:** a tug-of-war bar. Tap SPACE to push your will; the beast pulls back and surges every few seconds. Reach your end within 14 seconds and it submits. It's harder the stronger and rarer the beast.
- **What can't be tamed:** a beast more than 2 realms above you, cave guardians, and beasts in a running tide.
- **How many:** 1 at Mortal, one more every two realms, up to 6.

### Living with your beast

| Action | Effect |
|---|---|
| Right-click (empty hand) | Ride it, if it's big enough. Nascent Soul beasts **fly**: jump to take off, it flies where you look, hold jump to climb, sprint for speed |
| Sneak + right-click (empty hand) | Talk with it: spend time together, ask what it wants, open its bond and orders |
| Right-click with meat / a demon core | Heals 20% / 50% |
| **R** | Your nearest companion casts one of its spells at what you look at |
| **J** | The Companion Beasts screen: locate, store and summon, stay and follow, unbind |

### Bond

A bond deepens as you feed it, fight beside it and keep it near.

| Bond | At | Gift |
|---|---|---|
| Wary | 0 | none yet |
| Familiar | 10 | +10% attack |
| Trusted | 25 | +10% health |
| Bonded | 45 | takes a fifth of the wounds meant for you (within 16 blocks) |
| Soul-linked | 70 | regenerates while near you |
| Heart-bound | 100 | once a day it refuses to fall, rising at a third of its strength |

**Orders beyond follow and stay:**

- **Guard this area:** it stays within 12 blocks and attacks every foe.
- **Hunt around me:** it attacks hostile creatures within 16 blocks of you.
- **Strike what I point at.**
- **Go with a disciple:** it's lent to your nearest disciple as their beast.

### The Beast Chamber

Each companion has its own window: sneak + right-click it, or use its row on the Companion screen. It has nine places:

- **Armour** and **two charms**.
- **Three technique manuals:** it studies them while they sit there, if they're not too profound for its realm.
- **Food:** eaten by itself when it's hurt.
- **A pill:** cultivation pills feed its qi toward breakthrough; healing pills mend it.
- **A demon core:** for evolution.

When its qi is full, press **Break through**. The chance is 55% plus its bond and evolution, at most 95%.

### Evolution, bloodlines and gear

- **Evolution:** feed it a demon core of high enough tier once its realm allows. It becomes **Awakened**, **Ascended** and finally **Sovereign**: more health, harder blows, deeper spells.
- **Bloodlines:** two beasts of one kind paired with demon cores give an offspring of a stronger line.
- **Gear:**
  - **Iron, Golden and Jade Beast Armour:** more armour, better with each metal.
  - **Flame Charm:** its blows set foes ablaze.
  - **Wind Charm:** it moves faster.
  - **Jade Vitality Charm:** it regenerates.

### Nests and eggs

- **Finding a nest:** now and then a **Demon Beast Nest** appears 48–96 blocks from you in the wild, guarded by a Rare (sometimes Boss) beast near your realm. You get the direction, and the Missions window tracks it (Shift+U hides nests).
- **Taking an egg:** slay or lure away the guardian, then take a **Demon Beast Egg**. Nests are abandoned after 3 days.
- **Hatching:** keep the egg **warm**: about 30 minutes in your pack, faster in your off hand, about 100 seconds near fire, lava or magma. Then use it. The hatchling takes you for its **parent**: your companion at once, starting at Trusted bond.

### Parley with wild beasts

Sneak + right-click a wild beast with an empty hand:

- **Bow:** a 3-minute truce.
- **Offer food:** a 20-minute truce, maybe a nest.
- **Golden Core and above:** ask what troubles it (a task, rewarded with a demon core and lasting peace), or **challenge it to an honourable duel**.
- A truce holds until you strike it. Beasts in a tide hear nothing.

### The sect's guardian beast

Appoint one of your companions as the **guardian of your headquarters**.

- **What it does:** it keeps to the grounds, fights every foe that comes and grows with your sect's prestige.
- **Upkeep:** it's fed from the treasury each payday. **Beast Keeper** disciples halve the cost and train it.
- **If it falls,** it can be called back by a rite.
