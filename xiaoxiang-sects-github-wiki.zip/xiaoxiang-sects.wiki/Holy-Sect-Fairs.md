- **When and where:** every **12th day**, each Holy Sect sends an **Examiner** (Nascent Soul) to the plaza of every **capital under its sway**. Players in the capital are told when the fair opens, and the sect's disciples tell you how many days remain.
- **The entrance bout** (300◆, once a day): a disciple of your own realm meets you. No one dies: the blow that would kill either of you decides it. Win within 2½ minutes to become an **outer disciple** of that Holy Sect.
- **One Holy Sect only:** you can belong to only one.

**Outer disciples get:**

- the sect's pavilion at **25% off**, with no regard required;
- its masters' services at 25% off;
- its daily teaching **free**;
- a gift of its craft on joining.
