### Consolidation

After every stage you rise, a **breakthrough consolidation** minigame opens: steer the surging qi orb and keep it inside the shrinking circle.

- **80% or more:** +3% cultivation, plus Strength and Regeneration for 5 minutes.
- **50% or more:** +1%.
- **Below 50%:** qi deviation (weakened and slowed).

### Foundation quality

How cleanly you consolidated each breakthrough, together with the grade of your Foundation and Golden Core Daos, gives your **foundation quality** (0–100).

| Grade | Quality |
|---|---|
| Cracked | below 25 |
| Common | 25–44 |
| Solid | 45–59 |
| Superior | 60–74 |
| Flawless | 75–89 |
| Heavenly | 90+ |

A sound foundation:

- adds up to **+10 points** to every breakthrough chance;
- softens tribulation lightning (up to −40%);
- makes the main mod's inner-world trials easier (up to −25% damage taken, +25% dealt);
- makes consolidation gentler and pays more cultivation from it.

### Heart demons and old age

- **Heart demons:** after a major breakthrough from Foundation on, a heart demon may take form (45%, always on the Demonic Path). It's a mirror of you, with your realm, weapon and armour, and it pulls you into your **Soul Sea**.
  - **Slay it within 3 minutes:** your Dao heart steadies (Strength, Regeneration, a surge of cultivation, Path experience).
  - **Fail, die or flee:** this realm's progress is lost and you're weakened for a while.
- **Old age:** as your bone age nears your lifespan, your body grows frail. Weakness comes from three quarters of your lifespan; Slowness and Mining Fatigue in its last tenth. Each major breakthrough announces your new lifespan. **Youth Pills** push it back (refined by Master alchemists, found in inheritances and auctions).

### The Paths to Ascension

The means to break through are jealously kept. The **⛩ Ascension** button on the cultivation menu (G) lists every road to Foundation manuals, Dao Foundation Fruits, Zhuji and Jiedan pills and Golden Core materials:

| Road | What it asks |
|---|---|
| Your sect's **Scripture Pavilion** | Contribution earned in your sect |
| The **sect trial** | Once per realm, 100 contribution and a hard consolidation before the elders (70%+) |
| **A master's teaching** | A cultivator two realms above you (Golden Core at least) who holds you in high regard, and 500◆ |
| **An ally's exchange** | An allied or vassal sect trades a foundation method for 4,000◆ and 5 prestige |
| **Comprehension under the storm** | Sneak still for a minute on a high summit (y 120+, open sky) in a thunderstorm. Once a day; insight is rare |
| **The alchemist's elixir** | Alchemy rank 5+: 24 spirit herbs, 3 high spirit stones and a hard refining |
| **Other roads** | Clan adoption, the royal grant, the arena, scripture theft, caravan auctions, boss beasts, evil cultivators, secret realms, ancient ruins and abandoned caves |

### The great breakthroughs

Beyond Golden Core, no cultivator crosses a major realm on qi alone. At the peak of each realm from Golden Core to Tribulation Transcendence, the breakthrough asks a price, paid once when the attempt begins. A failed tribulation can be tried again without paying twice.

| Crossing from | Ascension Seals | Beast Soul Orbs | Spirit stones |
|---|---|---|---|
| Golden Core | 1 | 2 | 8 high |
| Nascent Soul | 2 | 4 | 4 supreme |
| Soul Formation | 3 | 6 | 8 supreme |
| Void Refining | 4 | 8 | 16 supreme |
| Body Integration | 5 | 10 | 32 supreme |
| Mahayana | 6 | 12 | 64 supreme |
| Tribulation Transcendence | 7 | 14 | 64 supreme |

- **Ascension Seals** are never found, only bought: the crown's **Seal Office** sells one a day (6,000◆) to a Knight of the Realm or higher.
- **Beast Soul Orbs** are cut from great beasts: great evils, world bosses and other mighty beasts.

### The immortal road

The cultivation mod lists the immortal realms but opens no breakthrough into them yet. The addon opens its own road from **Earth Immortal**, through Heavenly, Perfected, Mystic, Golden, Taiyi Golden and Daluo Golden Immortal.

- **After Daluo** the road forks: the **Saint path** (Quasi-Saint, Saint, Dao Ancestor) or the **Hunyuan path** (Hunyuan Golden Immortal, Hunyuan Daluo, Hunyuan Wuji Daluo). Both end at **Great Dao Saint**.
- **Each ascension asks for** Ascension Seals, Beast Soul Orbs and spirit stones, all growing with each step (4,000 × step² stones), plus **Immortal Resonance**.
- **Immortal Resonance** comes from clearing **Immortal Resonance** gates: S-Rank secret realms drawn into resonance when an immortal is within 256 blocks.
